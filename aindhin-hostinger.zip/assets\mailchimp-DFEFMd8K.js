const o="/assets/google_ads_logo-hn5ERIda.svg",s="/assets/mailchimp-DrB5yc2i.webp";export{o as g,s as m};
