const e="/assets/mobile%20pic-Colhaqes.webp";export{e as m};
