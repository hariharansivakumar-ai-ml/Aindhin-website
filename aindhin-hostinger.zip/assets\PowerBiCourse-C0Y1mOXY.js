import{r as p,j as e,n as c,B as x,U as l,ak as h,K as m,aX as b,aY as g,g as f,am as j,ah as u,a9 as w,E as v,N,aU as y,m as I}from"./vendor-BkeoPC-K.js";import{m as t}from"./mysql-7K1F7UL4.js";import{p as B}from"./python_tool-DTKtQ8gD.js";import{G as k}from"./google_logo-DsnDYeGk.js";import{M as z}from"./microsoft_logo-DpTQl3b8.js";import{A as P}from"./aws_logo-BKbZjplO.js";import{I as S}from"./ibm_logo-ZbxQxZt0.js";import{M as A,N as D}from"./netflix_logo-CTGmZti7.js";import{I as C}from"./infosys_logo-HQ5x-L0e.js";import{A as L}from"./accenture_logo-DYYk3RN0.js";const E="/assets/power_bi-BPuXIjsU.webp",n="/assets/powerbi-BbPy9d0V.svg",d="/assets/excel-gyg8rysE.svg",T="/assets/azure-ChxFfd9H.svg",s=({children:r,className:o})=>{const i=p.useRef(null),a=y(i,{once:!0,margin:"-100px"});return e.jsx(I.div,{ref:i,initial:{opacity:0,y:24},animate:a?{opacity:1,y:0}:{opacity:0,y:24},transition:{duration:.7,ease:"easeOut"},className:o,children:r})},F=()=>{const[r,o]=p.useState(0);return e.jsxs("div",{className:"power-bi-course font-sans text-slate-900 bg-blue-50 w-full overflow-x-hidden",children:[e.jsx("style",{children:`
            /* ===== POWER BI COURSE PAGE (scoped) ===== */
            .power-bi-course{
              font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
              color:#0f172a;
              background:#e0f2fe;
              width:100%;
            }
            .power-bi-course *{box-sizing:border-box;}
            
            /* HERO */
            .pb-hero{
              color:#fff;
              background:
                linear-gradient(120deg,rgba(15,23,42,.96),rgba(37,99,235,.7)),
                url("${E}")
                center/cover no-repeat;
              padding:70px 20px;
              display:flex;
              align-items:center;
              justify-content:center;
            }
            .pb-hero-content{
              max-width:900px;
              text-align:left;
            }
            .pb-badge{
              display:inline-block;
              padding:4px 12px;
              border-radius:999px;
              background:rgba(15,23,42,.7);
              border:1px solid rgba(248,250,252,.4);
              font-size:12px;
              letter-spacing:.08em;
              text-transform:uppercase;
              margin-bottom:10px;
            }
            .pb-hero-title{
              color:#fff;
              font-size:64px;
              line-height:1.1;
              margin:0 0 14px;
            }
            .pb-hero-sub{
              font-size:20px;
              max-width:720px;
              color:#e5e7eb;
              margin:0 0 16px;
            }
            .pb-hero-meta{
              display:flex;
              flex-wrap:wrap;
              gap:10px 18px;
              font-size:13px;
              color:#e5e7eb;
            }
            .pb-hero-meta span::before{
              content:"• ";
              color:#fde68a;
              font-weight:700;
            }
            
            /* MAIN LAYOUT */
            .pb-main{padding:40px 20px 50px;}
            .pb-main-inner{
              max-width:1160px;
              margin:0 auto;
              display:grid;
              grid-template-columns:minmax(0,2fr) minmax(0,1.1fr);
              gap:24px;
            }
            .pb-left,.pb-right{
              display:flex;
              flex-direction:column;
              gap:16px;
            }
            
            /* CARDS */
            .pb-card{
              background:#ffffff;
              border-radius:18px;
              padding:20px 22px;
              box-shadow:0 10px 25px rgba(15,23,42,.08);
            }
            .pb-card h2{
              font-size:18px;
              margin:0 0 10px;
              color:#db2777;
            }
            .pb-about-text{
              font-size:14px;
              color:#4b5563;
              line-height:1.6;
            }
            
            /* SYLLABUS */
            .pb-module{
              border:1px solid #e5e7eb;
              border-radius:12px;
              background:#f9fafb;
              margin-top:8px;
              overflow:hidden;
            }
            .pb-module .summary{
              list-style:none;
              padding:10px 14px;
              cursor:pointer;
              display:flex;
              justify-content:space-between;
              align-items:center;
              font-size:14px;
              font-weight:600;
            }
            .pb-module .summary::after{
              content:"▾";
              font-size:12px;
              color:#9ca3af;
              transition:transform .2s;
            }
            .pb-module.open .summary::after{transform:rotate(-180deg);}
            .pb-module-title{
              display:flex;
              gap:8px;
              flex-wrap:wrap;
              align-items:baseline;
            }
            .pb-module-label{
              font-size:11px;
              text-transform:uppercase;
              letter-spacing:.08em;
              color:#111827;   /* dark text */
              font-weight:700; /* bold */
            }
            .pb-module-content{
              padding:0 14px 10px 24px;
              font-size:13px;
              color:#4b5563;
            }
            .pb-module-content ul{
              margin:0;
              padding-left:16px;
            }
            .pb-module-content li{margin-bottom:4px;}
            
            /* RIGHT-COLUMN DETAILS */
            .pb-detail-list{
              list-style:none;
              padding:0;
              margin:0 0 16px;
              font-size:14px;
            }
            .pb-detail-item{
              display:flex;
              gap:10px;
              margin-bottom:10px;
            }
            .pb-detail-icon{
              width:26px;
              height:26px;
              border-radius:999px;
              background:#e0f2fe;
              display:flex;
              align-items:center;
              justify-content:center;
              font-size:13px;
              color:#1d4ed8;
              flex-shrink:0;
            }
            .pb-detail-text strong{
              display:block;
              font-weight:600;
              color:#111827;
            }
            .pb-detail-text span{
              font-size:13px;
              color:#4b5563;
            }
            
            /* CTA BUTTON */
            .pb-cta-btn{
              display:block;
              width:100%;
              border-radius:999px;
              padding:11px 16px;
              border:none;
              text-align:center;
              text-decoration:none;
              background:linear-gradient(135deg,#38bdf8,#6366f1);
              color:#fff !important;
              font-weight:600;
              font-size:15px;
              box-shadow:0 14px 30px rgba(37,99,235,.4);
              transition:transform .15s,box-shadow .15s,filter .15s,color .15s;
            }
            .pb-cta-btn:hover{
              transform:translateY(-1px);
              filter:brightness(1.04);
              box-shadow:0 18px 40px rgba(37,99,235,.55);
              color:#fff !important;
            }
            
            /* TOP COMPANIES */
            .pb-companies{
              background:#e0f2fe;
              padding:40px 20px 40px;
            }
            .pb-companies-inner{
              max-width:1160px;
              margin:0 auto;
              text-align:center;
            }
            .pb-companies h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .pb-companies p{
              margin:0 0 20px;
              font-size:14px;
              color:#4b5563;
            }
            .pb-logo-row{
              display:flex;
              flex-wrap:wrap;
              justify-content:center;
              gap:18px;
            }
            .pb-logo-card{
              width:130px;
              height:62px;
              border-radius:14px;
              background:#ffffff;
              display:flex;
              align-items:center;
              justify-content:center;
              box-shadow:0 8px 18px rgba(15,23,42,.08);
              transition:transform .18s,box-shadow .18s;
            }
            .pb-logo-card img{
              max-height:40px;
              max-width:100%;
            }
            .pb-logo-card:hover{
              transform:translateY(-3px);
              box-shadow:0 14px 30px rgba(15,23,42,.16);
            }
            
            /* EXTRA COURSE DETAILS SECTION */
            .pb-highlights{
              background:#e0f2fe;
              padding:10px 20px 50px;
            }
            .pb-highlights-inner{
              max-width:1160px;
              margin:0 auto;
              display:grid;
              grid-template-columns:minmax(0,1.7fr) minmax(0,1.1fr);
              gap:28px;
              align-items:center;
            }
            .pb-highlights-heading{
              margin-bottom:12px;
            }
            .pb-highlights-heading h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .pb-highlights-heading p{
              margin:0;
              font-size:14px;
              color:#4b5563;
            }
            .pb-highlight-grid{
              margin-top:18px;
              display:grid;
              grid-template-columns:repeat(3,minmax(0,1fr));
              gap:14px;
            }
            .pb-highlight-card{
              background:#ffffff;
              border-radius:16px;
              padding:14px 12px;
              box-shadow:0 10px 24px rgba(15,23,42,.08);
            }
            .pb-highlight-icon{
              width:38px;
              height:38px;
              border-radius:999px;
              background:linear-gradient(135deg,#38bdf8,#6366f1);
              display:flex;
              align-items:center;
              justify-content:center;
              color:#fff;
              font-size:20px;
              margin-bottom:8px;
            }
            .pb-highlight-card h3{
              font-size:14px;
              margin:0 0 4px;
              color:#0f172a;
            }
            .pb-highlight-card p{
              font-size:13px;
              margin:0;
              color:#4b5563;
            }
            
            /* representation "image" block */
            .pb-highlights-visual{
              display:flex;
              justify-content:center;
            }
            .pb-dashboard{
              width:100%;
              max-width:340px;
              background:#ffffff;
              border-radius:20px;
              padding:14px 14px 18px;
              box-shadow:0 18px 40px rgba(37,99,235,.25);
            }
            .pb-dashboard-header{
              display:flex;
              justify-content:space-between;
              align-items:center;
              margin-bottom:10px;
              font-size:12px;
              color:#0f172a;
            }
            .pb-dashboard-dots{
              display:flex;
              gap:4px;
            }
            .pb-dashboard-dots span{
              width:7px;
              height:7px;
              border-radius:999px;
              background:#e5e7eb;
            }
            .pb-dashboard-graph{
              display:flex;
              gap:6px;
              align-items:flex-end;
              height:90px;
              margin-bottom:12px;
            }
            .pb-dashboard-bar{
              flex:1;
              border-radius:8px 8px 2px 2px;
              background:linear-gradient(180deg,#38bdf8,#1d4ed8);
            }
            .pb-dashboard-bar:nth-child(2){height:55%;}
            .pb-dashboard-bar:nth-child(3){height:80%;}
            .pb-dashboard-bar:nth-child(4){height:40%;}
            .pb-dashboard-bar:nth-child(5){height:70%;}
            .pb-dashboard-bar:nth-child(1){height:30%;}
            .pb-dashboard-tags{
              display:flex;
              flex-wrap:wrap;
              gap:6px;
              font-size:11px;
            }
            .pb-dashboard-tags span{
              padding:3px 7px;
              border-radius:999px;
              background:#eff6ff;
              color:#1d4ed8;
            }
            
            /* TOOLS SECTION */
            .pb-tools{
              background:#e0f2fe;
              padding:0 20px 50px;
            }
            .pb-tools-inner{
              max-width:1160px;
              margin:0 auto;
              text-align:center;
            }
            .pb-tools-inner h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .pb-tools-inner p{
              margin:0 0 20px;
              font-size:14px;
              color:#4b5563;
            }
            .pb-tools-grid{
              display:flex;
              flex-wrap:wrap;
              justify-content:center;
              gap:16px;
            }
            .pb-tools-card{
              width:140px;
              height:90px;
              border-radius:16px;
              background:#ffffff;
              box-shadow:0 10px 26px rgba(15,23,42,.12);
              display:flex;
              flex-direction:column;
              align-items:center;
              justify-content:center;
              padding:8px;
            }
            .pb-tools-logo{
              max-height:36px;
              max-width:90px;
              margin-bottom:4px;
            }
            .pb-tools-card span{
              font-size:12px;
              color:#111827;
            }
            
            /* MORE DETAILS SECTION */
            .pb-more{
              background:#e0f2fe;
              padding:0 20px 50px;
            }
            .pb-more-inner{
              max-width:1160px;
              margin:0 auto;
            }
            .pb-more-header{
              text-align:center;
              margin-bottom:20px;
            }
            .pb-more-header h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .pb-more-header p{
              margin:0;
              font-size:14px;
              color:#4b5563;
            }
            .pb-more-grid{
              display:grid;
              grid-template-columns:repeat(3,minmax(0,1fr));
              gap:18px;
            }
            .pb-more-card{
              background:#ffffff;
              border-radius:18px;
              padding:16px 14px;
              box-shadow:0 12px 30px rgba(15,23,42,.12);
              display:flex;
              flex-direction:column;
              gap:8px;
            }
            .pb-more-top{
              display:flex;
              align-items:flex-start;
              gap:8px;
            }
            .pb-more-icon{
              width:32px;
              height:32px;
              border-radius:999px;
              background:linear-gradient(135deg,#22c55e,#14b8a6);
              color:#fff;
              display:flex;
              align-items:center;
              justify-content:center;
              font-size:18px;
            }
            .pb-more-title{
              font-size:15px;
              font-weight:600;
              margin:0;
              color:#0f172a;
            }
            .pb-more-text{
              font-size:13px;
              color:#4b5563;
              margin:0;
            }
            .pb-tool-logos{
              margin-top:12px;
              display:flex;
              flex-wrap:wrap;
              gap:10px;
              align-items:center;
              justify-content:center;
              width:100%;
            }
            .pb-tool-logo{
              max-height:32px;
              width:auto;
              filter:drop-shadow(0 2px 4px rgba(15,23,42,.18));
            }
            .pb-tool-logos img{
              max-height:32px !important;
              width:auto !important;
              object-fit:contain;
            }
            .pb-roles-image{
              margin-top:8px;
              display:flex;
              flex-wrap:wrap;
              gap:6px;
            }
            .pb-role-tag{
              padding:4px 8px;
              border-radius:999px;
              font-size:11px;
              background:#eff6ff;
              color:#1d4ed8;
            }
            .pb-journey{
              margin-top:8px;
              border-left:2px solid #bfdbfe;
              padding-left:10px;
            }
            .pb-journey-step{
              position:relative;
              padding-left:10px;
              margin-bottom:6px;
              font-size:12px;
              color:#4b5563;
            }
            .pb-journey-step::before{
              content:"";
              position:absolute;
              left:-11px;
              top:5px;
              width:8px;
              height:8px;
              border-radius:999px;
              background:#38bdf8;
            }
            
            /* RESPONSIVE */
            @media (max-width:900px){
              .pb-hero{padding:50px 18px;}
              .pb-hero-title{font-size:48px;}
              .pb-main-inner{
                grid-template-columns:minmax(0,1fr);
              }
              .pb-highlights-inner{
                grid-template-columns:minmax(0,1fr);
              }
              .pb-more-grid{
                grid-template-columns:minmax(0,1fr);
              }
            }
            @media (max-width:640px){
              .pb-hero{padding:38px 16px;}
              .pb-hero-meta{flex-direction:column;}
              .pb-highlight-grid{
                grid-template-columns:minmax(0,1fr);
              }
            }
            `}),e.jsxs("div",{className:"power-bi-course",id:"top",children:[e.jsx(s,{className:"pb-hero pb-section",children:e.jsxs("div",{className:"pb-hero-content",children:[e.jsx("span",{className:"pb-badge",children:"Power BI"}),e.jsx("h1",{className:"fs-hero-title",children:"Power BI – Data Visualization & Business Intelligence"}),e.jsx("p",{className:"fs-hero-sub",children:"Learn to connect, transform and model data in Power BI, build interactive dashboards, write DAX measures, and publish BI reports that help teams make faster, better decisions."}),e.jsxs("div",{className:"pb-hero-meta",children:[e.jsx("span",{children:"End‑to‑end Power BI – Desktop, DAX & Service"}),e.jsx("span",{children:"No prior BI experience required (basic Excel helps)"}),e.jsx("span",{children:"Capstone project with real‑world business dataset"})]})]})}),e.jsx("main",{className:"pb-main pb-section",children:e.jsxs("div",{className:"pb-main-inner",children:[e.jsxs("div",{className:"pb-left",children:[e.jsxs(s,{className:"pb-card",children:[e.jsx("h2",{children:"About This Course"}),e.jsxs("div",{className:"pb-about-text",children:[e.jsx("p",{children:"This hands‑on course teaches you how to use Power BI as a full Business Intelligence platform. You’ll learn how to connect to Excel and database sources, clean and shape data with Power Query, design data models, and write DAX to calculate business metrics."}),e.jsx("p",{children:"You will then create interactive dashboards and reports, apply row‑level security, and publish your work to the Power BI Service so that stakeholders can access fresh, reliable insights on any device."})]})]}),e.jsxs(s,{className:"pb-card",children:[e.jsx("h2",{children:"Syllabus Covered"}),e.jsx("div",{className:"flex flex-col gap-4",children:[{label:"Module 1",title:"Getting Started with Power BI Desktop",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Power BI ecosystem: Desktop, Service & Mobile"}),e.jsx("li",{children:"Connecting to Excel, CSV and database sources"}),e.jsx("li",{children:"Using Power Query to clean & transform data"}),e.jsx("li",{children:"Creating relationships & star schemas"}),e.jsx("li",{children:"Building your first interactive report"})]})},{label:"Module 2",title:"Data Modeling & DAX Fundamentals",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Dimension vs fact tables & model design patterns"}),e.jsx("li",{children:"Calculated columns vs measures"}),e.jsx("li",{children:"DAX basics: SUM, COUNTROWS, CALCULATE, FILTER"}),e.jsx("li",{children:"Time-intelligence: YTD, MTD, YoY growth"}),e.jsx("li",{children:"Optimizing models for performance & reuse"})]})},{label:"Module 3",title:"Visualizations, Dashboards & UX Design",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Choosing the right visuals for different questions"}),e.jsx("li",{children:"Designing layout, navigation & drill-through pages"}),e.jsx("li",{children:"Bookmarks, tooltips, slicers & custom visuals"}),e.jsx("li",{children:"Building executive KPI dashboards"}),e.jsx("li",{children:"Theming, branding & report performance tips"})]})},{label:"Module 4",title:"Publishing, Security & Power BI Service",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Publishing reports to Power BI Service"}),e.jsx("li",{children:"Workspaces, apps & sharing strategies"}),e.jsx("li",{children:"Refresh schedules & gateway basics"}),e.jsx("li",{children:"Row-level security (RLS) & access control"}),e.jsx("li",{children:"Capstone: end-to-end Power BI BI solution"})]})}].map((i,a)=>e.jsxs("div",{className:`pb-module ${r===a?"open":""}`,onClick:()=>o(r===a?null:a),children:[e.jsx("div",{className:"summary",children:e.jsxs("div",{className:"pb-module-title",children:[e.jsx("span",{className:"pb-module-label",children:i.label}),e.jsx("span",{children:i.title})]})}),r===a&&e.jsx("div",{className:"pb-module-content",children:i.content})]},a))})]})]}),e.jsx("aside",{className:"pb-right",children:e.jsxs(s,{className:"pb-card",children:[e.jsx("h2",{children:"Course Details"}),e.jsxs("ul",{className:"pb-detail-list",children:[e.jsxs("li",{className:"pb-detail-item",children:[e.jsx("div",{className:"pb-detail-icon",children:e.jsx(c,{size:20})}),e.jsxs("div",{className:"pb-detail-text",children:[e.jsx("strong",{children:"Duration"}),e.jsx("span",{children:"8 Weeks (50+ hours of intensive Power BI practice)"})]})]}),e.jsxs("li",{className:"pb-detail-item",children:[e.jsx("div",{className:"pb-detail-icon",children:e.jsx(x,{size:20})}),e.jsxs("div",{className:"pb-detail-text",children:[e.jsx("strong",{children:"Skill Level"}),e.jsx("span",{children:"Beginner to Intermediate – basic Excel/SQL is helpful"})]})]}),e.jsxs("li",{className:"pb-detail-item",children:[e.jsx("div",{className:"pb-detail-icon",children:e.jsx(l,{size:20})}),e.jsxs("div",{className:"pb-detail-text",children:[e.jsx("strong",{children:"Includes"}),e.jsx("span",{children:"Live labs, DAX exercises, dashboard reviews & Q&A sessions"})]})]}),e.jsxs("li",{className:"pb-detail-item",children:[e.jsx("div",{className:"pb-detail-icon",children:e.jsx(h,{size:20})}),e.jsxs("div",{className:"pb-detail-text",children:[e.jsx("strong",{children:"Next Batch"}),e.jsx("span",{children:"Coming Soon"})]})]}),e.jsxs("li",{className:"pb-detail-item",children:[e.jsx("div",{className:"pb-detail-icon",children:e.jsx(m,{size:20})}),e.jsxs("div",{className:"pb-detail-text",children:[e.jsx("strong",{children:"Certificate"}),e.jsx("span",{children:"Completion certificate + production‑style Power BI reports"})]})]})]}),e.jsx("a",{href:"#top",className:"pb-cta-btn",children:"Enroll Now & Start Learning"})]})})]})}),e.jsx(s,{className:"pb-companies pb-section",children:e.jsxs("div",{className:"pb-companies-inner",children:[e.jsx("h2",{children:"Top Companies Using Power BI for BI & Reporting"}),e.jsx("p",{children:"Power BI is widely adopted across enterprises, startups and consulting firms for self‑service BI."}),e.jsxs("div",{className:"pb-logo-row",children:[e.jsx("div",{className:"pb-logo-card",children:e.jsx("img",{src:k,alt:"Google"})}),e.jsx("div",{className:"pb-logo-card",children:e.jsx("img",{src:z,alt:"Microsoft"})}),e.jsx("div",{className:"pb-logo-card",children:e.jsx("img",{src:P,alt:"AWS"})}),e.jsx("div",{className:"pb-logo-card",children:e.jsx("img",{src:S,alt:"IBM"})}),e.jsx("div",{className:"pb-logo-card",children:e.jsx("img",{src:A,alt:"Meta"})}),e.jsx("div",{className:"pb-logo-card",children:e.jsx("img",{src:D,alt:"Netflix"})}),e.jsx("div",{className:"pb-logo-card",children:e.jsx("img",{src:C,alt:"Infosys"})}),e.jsx("div",{className:"pb-logo-card",children:e.jsx("img",{src:L,alt:"Accenture"})})]})]})}),e.jsx(s,{className:"pb-highlights pb-section",children:e.jsxs("div",{className:"pb-highlights-inner",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"pb-highlights-heading",children:[e.jsx("h2",{children:"What You Will Achieve in This Power BI Program"}),e.jsx("p",{children:"Go from raw data to enterprise‑grade Power BI dashboards and BI reports."})]}),e.jsxs("div",{className:"pb-highlight-grid",children:[e.jsxs("div",{className:"pb-highlight-card",children:[e.jsx("div",{className:"pb-highlight-icon",children:e.jsx(b,{size:24})}),e.jsx("h3",{children:"Strong Data Modeling Skills"}),e.jsx("p",{children:"Design robust star‑schema models that perform well on large datasets and evolve with business needs."})]}),e.jsxs("div",{className:"pb-highlight-card",children:[e.jsx("div",{className:"pb-highlight-icon",children:e.jsx(g,{size:24})}),e.jsx("h3",{children:"DAX for Business Metrics"}),e.jsx("p",{children:"Write DAX measures to calculate KPIs like revenue growth, churn, cohort metrics and more."})]}),e.jsxs("div",{className:"pb-highlight-card",children:[e.jsx("div",{className:"pb-highlight-icon",children:e.jsx(f,{size:24})}),e.jsx("h3",{children:"Interactive Dashboards"}),e.jsx("p",{children:"Build pixel‑perfect dashboards with drill‑downs, bookmarks and mobile‑friendly layouts."})]}),e.jsxs("div",{className:"pb-highlight-card",children:[e.jsx("div",{className:"pb-highlight-icon",children:e.jsx(j,{size:24})}),e.jsx("h3",{children:"Secure BI Deployments"}),e.jsx("p",{children:"Configure workspaces, apps, refresh schedules and RLS so your reports stay fresh and secure."})]}),e.jsxs("div",{className:"pb-highlight-card",children:[e.jsx("div",{className:"pb-highlight-icon",children:e.jsx(u,{size:24})}),e.jsx("h3",{children:"Real‑World Capstone"}),e.jsx("p",{children:"Deliver a complete Power BI solution for a simulated company, from raw CSVs to published app."})]}),e.jsxs("div",{className:"pb-highlight-card",children:[e.jsx("div",{className:"pb-highlight-icon",children:e.jsx(l,{size:24})}),e.jsx("h3",{children:"Mentor Guidance"}),e.jsx("p",{children:"Get support on DAX logic, model design and dashboard UX from experienced BI practitioners."})]})]})]}),e.jsx("div",{className:"pb-highlights-visual",children:e.jsxs("div",{className:"pb-dashboard",children:[e.jsxs("div",{className:"pb-dashboard-header",children:[e.jsx("span",{children:"Power BI Sales Overview"}),e.jsxs("div",{className:"pb-dashboard-dots",children:[e.jsx("span",{}),e.jsx("span",{}),e.jsx("span",{})]})]}),e.jsxs("div",{className:"pb-dashboard-graph",children:[e.jsx("div",{className:"pb-dashboard-bar"}),e.jsx("div",{className:"pb-dashboard-bar"}),e.jsx("div",{className:"pb-dashboard-bar"}),e.jsx("div",{className:"pb-dashboard-bar"}),e.jsx("div",{className:"pb-dashboard-bar"})]}),e.jsxs("div",{className:"pb-dashboard-tags",children:[e.jsx("span",{children:"Total Sales"}),e.jsx("span",{children:"Profit Margin"}),e.jsx("span",{children:"Region Performance"}),e.jsx("span",{children:"Top Products"})]})]})})]})}),e.jsx(s,{className:"pb-tools pb-section",children:e.jsxs("div",{className:"pb-tools-inner",children:[e.jsx("h2",{children:"Tools & Platforms You Will Use"}),e.jsx("p",{children:"Get comfortable with the Power BI ecosystem and common data sources used with it."}),e.jsxs("div",{className:"pb-tools-grid",children:[e.jsxs("div",{className:"pb-tools-card",children:[e.jsx("img",{className:"pb-tools-logo",src:n,alt:"Power BI"}),e.jsx("span",{children:"Power BI Desktop / Service"})]}),e.jsxs("div",{className:"pb-tools-card",children:[e.jsx("img",{className:"pb-tools-logo",src:d,alt:"Excel"}),e.jsx("span",{children:"Microsoft Excel"})]}),e.jsxs("div",{className:"pb-tools-card",children:[e.jsx("img",{className:"pb-tools-logo",src:t,alt:"MySQL"}),e.jsx("span",{children:"SQL Databases"})]}),e.jsxs("div",{className:"pb-tools-card",children:[e.jsx("img",{className:"pb-tools-logo",src:T,alt:"Azure"}),e.jsx("span",{children:"Azure / Cloud Sources"})]}),e.jsxs("div",{className:"pb-tools-card",children:[e.jsx("img",{className:"pb-tools-logo",src:B,alt:"Python"}),e.jsx("span",{children:"Python (optional data prep)"})]})]})]})}),e.jsx(s,{className:"pb-more pb-section",children:e.jsxs("div",{className:"pb-more-inner",children:[e.jsxs("div",{className:"pb-more-header",children:[e.jsx("h2",{children:"Roles & Learning Journey"}),e.jsx("p",{children:"See how this course maps directly to common Power BI and BI Analyst job roles."})]}),e.jsxs("div",{className:"pb-more-grid",children:[e.jsxs("div",{className:"pb-more-card",children:[e.jsxs("div",{className:"pb-more-top",children:[e.jsx("div",{className:"pb-more-icon",children:e.jsx(w,{size:20})}),e.jsxs("div",{children:[e.jsx("h3",{className:"pb-more-title",children:"Power BI Toolset"}),e.jsx("p",{className:"pb-more-text",children:"Use Desktop for modeling and report design, and the Service for sharing, security and refresh orchestration."})]})]}),e.jsxs("div",{className:"pb-tool-logos",children:[e.jsx("img",{className:"pb-tool-logo",src:n,alt:"Power BI"}),e.jsx("img",{className:"pb-tool-logo",src:d,alt:"Excel"}),e.jsx("img",{className:"pb-tool-logo",src:t,alt:"MySQL"})]})]}),e.jsxs("div",{className:"pb-more-card",children:[e.jsxs("div",{className:"pb-more-top",children:[e.jsx("div",{className:"pb-more-icon",children:e.jsx(v,{size:20})}),e.jsxs("div",{children:[e.jsx("h3",{className:"pb-more-title",children:"Career Roles You Can Target"}),e.jsx("p",{className:"pb-more-text",children:"Align your portfolio and skills with the Power BI‑focused roles recruiters are hiring for today."})]})]}),e.jsxs("div",{className:"pb-roles-image",children:[e.jsx("span",{className:"pb-role-tag",children:"Power BI Developer"}),e.jsx("span",{className:"pb-role-tag",children:"BI Analyst"}),e.jsx("span",{className:"pb-role-tag",children:"Reporting Analyst"}),e.jsx("span",{className:"pb-role-tag",children:"Data Analyst (Power BI)"}),e.jsx("span",{className:"pb-role-tag",children:"Analytics Engineer – BI"})]})]}),e.jsxs("div",{className:"pb-more-card",children:[e.jsxs("div",{className:"pb-more-top",children:[e.jsx("div",{className:"pb-more-icon",children:e.jsx(N,{size:20})}),e.jsxs("div",{children:[e.jsx("h3",{className:"pb-more-title",children:"Your 8‑Week Learning Journey"}),e.jsx("p",{className:"pb-more-text",children:"A compact plan that makes you productive in Power BI in just two months."})]})]}),e.jsxs("div",{className:"pb-journey",children:[e.jsx("div",{className:"pb-journey-step",children:"Weeks 1–2: Power BI Desktop basics, Power Query & data loading"}),e.jsx("div",{className:"pb-journey-step",children:"Weeks 3–4: Data modeling best practices & core DAX measures"}),e.jsx("div",{className:"pb-journey-step",children:"Weeks 5–6: Advanced visuals, interactions & dashboard UX"}),e.jsx("div",{className:"pb-journey-step",children:"Weeks 7–8: Power BI Service, security, refresh & capstone project"})]})]})]})]})})]})]})};export{F as default};
