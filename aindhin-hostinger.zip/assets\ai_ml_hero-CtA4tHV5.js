const e="/assets/ai_ml_hero-gpi3ENni.webp";export{e as A};
