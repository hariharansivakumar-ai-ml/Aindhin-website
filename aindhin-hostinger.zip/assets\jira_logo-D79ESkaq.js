const o="/assets/jira_logo-BbRA0u4J.webp";export{o as J};
