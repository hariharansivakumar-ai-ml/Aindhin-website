const o="/assets/html5_logo-DZkm32X4.svg";export{o as H};
