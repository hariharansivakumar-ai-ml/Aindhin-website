const s="/assets/pandas-CAqHiGRj.svg";export{s as P};
