const e="/assets/accenture-BRC-jHAb.svg";export{e as A};
