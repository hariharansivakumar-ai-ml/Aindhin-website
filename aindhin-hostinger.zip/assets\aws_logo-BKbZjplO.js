const s="/assets/aws-Ckru8vcZ.svg";export{s as A};
