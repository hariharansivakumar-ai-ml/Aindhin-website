const s="/assets/r_logo-Buk5VsO6.svg";export{s as R};
