import{r as d,j as e,G as p,E as o,b2 as u,ax as f,l as j,ab as c,af as b,b3 as m,a9 as t,an as v,n as N,B as g,U as w,ak as y,K as k,aw as A,b4 as M,N as E,aU as C,m as S}from"./vendor-BkeoPC-K.js";import{F as z}from"./FAQSection-BzwAclpV.js";import{h as O}from"./digital_marketing_hero-BYvApVmU.js";import{g as h,m as I}from"./mailchimp-DFEFMd8K.js";import{G as x}from"./google_analytics_logo-CUZVike8.js";import{M as l,N as G}from"./netflix_logo-CTGmZti7.js";import{L}from"./linkedin_logo-C50-VQpI.js";import{C as T}from"./canva-hRnZO1Vj.js";import{G as D}from"./google_logo-DsnDYeGk.js";import{M as B}from"./microsoft_logo-DpTQl3b8.js";import{A as P}from"./aws_logo-BKbZjplO.js";import{I as R}from"./ibm_logo-ZbxQxZt0.js";import{I as U}from"./infosys_logo-HQ5x-L0e.js";import{A as W}from"./accenture_logo-DYYk3RN0.js";const s=({children:n,className:r})=>{const i=d.useRef(null),a=C(i,{once:!0,margin:"-100px"});return e.jsx(S.div,{ref:i,initial:{opacity:0,y:24},animate:a?{opacity:1,y:0}:{opacity:0,y:24},transition:{duration:.7,ease:"easeOut"},className:r,children:n})},ae=()=>{d.useEffect(()=>{document.title="Online Digital Marketing Course with Certificate | Aindhin";const i=document.querySelector('meta[name="description"]');i&&i.setAttribute("content","Become a job-ready digital marketer with hands-on training in SEO, Google Ads, Analytics, AI Marketing, and real-world projects.")},[]);const[n,r]=d.useState(0);return e.jsxs("div",{className:"dm-course font-sans text-slate-900 bg-blue-50 w-full",children:[e.jsx("style",{children:`
            /* ===== DIGITAL MARKETING COURSE PAGE (scoped) ===== */
            .dm-course{
              font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
              color:#0f172a;
              background:#e0f2fe;
              width:100%;
            }
            .dm-course *{box-sizing:border-box;}
            
            /* HERO */
            .dm-hero{
              color:#fff;
              background:
                linear-gradient(120deg,rgba(15,23,42,.96),rgba(37,99,235,.7)),
                url("${O}")
                center/cover no-repeat;
              padding:70px 20px;
              display:flex;
              align-items:center;
              justify-content:center;
            }
            .dm-hero-content{
              max-width:900px;
              text-align:left;
            }
            .dm-badge{
              display:inline-block;
              padding:4px 12px;
              border-radius:999px;
              background:rgba(15,23,42,.7);
              border:1px solid rgba(248,250,252,.4);
              font-size:12px;
              letter-spacing:.08em;
              text-transform:uppercase;
              margin-bottom:10px;
            }
            .fs-hero-title{
              color:#fff;
              font-size:64px;
              line-height:1.1;
              margin:0 0 14px;
            }
            .fs-hero-sub{
              font-size:20px;
              max-width:720px;
              color:#e5e7eb;
              margin:0 0 16px;
            }
            .dm-hero-meta{
              display:flex;
              flex-wrap:wrap;
              gap:10px 18px;
              font-size:13px;
              color:#e5e7eb;
            }
            .dm-hero-meta span::before{
              content:"• ";
              color:#fde68a;
              font-weight:700;
            }
            
            /* MAIN LAYOUT */
            .dm-main{padding:40px 20px 50px;}
            .dm-main-inner{
              max-width:1160px;
              margin:0 auto;
              display:grid;
              grid-template-columns:minmax(0,2fr) minmax(0,1.1fr);
              gap:24px;
            }
            .dm-left,.dm-right{
              display:flex;
              flex-direction:column;
              gap:16px;
            }
            
            /* CARDS */
            .dm-card{
              background:#ffffff;
              border-radius:18px;
              padding:20px 22px;
              box-shadow:0 10px 25px rgba(15,23,42,.08);
            }
            .dm-card h2{
              font-size:18px;
              margin:0 0 10px;
              color:#1d4ed8;
            }
            .dm-about-text{
              font-size:14px;
              color:#4b5563;
              line-height:1.6;
            }
            
            /* SYLLABUS */
            .dm-module{
              border:1px solid #e5e7eb;
              border-radius:12px;
              background:#f9fafb;
              margin-top:8px;
              overflow:hidden;
            }
            .dm-module .summary{
              list-style:none;
              padding:10px 14px;
              cursor:pointer;
              display:flex;
              justify-content:space-between;
              align-items:center;
              font-size:14px;
              font-weight:600;
            }
            .dm-module .summary::after{
              content:"▾";
              font-size:12px;
              color:#9ca3af;
              transition:transform .2s;
            }
            .dm-module.open .summary::after{transform:rotate(-180deg);}
            .dm-module-title{
              display:flex;
              gap:8px;
              flex-wrap:wrap;
              align-items:baseline;
            }
            .dm-module-label{
              font-size:11px;
              text-transform:uppercase;
              letter-spacing:.08em;
              color:#111827;   /* dark text */
              font-weight:700; /* bold */
            }
            .dm-module-content{
              padding:0 14px 10px 24px;
              font-size:13px;
              color:#4b5563;
            }
            .dm-module-content ul{
              margin:0;
              padding-left:16px;
            }
            .dm-module-content li{margin-bottom:4px;}
            
            /* RIGHT-COLUMN DETAILS */
            .dm-detail-list{
              list-style:none;
              padding:0;
              margin:0 0 16px;
              font-size:14px;
            }
            .dm-detail-item{
              display:flex;
              gap:10px;
              margin-bottom:10px;
            }
            .dm-detail-icon{
              width:26px;
              height:26px;
              border-radius:999px;
              background:#e0f2fe;
              display:flex;
              align-items:center;
              justify-content:center;
              font-size:13px;
              color:#1d4ed8;
              flex-shrink:0;
            }
            .dm-detail-text strong{
              display:block;
              font-weight:600;
              color:#111827;
            }
            .dm-detail-text span{
              font-size:13px;
              color:#4b5563;
            }
            
            /* CTA BUTTON (BLUE THEME) */
            .dm-cta-btn{
              display:block;
              width:100%;
              border-radius:999px;
              padding:11px 16px;
              border:none;
              text-align:center;
              text-decoration:none;
              background:linear-gradient(135deg,#38bdf8,#6366f1);
              color:#fff !important;
              font-weight:600;
              font-size:15px;
              box-shadow:0 14px 30px rgba(37,99,235,.45);
              transition:transform .15s,box-shadow .15s,filter .15s,color .15s;
            }
            .dm-cta-btn:hover{
              transform:translateY(-1px);
              filter:brightness(1.04);
              box-shadow:0 18px 40px rgba(37,99,235,.6);
              color:#fff !important;
            }
            
            /* TOP COMPANIES */
            .dm-companies{
              background:#e0f2fe;
              padding:40px 20px 40px;
            }
            .dm-companies-inner{
              max-width:1160px;
              margin:0 auto;
              text-align:center;
            }
            .dm-companies h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .dm-companies p{
              margin:0 0 20px;
              font-size:14px;
              color:#4b5563;
            }
            .dm-logo-row{
              display:flex;
              flex-wrap:wrap;
              justify-content:center;
              gap:18px;
            }
            .dm-logo-card{
              width:130px;
              height:62px;
              border-radius:14px;
              background:#ffffff;
              display:flex;
              align-items:center;
              justify-content:center;
              box-shadow:0 8px 18px rgba(15,23,42,.08);
              transition:transform .18s,box-shadow .18s;
            }
            .dm-logo-card img{
              max-height:40px;
              max-width:100%;
            }
            .dm-logo-card:hover{
              transform:translateY(-3px);
              box-shadow:0 14px 30px rgba(15,23,42,.16);
            }
            
            /* EXTRA COURSE DETAILS SECTION */
            .dm-highlights{
              background:#e0f2fe;
              padding:10px 20px 50px;
            }
            .dm-highlights-inner{
              max-width:1160px;
              margin:0 auto;
              display:grid;
              grid-template-columns:minmax(0,1.7fr) minmax(0,1.1fr);
              gap:28px;
              align-items:center;
            }
            .dm-highlights-heading{
              margin-bottom:12px;
            }
            .dm-highlights-heading h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .dm-highlights-heading p{
              margin:0;
              font-size:14px;
              color:#4b5563;
            }
            .dm-highlight-grid{
              margin-top:18px;
              display:grid;
              grid-template-columns:repeat(3,minmax(0,1fr));
              gap:14px;
            }
            .dm-highlight-card{
              background:#ffffff;
              border-radius:16px;
              padding:14px 12px;
              box-shadow:0 10px 24px rgba(15,23,42,.08);
            }
            .dm-highlight-icon{
              width:38px;
              height:38px;
              border-radius:999px;
              background:linear-gradient(135deg,#38bdf8,#6366f1); /* BLUE ICONS */
              display:flex;
              align-items:center;
              justify-content:center;
              color:#fff;
              font-size:20px;
              margin-bottom:8px;
            }
            .dm-highlight-card h3{
              font-size:14px;
              margin:0 0 4px;
              color:#0f172a;
            }
            .dm-highlight-card p{
              font-size:13px;
              margin:0;
              color:#4b5563;
            }
            
            /* representation "image" block */
            .dm-highlights-visual{
              display:flex;
              justify-content:center;
            }
            .dm-dashboard{
              width:100%;
              max-width:340px;
              background:#ffffff;
              border-radius:20px;
              padding:14px 14px 18px;
              box-shadow:0 18px 40px rgba(37,99,235,.35); /* BLUE SHADOW */
            }
            .dm-dashboard-header{
              display:flex;
              justify-content:space-between;
              align-items:center;
              margin-bottom:10px;
              font-size:12px;
              color:#0f172a;
            }
            .dm-dashboard-dots{
              display:flex;
              gap:4px;
            }
            .dm-dashboard-dots span{
              width:7px;
              height:7px;
              border-radius:999px;
              background:#bfdbfe; /* LIGHT BLUE */
            }
            .dm-dashboard-graph{
              display:flex;
              gap:6px;
              align-items:flex-end;
              height:90px;
              margin-bottom:12px;
            }
            .dm-dashboard-bar{
              flex:1;
              border-radius:8px 8px 2px 2px;
              background:linear-gradient(180deg,#38bdf8,#1d4ed8); /* BLUE BARS */
            }
            .dm-dashboard-bar:nth-child(2){height:55%;}
            .dm-dashboard-bar:nth-child(3){height:80%;}
            .dm-dashboard-bar:nth-child(4){height:40%;}
            .dm-dashboard-bar:nth-child(5){height:70%;}
            .dm-dashboard-bar:nth-child(1){height:30%;}
            .dm-dashboard-tags{
              display:flex;
              flex-wrap:wrap;
              gap:6px;
              font-size:11px;
            }
            .dm-dashboard-tags span{
              padding:3px 7px;
              border-radius:999px;
              background:#eff6ff;
              color:#1d4ed8;
            }
            
            /* TOOLS SECTION */
            .dm-tools{
              background:#e0f2fe;
              padding:0 20px 50px;
            }
            .dm-tools-inner{
              max-width:1160px;
              margin:0 auto;
              text-align:center;
            }
            .dm-tools-inner h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .dm-tools-inner p{
              margin:0 0 20px;
              font-size:14px;
              color:#4b5563;
            }
            .dm-tools-grid{
              display:flex;
              flex-wrap:wrap;
              justify-content:center;
              gap:16px;
            }
            .dm-tools-card{
              width:140px;
              height:90px;
              border-radius:16px;
              background:#ffffff;
              box-shadow:0 10px 26px rgba(15,23,42,.12);
              display:flex;
              flex-direction:column;
              align-items:center;
              justify-content:center;
              padding:8px;
            }
            .dm-tools-logo{
              max-height:36px;
              max-width:90px;
              margin-bottom:4px;
            }
            .dm-tools-card span{
              font-size:12px;
              color:#111827;
            }
            
            /* MORE DETAILS SECTION */
            .dm-more{
              background:#e0f2fe;
              padding:0 20px 50px;
            }
            .dm-more-inner{
              max-width:1160px;
              margin:0 auto;
            }
            .dm-more-header{
              text-align:center;
              margin-bottom:20px;
            }
            .dm-more-header h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .dm-more-header p{
              margin:0;
              font-size:14px;
              color:#4b5563;
            }
            .dm-more-grid{
              display:grid;
              grid-template-columns:repeat(3,minmax(0,1fr));
              gap:18px;
            }
            .dm-more-card{
              background:#ffffff;
              border-radius:18px;
              padding:16px 14px;
              box-shadow:0 12px 30px rgba(15,23,42,.12);
              display:flex;
              flex-direction:column;
              gap:8px;
            }
            .dm-more-top{
              display:flex;
              align-items:flex-start;
              gap:8px;
            }
            .dm-more-icon{
              width:32px;
              height:32px;
              border-radius:999px;
              background:linear-gradient(135deg,#38bdf8,#6366f1); /* BLUE ICONS */
              color:#fff;
              display:flex;
              align-items:center;
              justify-content:center;
              font-size:18px;
            }
            .dm-more-title{
              font-size:15px;
              font-weight:600;
              margin:0;
              color:#0f172a;
            }
            .dm-more-text{
              font-size:13px;
              color:#4b5563;
              margin:0;
            }
            .dm-tool-logos{
              margin-top:12px;
              display:flex;
              flex-wrap:wrap;
              gap:10px;
              align-items:center;
              justify-content:center;
              width:100%;
            }
            .dm-tool-logo{
              max-height:32px;
              width:auto;
              filter:drop-shadow(0 2px 4px rgba(15,23,42,.18));
            }
            .dm-tool-logos img{
              max-height:32px !important;
              width:auto !important;
              object-fit:contain;
            }
            .dm-roles-image{
              margin-top:8px;
              display:flex;
              flex-wrap:wrap;
              gap:6px;
            }
            .dm-role-tag{
              padding:4px 8px;
              border-radius:999px;
              font-size:11px;
              background:#eff6ff;
              color:#1d4ed8;
            }
            .dm-journey{
              margin-top:8px;
              border-left:2px solid #bfdbfe;
              padding-left:10px;
            }
            .dm-journey-step{
              position:relative;
              padding-left:10px;
              margin-bottom:6px;
              font-size:12px;
              color:#4b5563;
            }
            .dm-journey-step::before{
              content:"";
              position:absolute;
              left:-11px;
              top:5px;
              width:8px;
              height:8px;
              border-radius:999px;
              background:#38bdf8;
            }
            
            /* RESPONSIVE */
            @media (max-width:900px){
              .dm-hero{padding:50px 18px;}
              .fs-hero-title{font-size:48px;}
              .dm-main-inner{
                grid-template-columns:minmax(0,1fr);
              }
              .dm-highlights-inner{
                grid-template-columns:minmax(0,1fr);
              }
              .dm-more-grid{
                grid-template-columns:minmax(0,1fr);
              }
            }
            @media (max-width:640px){
              .dm-hero{padding:38px 16px;}
              .dm-hero-meta{flex-direction:column;}
              .dm-highlight-grid{
                grid-template-columns:minmax(0,1fr);
              }
            }
            `}),e.jsxs("div",{className:"dm-course",id:"top",children:[e.jsx(s,{className:"dm-hero dm-section",children:e.jsxs("div",{className:"flex flex-col md:flex-row justify-between items-start max-w-[1200px] mx-auto w-full gap-8",children:[e.jsxs("div",{className:"dm-hero-content",children:[e.jsx("span",{className:"dm-badge",children:"Online Digital Marketing Certificate Course"}),e.jsx("h1",{className:"fs-hero-title",children:"Become a Job-Ready Digital Marketer with Industry-Relevant Skills"}),e.jsx("p",{className:"fs-hero-sub",children:"Master SEO, Google Ads, Social Media Marketing, AI-Powered Marketing, Content Strategy, Email Marketing, Analytics, and Marketing Automation through a structured online learning experience."}),e.jsxs("div",{className:"dm-hero-meta",children:[e.jsx("span",{children:"Learn SEO, AI-Powered Marketing, Google Ads & Social Media Marketing"}),e.jsx("span",{children:"Hands-On Training with Modern AI Marketing Tools"}),e.jsx("span",{children:"Develop a Portfolio Through Hands-On Campaign Projects"})]})]}),e.jsx("div",{className:"flex-shrink-0 w-full md:w-auto mt-6 md:mt-12",children:e.jsxs("a",{href:"https://user.aindhin.com/course/AD-944b67c3bbf11c6b037beb11b0c1ada8",target:"_blank",rel:"noopener noreferrer",className:"inline-flex items-center justify-center gap-2 px-8 py-4 bg-primary text-white font-bold rounded-full shadow-[0_10px_30px_rgba(37,99,235,0.4)] hover:shadow-[0_20px_40px_rgba(37,99,235,0.6)] hover:-translate-y-1 transition-all duration-300 font-inter text-lg w-full md:w-auto animate-color-blink",children:["Enroll Now ",e.jsx(p,{className:"w-5 h-5"})]})})]})}),e.jsx("main",{className:"dm-main dm-section",children:e.jsxs("div",{className:"dm-main-inner",children:[e.jsxs("div",{className:"dm-left",children:[e.jsxs(s,{className:"dm-card",children:[e.jsx("h2",{children:"Build Future-Ready Digital Marketing Skills"}),e.jsxs("div",{className:"dm-about-text",children:[e.jsx("p",{className:"mb-4",children:"Digital marketing is one of the most valuable skills in today's business environment. Businesses rely on search engines, social media, paid advertising, content marketing, and data analytics to attract customers and drive growth. As AI-powered search experiences continue to evolve, marketers need practical skills that go beyond traditional marketing concepts."}),e.jsx("p",{className:"mb-4",children:"The Aindhin Online Digital Marketing Certificate Course is designed to help learners build industry-relevant expertise through structured online training. Over 10 weeks, you'll gain hands-on experience in SEO, AEO, GEO, XEO, Google Ads, Social Media Marketing, Email Marketing, Analytics, Marketing Automation, and AI-powered marketing workflows used by modern businesses."}),e.jsx("p",{children:"Through interactive learning, practical assignments, and real-world marketing scenarios, you'll gain the ability to create, manage, and improve digital marketing campaigns across multiple platforms."})]})]}),e.jsxs(s,{className:"dm-card",children:[e.jsx("h2",{children:"Syllabus Covered"}),e.jsx("div",{className:"flex flex-col gap-4",children:[{icon:e.jsx(o,{className:"w-5 h-5 text-blue-600"}),label:"Module 1",title:"Digital Marketing Fundamentals",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Understand the digital marketing ecosystem, customer journey, and buyer personas"}),e.jsx("li",{children:"Identify marketing funnels & customer acquisition pathways"}),e.jsx("li",{children:"Analyze competitor strategies and define brand positioning"}),e.jsx("li",{children:"Learn the fundamentals of core digital marketing strategies"})]})},{icon:e.jsx(u,{className:"w-5 h-5 text-blue-600"}),label:"Module 2",title:"Website, Landing Pages & Conversion Optimization",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Understand website structure and planning layout"}),e.jsx("li",{children:"Create high-converting landing pages and craft compelling calls-to-action (CTAs)"}),e.jsx("li",{children:"Apply user experience (UX) and lead generation strategies"}),e.jsx("li",{children:"Implement conversion rate optimization (CRO) techniques"}),e.jsx("li",{children:"Follow website performance & optimization best practices"})]})},{icon:e.jsx(f,{className:"w-5 h-5 text-blue-600"}),label:"Module 3",title:"Modern Search Optimization (SEO, AEO, GEO & XEO)",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Master keyword research and search intent analysis"}),e.jsx("li",{children:"Implement traditional Search Engine Optimization (SEO) strategies"}),e.jsx("li",{children:"Master Answer Engine Optimization (AEO) for AI assistants & voice search"}),e.jsx("li",{children:"Apply Generative Engine Optimization (GEO) concepts for AI search results (SGE)"}),e.jsx("li",{children:"Develop Search Experience Optimization (XEO) across platforms"})]})},{icon:e.jsx(j,{className:"w-5 h-5 text-blue-600"}),label:"Module 4",title:"Content Marketing & Social Media Marketing",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Develop skills in content planning, creation, and distribution strategies"}),e.jsx("li",{children:"Learn content writing, blogging, and general content strategy"}),e.jsx("li",{children:"Plan organic social media campaigns and audience engagement"}),e.jsx("li",{children:"Apply brand positioning, content distribution, and community building"}),e.jsx("li",{children:"Manage content scheduling and tracking toolsets"})]})},{icon:e.jsx(c,{className:"w-5 h-5 text-blue-600"}),label:"Module 5",title:"Google Ads & Performance Marketing",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Create and optimize paid search, display, and video advertising campaigns"}),e.jsx("li",{children:"Master audience targeting, segments, and budget management"}),e.jsx("li",{children:"Set up conversion tracking and execute campaign analysis"}),e.jsx("li",{children:"Implement retargeting, remarketing campaigns & bidding strategies"}),e.jsx("li",{children:"Measure key metrics: CPC, CTR, CPA, and ROAS"})]})},{icon:e.jsx(b,{className:"w-5 h-5 text-blue-600"}),label:"Module 6",title:"Email Marketing & Marketing Automation",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Design and run effective email marketing campaigns"}),e.jsx("li",{children:"Understand list building, lead nurturing, and audience segmentation"}),e.jsx("li",{children:"Implement email marketing automation workflows & triggers"}),e.jsx("li",{children:"Deliver personalized communication and customer retention techniques"}),e.jsx("li",{children:"Analyze email metrics: open rates, CTR, and list growth"})]})},{icon:e.jsx(m,{className:"w-5 h-5 text-blue-600"}),label:"Module 7",title:"Analytics, Reporting & AI-Powered Marketing",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Measure performance using Google Analytics 4 (GA4) and Google Search Console"}),e.jsx("li",{children:"Integrate tracking tags via Google Tag Manager (GTM)"}),e.jsx("li",{children:"Analyze website traffic, user behavior, and campaign reports"}),e.jsx("li",{children:"Build client-ready reporting dashboards and attribution frameworks"}),e.jsx("li",{children:"Leverage AI tools for campaign planning, content creation, and workflow automation"})]})},{icon:e.jsx(t,{className:"w-5 h-5 text-blue-600"}),label:"Module 8",title:"Hands-On Projects & Practical Implementation",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Conduct detailed SEO audits and recommend optimizations"}),e.jsx("li",{children:"Execute AEO & GEO optimization strategies on web content"}),e.jsx("li",{children:"Build a multi-channel content strategy plan and content calendar"}),e.jsx("li",{children:"Set up and plan a simulated Google Ads performance campaign"}),e.jsx("li",{children:"Configure an automated email nurturing sequence workflow"}),e.jsx("li",{children:"Compile a complete campaign analytics and performance report"})]})}].map((i,a)=>e.jsxs("div",{className:`dm-module ${n===a?"open":""}`,onClick:()=>r(n===a?null:a),children:[e.jsx("div",{className:"summary",children:e.jsxs("div",{className:"dm-module-title",children:[e.jsx("span",{className:"mr-2 flex items-center",children:i.icon}),e.jsx("span",{className:"dm-module-label",children:i.label}),e.jsx("span",{children:i.title})]})}),n===a&&e.jsx("div",{className:"dm-module-content",children:i.content})]},a))})]}),e.jsxs(s,{className:"dm-card",children:[e.jsx("h2",{children:"Who Is This Course For?"}),e.jsx("p",{className:"mb-4 text-sm text-gray-500",children:"No prior marketing experience is required. This course is suitable for:"}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-3 mt-4",children:["Students and graduates","Working professionals","Business owners","Freelancers","Career changers","Anyone interested in digital marketing"].map((i,a)=>e.jsxs("div",{className:"flex items-center gap-3 p-3 bg-blue-50/50 rounded-2xl border border-blue-100/60 hover:bg-blue-50 transition-all duration-300",children:[e.jsx("div",{className:"w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs shrink-0",children:e.jsx(v,{size:14})}),e.jsx("span",{className:"text-sm font-semibold text-slate-800",children:i})]},a))})]}),e.jsxs(s,{className:"dm-card",children:[e.jsx("h2",{children:"Learn From Industry-Focused Mentors"}),e.jsxs("div",{className:"dm-about-text",children:[e.jsx("p",{className:"mb-4",children:"The course is guided by experienced digital marketing professionals who understand current industry practices and evolving trends. The curriculum is regularly updated to reflect changes in search behavior, advertising platforms, analytics tools, and AI-driven marketing workflows."}),e.jsx("p",{children:"The goal is to help learners build practical knowledge that can be applied in real business environments."})]})]}),e.jsxs(s,{className:"dm-card",children:[e.jsx("h2",{children:"Why Choose Aindhin?"}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4 mt-4",children:[{title:"Structured online learning",desc:"Step-by-step curriculum built for online engagement."},{title:"Beginner-friendly curriculum",desc:"No coding or prior marketing experience required."},{title:"Practical project-based approach",desc:"Apply learning directly through real-world campaign work."},{title:"Modern SEO, AEO & GEO concepts",desc:"Stay ahead with search optimization for AI engines like ChatGPT & Perplexity."},{title:"Exposure to industry-relevant tools",desc:"Gain hands-on familiarity with GA4, Google Ads, Meta Ads & more."},{title:"AI-powered marketing fundamentals",desc:"Learn to use modern AI tools to boost marketing workflows & productivity."},{title:"Live training & campaign practice",desc:"Interact with instructors and get feedback on live campaigns."},{title:"Certificate upon successful completion",desc:"Earn a certificate upon successful completion to boost your resume."}].map((i,a)=>e.jsxs("div",{className:"p-4 bg-white rounded-xl border border-slate-100 hover:border-blue-200 hover:shadow-md transition-all duration-300",children:[e.jsxs("h3",{className:"text-sm font-bold text-slate-900 mb-1 flex items-center gap-2",children:[e.jsx("span",{className:"w-2 h-2 rounded-full bg-primary shrink-0"}),i.title]}),e.jsx("p",{className:"text-xs text-gray-500 leading-relaxed",children:i.desc})]},a))})]})]}),e.jsx("aside",{className:"dm-right",children:e.jsxs(s,{className:"dm-card",children:[e.jsx("h2",{children:"Course Details"}),e.jsxs("ul",{className:"dm-detail-list",children:[e.jsxs("li",{className:"dm-detail-item",children:[e.jsx("div",{className:"dm-detail-icon",children:e.jsx(N,{size:20})}),e.jsxs("div",{className:"dm-detail-text",children:[e.jsx("strong",{children:"Duration"}),e.jsx("span",{children:"10 Weeks (60+ hours of live sessions & campaign practice)"})]})]}),e.jsxs("li",{className:"dm-detail-item",children:[e.jsx("div",{className:"dm-detail-icon",children:e.jsx(g,{size:20})}),e.jsxs("div",{className:"dm-detail-text",children:[e.jsx("strong",{children:"Skill Level"}),e.jsx("span",{children:"Beginner to Intermediate – no prior marketing required"})]})]}),e.jsxs("li",{className:"dm-detail-item",children:[e.jsx("div",{className:"dm-detail-icon",children:e.jsx(w,{size:20})}),e.jsxs("div",{className:"dm-detail-text",children:[e.jsx("strong",{children:"Includes"}),e.jsx("span",{children:"Campaign templates, live reviews & interview‑oriented guidance"})]})]}),e.jsxs("li",{className:"dm-detail-item",children:[e.jsx("div",{className:"dm-detail-icon",children:e.jsx(y,{size:20})}),e.jsxs("div",{className:"dm-detail-text",children:[e.jsx("strong",{children:"Next Batch"}),e.jsx("span",{children:"06.06.2026"})]})]}),e.jsxs("li",{className:"dm-detail-item",children:[e.jsx("div",{className:"dm-detail-icon",children:e.jsx(k,{size:20})}),e.jsxs("div",{className:"dm-detail-text",children:[e.jsx("strong",{children:"Certificate"}),e.jsx("span",{children:"Completion certificate + portfolio of growth campaigns"})]})]})]}),e.jsx("a",{href:"https://user.aindhin.com/course/AD-944b67c3bbf11c6b037beb11b0c1ada8",target:"_blank",rel:"noopener noreferrer",className:"dm-cta-btn",children:"Enroll Now & Start Learning"})]})})]})}),e.jsx(s,{className:"dm-companies dm-section",children:e.jsxs("div",{className:"dm-companies-inner",children:[e.jsx("h2",{children:"Top Companies Hiring Digital Marketers"}),e.jsx("p",{children:"Digital marketing skills are in demand across product companies, agencies, startups and e‑commerce brands."}),e.jsxs("div",{className:"dm-logo-row",children:[e.jsx("div",{className:"dm-logo-card",children:e.jsx("img",{src:D,alt:"Google"})}),e.jsx("div",{className:"dm-logo-card",children:e.jsx("img",{src:B,alt:"Microsoft"})}),e.jsx("div",{className:"dm-logo-card",children:e.jsx("img",{src:P,alt:"AWS"})}),e.jsx("div",{className:"dm-logo-card",children:e.jsx("img",{src:R,alt:"IBM"})}),e.jsx("div",{className:"dm-logo-card",children:e.jsx("img",{src:l,alt:"Meta"})}),e.jsx("div",{className:"dm-logo-card",children:e.jsx("img",{src:G,alt:"Netflix"})}),e.jsx("div",{className:"dm-logo-card",children:e.jsx("img",{src:U,alt:"Infosys"})}),e.jsx("div",{className:"dm-logo-card",children:e.jsx("img",{src:W,alt:"Accenture"})})]})]})}),e.jsx(s,{className:"dm-highlights dm-section",children:e.jsxs("div",{className:"dm-highlights-inner",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"dm-highlights-heading",children:[e.jsx("h2",{children:"What You Will Achieve in This Digital Marketing Program"}),e.jsx("p",{children:"Build practical digital marketing skills that help you plan, execute, and measure campaigns across modern marketing channels."})]}),e.jsxs("div",{className:"dm-highlight-grid",children:[e.jsxs("div",{className:"dm-highlight-card",children:[e.jsx("div",{className:"dm-highlight-icon",children:e.jsx(A,{size:24})}),e.jsx("h3",{children:"Search & Visibility Optimization"}),e.jsx("p",{children:"Learn SEO, AEO, GEO, and XEO strategies to improve visibility across search engines and AI-powered search experiences."})]}),e.jsxs("div",{className:"dm-highlight-card",children:[e.jsx("div",{className:"dm-highlight-icon",children:e.jsx(c,{size:24})}),e.jsx("h3",{children:"Multi-Channel Marketing Skills"}),e.jsx("p",{children:"Gain hands-on knowledge in content marketing, social media marketing, Google Ads, email marketing, and performance marketing."})]}),e.jsxs("div",{className:"dm-highlight-card",children:[e.jsx("div",{className:"dm-highlight-icon",children:e.jsx(g,{size:24})}),e.jsx("h3",{children:"Analytics & Data-Driven Decisions"}),e.jsx("p",{children:"Use Google Analytics 4, Google Search Console, and reporting tools to track performance and optimize campaigns with confidence."})]}),e.jsxs("div",{className:"dm-highlight-card",children:[e.jsx("div",{className:"dm-highlight-icon",children:e.jsx(m,{size:24})}),e.jsx("h3",{children:"AI-Powered Marketing Workflows"}),e.jsx("p",{children:"Understand how modern marketers use AI tools for research, content creation, campaign planning, automation, and productivity."})]}),e.jsxs("div",{className:"dm-highlight-card",children:[e.jsx("div",{className:"dm-highlight-icon",children:e.jsx(M,{size:24})}),e.jsx("h3",{children:"Real-World Project Experience"}),e.jsx("p",{children:"Apply your learning through practical projects including SEO audits, content strategies, paid advertising campaigns, and analytics reporting."})]}),e.jsxs("div",{className:"dm-highlight-card",children:[e.jsx("div",{className:"dm-highlight-icon",children:e.jsx(t,{size:24})}),e.jsx("h3",{children:"Career & Business Readiness"}),e.jsx("p",{children:"Build a portfolio of work, gain exposure to industry-standard tools, and develop skills valued by businesses, agencies, startups, and entrepreneurs."})]})]})]}),e.jsx("div",{className:"dm-highlights-visual",children:e.jsxs("div",{className:"dm-dashboard",children:[e.jsxs("div",{className:"dm-dashboard-header",children:[e.jsx("span",{children:"Campaign Performance Snapshot"}),e.jsxs("div",{className:"dm-dashboard-dots",children:[e.jsx("span",{}),e.jsx("span",{}),e.jsx("span",{})]})]}),e.jsxs("div",{className:"dm-dashboard-graph",children:[e.jsx("div",{className:"dm-dashboard-bar"}),e.jsx("div",{className:"dm-dashboard-bar"}),e.jsx("div",{className:"dm-dashboard-bar"}),e.jsx("div",{className:"dm-dashboard-bar"}),e.jsx("div",{className:"dm-dashboard-bar"})]}),e.jsxs("div",{className:"dm-dashboard-tags",children:[e.jsx("span",{children:"Impressions"}),e.jsx("span",{children:"Clicks"}),e.jsx("span",{children:"Conversions"}),e.jsx("span",{children:"ROAS"})]})]})})]})}),e.jsx(s,{className:"dm-tools dm-section",children:e.jsxs("div",{className:"dm-tools-inner",children:[e.jsx("h2",{children:"Tools & Platforms You Will Use"}),e.jsx("p",{children:"Get hands‑on with the most widely used tools in modern digital marketing teams."}),e.jsxs("div",{className:"dm-tools-grid",children:[e.jsxs("div",{className:"dm-tools-card",children:[e.jsx("img",{className:"dm-tools-logo",src:h,alt:"Google Ads"}),e.jsx("span",{children:"Google Ads"})]}),e.jsxs("div",{className:"dm-tools-card",children:[e.jsx("img",{className:"dm-tools-logo",src:x,alt:"Google Analytics"}),e.jsx("span",{children:"Google Analytics 4"})]}),e.jsxs("div",{className:"dm-tools-card",children:[e.jsx("img",{className:"dm-tools-logo",src:l,alt:"Meta Ads"}),e.jsx("span",{children:"Meta (Facebook/Instagram) Ads"})]}),e.jsxs("div",{className:"dm-tools-card",children:[e.jsx("img",{className:"dm-tools-logo",src:L,alt:"LinkedIn"}),e.jsx("span",{children:"LinkedIn Campaign Manager"})]}),e.jsxs("div",{className:"dm-tools-card",children:[e.jsx("img",{className:"dm-tools-logo",src:I,alt:"Mailchimp"}),e.jsx("span",{children:"Mailchimp / Email Tools"})]}),e.jsxs("div",{className:"dm-tools-card",children:[e.jsx("img",{className:"dm-tools-logo",src:T,alt:"Canva"}),e.jsx("span",{children:"Canva (Creatives)"})]})]})]})}),e.jsx(s,{className:"dm-more dm-section",children:e.jsxs("div",{className:"dm-more-inner",children:[e.jsxs("div",{className:"dm-more-header",children:[e.jsx("h2",{children:"Roles & Learning Journey"}),e.jsx("p",{children:"See how this course maps to growth‑focused roles and how your skills evolve over 10 weeks."})]}),e.jsxs("div",{className:"dm-more-grid",children:[e.jsxs("div",{className:"dm-more-card",children:[e.jsxs("div",{className:"dm-more-top",children:[e.jsx("div",{className:"dm-more-icon",children:e.jsx(t,{size:20})}),e.jsxs("div",{children:[e.jsx("h3",{className:"dm-more-title",children:"Channel Toolset"}),e.jsx("p",{className:"dm-more-text",children:"Use Google Ads, Meta Ads and GA4 together to plan, launch and analyze full‑funnel campaigns."})]})]}),e.jsxs("div",{className:"dm-tool-logos",children:[e.jsx("img",{className:"dm-tool-logo",src:h,alt:"Google Ads"}),e.jsx("img",{className:"dm-tool-logo",src:x,alt:"Google Analytics"}),e.jsx("img",{className:"dm-tool-logo",src:l,alt:"Meta"})]})]}),e.jsxs("div",{className:"dm-more-card",children:[e.jsxs("div",{className:"dm-more-top",children:[e.jsx("div",{className:"dm-more-icon",children:e.jsx(o,{size:20})}),e.jsxs("div",{children:[e.jsx("h3",{className:"dm-more-title",children:"Career Roles You Can Target"}),e.jsx("p",{className:"dm-more-text",children:"Align your projects and portfolio with the titles most commonly used in digital marketing teams."})]})]}),e.jsxs("div",{className:"dm-roles-image",children:[e.jsx("span",{className:"dm-role-tag",children:"Digital Marketing Executive"}),e.jsx("span",{className:"dm-role-tag",children:"Performance Marketing Analyst"}),e.jsx("span",{className:"dm-role-tag",children:"SEO / SEM Specialist"}),e.jsx("span",{className:"dm-role-tag",children:"Social Media Marketer"}),e.jsx("span",{className:"dm-role-tag",children:"Growth Marketer (Entry‑level)"})]})]}),e.jsxs("div",{className:"dm-more-card",children:[e.jsxs("div",{className:"dm-more-top",children:[e.jsx("div",{className:"dm-more-icon",children:e.jsx(E,{size:20})}),e.jsxs("div",{children:[e.jsx("h3",{className:"dm-more-title",children:"Your 10‑Week Learning Journey"}),e.jsx("p",{className:"dm-more-text",children:"A step‑by‑step plan that grows your skills from fundamentals to campaign‑ready marketer."})]})]}),e.jsxs("div",{className:"dm-journey",children:[e.jsx("div",{className:"dm-journey-step",children:"Weeks 1–2: Fundamentals, funnels & marketing strategy"}),e.jsx("div",{className:"dm-journey-step",children:"Weeks 3–4: Website, content & SEO basics"}),e.jsx("div",{className:"dm-journey-step",children:"Weeks 5–7: Paid ads & social media campaigns"}),e.jsx("div",{className:"dm-journey-step",children:"Weeks 8–10: Email, automation, analytics & capstone growth project"})]})]})]})]})}),e.jsx(z,{title:"Frequently Asked Questions",subtitle:"Find answers to some of the most common questions about the course.",faqs:[{question:"Is this Digital Marketing Certificate Course suitable for beginners?",answer:"Yes. The course is designed for beginners as well as learners who want to strengthen their digital marketing knowledge. No prior marketing experience is required."},{question:"Will I receive an Digital Marketing Certificate after completing the training?",answer:"Yes. Participants who successfully complete the program will receive an Aindhin Digital Marketing Certificate."},{question:"What topics are covered in this course?",answer:"The curriculum covers landing page designing, SEO, AEO, GEO, XEO, Google Ads, Social Media Marketing, Content Marketing, Email Marketing, Marketing Automation, Analytics, Conversion Optimization, and AI-powered marketing strategies."},{question:"Is this course conducted online?",answer:"Yes. This is a structured online digital marketing course delivered through live sessions, practical activities, and guided learning exercises."},{question:"Do I need coding knowledge to get started with digital marketing?",answer:"No. Coding knowledge is not required. The course focuses on marketing concepts, tools, strategies, analytics, and practical implementation."}]})]})]})};export{ae as default};
