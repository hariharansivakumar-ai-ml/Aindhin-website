const o="/assets/notion_logo-DpZXSEzf.svg";export{o as N};
