const o="/assets/linkedin_logo-CNH-Tu1j.svg";export{o as L};
