const o="/assets/google-DzpxA-yY.svg";export{o as G};
