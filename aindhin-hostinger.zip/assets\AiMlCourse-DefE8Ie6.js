import{r as n,j as e,G as m,n as x,B as o,U as h,ak as p,K as g,J as f,a3 as u,ah as j,aw as b,aU as N,m as y}from"./vendor-BkeoPC-K.js";import{A as v}from"./ai_ml_hero-CtA4tHV5.js";import{P as t}from"./python_logo-zopixIJC.js";import{J as w}from"./jupyter_logo-DRZQd1Ak.js";import{V as k}from"./vscode_logo-D7qh9J9J.js";import{G as A}from"./git_logo-sV4qme_O.js";import{G as L}from"./github_logo-CV1RcFOD.js";import{N as I,S as d,T as c}from"./tensorflow_logo-F6zoNSDE.js";import{P as M}from"./pandas_logo-CE__fUIg.js";import{G as z}from"./google_logo-DsnDYeGk.js";import{M as C}from"./microsoft_logo-DpTQl3b8.js";import{A as S}from"./aws_logo-BKbZjplO.js";import{I as P}from"./ibm_logo-ZbxQxZt0.js";import{M as E,N as T}from"./netflix_logo-CTGmZti7.js";import{I as R}from"./infosys_logo-HQ5x-L0e.js";import{A as D}from"./accenture_logo-DYYk3RN0.js";const O="/assets/matplotlib-CWJXC9nh.svg",i=({children:l,className:r})=>{const a=n.useRef(null),s=N(a,{once:!0,margin:"-100px"});return e.jsx(y.div,{ref:a,initial:{opacity:0,y:24},animate:s?{opacity:1,y:0}:{opacity:0,y:24},transition:{duration:.7,ease:"easeOut"},className:r,children:l})},ee=()=>{n.useEffect(()=>{document.title="Best AI and Machine Learning Course in India | Aindhin";const a=document.querySelector('meta[name="description"]');a&&a.setAttribute("content","Learn Artificial Intelligence and Machine Learning with live projects, mentorship, certification, and placement support at Aindhin. Enroll online today.")},[]);const[l,r]=n.useState(0);return e.jsxs("div",{className:"ai-ml-page font-sans text-slate-900 bg-blue-50 w-full",children:[e.jsx("style",{children:`
                /* ===== AI & ML Course Page (scoped) ===== */
                .ai-ml-page{
                  font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
                  color:#0f172a;
                  background:#e0f2fe; /* light blue theme */
                  width:100%;
                }
                .ai-ml-page *{box-sizing:border-box;}
                
                /* HERO */
                .ai-ml-hero{
                  color:#fff;
                  background:
                    linear-gradient(120deg,rgba(15,23,42,.95),rgba(30,64,175,.7)),
                    url(${v})
                    center/cover no-repeat;
                  padding:70px 20px;
                  display:flex;
                  align-items:center;
                  justify-content:center;
                }
                .ai-ml-hero-content{
                  max-width:900px;
                  text-align:left;
                }
                .ai-ml-badge{
                  display:inline-block;
                  padding:4px 12px;
                  border-radius:999px;
                  background:rgba(15,23,42,.7);
                  border:1px solid rgba(248,250,252,.4);
                  font-size:12px;
                  letter-spacing:.08em;
                  text-transform:uppercase;
                  margin-bottom:10px;
                }
                .fs-hero-title{
                  color:#fff;
                  font-size:64px;
                  line-height:1.1;
                  margin:0 0 14px;
                }
                .fs-hero-sub{
                  font-size:20px;
                  max-width:720px;
                  color:#e5e7eb;
                  margin:0 0 16px;
                }
                .ai-ml-hero-meta{
                  display:flex;
                  flex-wrap:wrap;
                  gap:10px 18px;
                  font-size:13px;
                  color:#e5e7eb;
                }
                .ai-ml-hero-meta span::before{
                  content:"• ";
                  color:#fde68a;
                  font-weight:700;
                }
                
                /* MAIN */
                .ai-ml-main{padding:40px 20px 50px;}
                .ai-ml-main-inner{
                  max-width:1160px;
                  margin:0 auto;
                  display:grid;
                  grid-template-columns:minmax(0,2fr) minmax(0,1.1fr);
                  gap:24px;
                }
                .ai-ml-left,.ai-ml-right{
                  display:flex;
                  flex-direction:column;
                  gap:16px;
                }
                
                /* CARDS */
                .ai-ml-card{
                  background:#ffffff;
                  border-radius:18px;
                  padding:20px 22px;
                  box-shadow:0 10px 25px rgba(15,23,42,.08);
                }
                .ai-ml-card h2{
                  font-size:18px;
                  margin:0 0 10px;
                  color:#db2777;
                }
                .ai-ml-about-text{
                  font-size:14px;
                  color:#4b5563;
                  line-height:1.6;
                }
                
                /* SYLLABUS */
                .ai-ml-module{
                  border:1px solid #e5e7eb;
                  border-radius:12px;
                  background:#f9fafb;
                  margin-top:8px;
                  overflow:hidden;
                }
                .ai-ml-module .summary{
                  list-style:none;
                  padding:10px 14px;
                  cursor:pointer;
                  display:flex;
                  justify-content:space-between;
                  align-items:center;
                  font-size:14px;
                  font-weight:600;
                }
                .ai-ml-module .summary::after{
                  content:"▾";
                  font-size:12px;
                  color:#9ca3af;
                  transition:transform .2s;
                }
                .ai-ml-module.open .summary::after{transform:rotate(-180deg);}
                .ai-ml-module-title{
                  display:flex;
                  gap:8px;
                  flex-wrap:wrap;
                  align-items:baseline;
                }
                .ai-ml-module-label{
                  font-size:11px;
                  text-transform:uppercase;
                  letter-spacing:.08em;
                  color:#111827;   /* dark text */
                  font-weight:700; /* bold */
                }
                .ai-ml-module-content{
                  padding:0 14px 10px 24px;
                  font-size:13px;
                  color:#4b5563;
                }
                .ai-ml-module-content ul{
                  margin:0;
                  padding-left:16px;
                }
                .ai-ml-module-content li{margin-bottom:4px;}
                
                /* RIGHT-COLUMN DETAILS */
                .ai-ml-detail-list{
                  list-style:none;
                  padding:0;
                  margin:0 0 16px;
                  font-size:14px;
                }
                .ai-ml-detail-item{
                  display:flex;
                  gap:10px;
                  margin-bottom:10px;
                }
                .ai-ml-detail-icon{
                  width:26px;
                  height:26px;
                  border-radius:999px;
                  background:#e0f2fe;
                  display:flex;
                  align-items:center;
                  justify-content:center;
                  font-size:13px;
                  color:#1d4ed8;
                  flex-shrink:0;
                }
                .ai-ml-detail-text strong{
                  display:block;
                  font-weight:600;
                  color:#111827;
                }
                .ai-ml-detail-text span{
                  font-size:13px;
                  color:#4b5563;
                }
                
                /* CTA BUTTON */
                .ai-ml-cta-btn{
                  display:block;
                  width:100%;
                  border-radius:999px;
                  padding:11px 16px;
                  border:none;
                  text-align:center;
                  text-decoration:none;
                  background:linear-gradient(135deg,#38bdf8,#6366f1);
                  color:#fff !important;
                  font-weight:600;
                  font-size:15px;
                  box-shadow:0 14px 30px rgba(37,99,235,.4);
                  transition:transform .15s,box-shadow .15s,filter .15s,color .15s;
                }
                .ai-ml-cta-btn:hover{
                  transform:translateY(-1px);
                  filter:brightness(1.04);
                  box-shadow:0 18px 40px rgba(37,99,235,.55);
                  color:#fff !important;
                }
                
                /* TOP COMPANIES */
                .ai-ml-companies{
                  background:#e0f2fe;
                  padding:40px 20px 40px;
                }
                .ai-ml-companies-inner{
                  max-width:1160px;
                  margin:0 auto;
                  text-align:center;
                }
                .ai-ml-companies h2{
                  font-size:20px;
                  margin:0 0 6px;
                  color:#0f172a;
                }
                .ai-ml-companies p{
                  margin:0 0 20px;
                  font-size:14px;
                  color:#4b5563;
                }
                .ai-ml-logo-row{
                  display:flex;
                  flex-wrap:wrap;
                  justify-content:center;
                  gap:18px;
                }
                .ai-ml-logo-card{
                  width:130px;
                  height:62px;
                  border-radius:14px;
                  background:#ffffff;
                  display:flex;
                  align-items:center;
                  justify-content:center;
                  box-shadow:0 8px 18px rgba(15,23,42,.08);
                  transition:transform .18s,box-shadow .18s;
                }
                .ai-ml-logo-card img{
                  max-height:40px;
                  max-width:100%;
                }
                .ai-ml-logo-card:hover{
                  transform:translateY(-3px);
                  box-shadow:0 14px 30px rgba(15,23,42,.16);
                }
                
                /* EXTRA COURSE DETAILS SECTION (ACHIEVEMENTS) */
                .ai-ml-highlights{
                  background:#e0f2fe;
                  padding:10px 20px 50px;
                }
                .ai-ml-highlights-inner{
                  max-width:1160px;
                  margin:0 auto;
                  display:grid;
                  grid-template-columns:minmax(0,1.7fr) minmax(0,1.1fr);
                  gap:28px;
                  align-items:center;
                }
                .ai-ml-highlights-heading{
                  margin-bottom:12px;
                }
                .ai-ml-highlights-heading h2{
                  font-size:20px;
                  margin:0 0 6px;
                  color:#0f172a;
                }
                .ai-ml-highlights-heading p{
                  margin:0;
                  font-size:14px;
                  color:#4b5563;
                }
                .ai-ml-highlight-grid{
                  margin-top:18px;
                  display:grid;
                  grid-template-columns:repeat(3,minmax(0,1fr));
                  gap:14px;
                }
                .ai-ml-highlight-card{
                  background:#ffffff;
                  border-radius:16px;
                  padding:14px 12px;
                  box-shadow:0 10px 24px rgba(15,23,42,.08);
                }
                .ai-ml-highlight-icon{
                  width:38px;
                  height:38px;
                  border-radius:999px;
                  background:linear-gradient(135deg,#38bdf8,#6366f1);
                  display:flex;
                  align-items:center;
                  justify-content:center;
                  color:#fff;
                  font-size:20px;
                  margin-bottom:8px;
                }
                .ai-ml-highlight-card h3{
                  font-size:14px;
                  margin:0 0 4px;
                  color:#0f172a;
                }
                .ai-ml-highlight-card p{
                  font-size:13px;
                  margin:0;
                  color:#4b5563;
                }
                
                /* representation "image" block */
                .ai-ml-highlights-visual{
                  display:flex;
                  justify-content:center;
                }
                .ai-ml-dashboard{
                  width:100%;
                  max-width:340px;
                  background:#ffffff;
                  border-radius:20px;
                  padding:14px 14px 18px;
                  box-shadow:0 18px 40px rgba(37,99,235,.25);
                  position:relative;
                  overflow:hidden;
                }
                .ai-ml-dashboard-header{
                  display:flex;
                  justify-content:space-between;
                  align-items:center;
                  margin-bottom:10px;
                  font-size:12px;
                  color:#0f172a;
                }
                .ai-ml-dashboard-dots{
                  display:flex;
                  gap:4px;
                }
                .ai-ml-dashboard-dots span{
                  width:7px;
                  height:7px;
                  border-radius:999px;
                  background:#e5e7eb;
                }
                .ai-ml-dashboard-graph{
                  display:flex;
                  gap:6px;
                  align-items:flex-end;
                  height:90px;
                  margin-bottom:12px;
                }
                .ai-ml-dashboard-bar{
                  flex:1;
                  border-radius:8px 8px 2px 2px;
                  background:linear-gradient(180deg,#38bdf8,#1d4ed8);
                }
                .ai-ml-dashboard-bar:nth-child(2){height:55%;}
                .ai-ml-dashboard-bar:nth-child(3){height:80%;}
                .ai-ml-dashboard-bar:nth-child(4){height:40%;}
                .ai-ml-dashboard-bar:nth-child(5){height:70%;}
                .ai-ml-dashboard-bar:nth-child(1){height:30%;}
                .ai-ml-dashboard-tags{
                  display:flex;
                  flex-wrap:wrap;
                  gap:6px;
                  font-size:11px;
                }
                .ai-ml-dashboard-tags span{
                  padding:3px 7px;
                  border-radius:999px;
                  background:#eff6ff;
                  color:#1d4ed8;
                }
                
                /* === TOOLS SECTION (logos of tools used) === */
                .ai-ml-tools{
                  background:#e0f2fe;
                  padding:0 20px 50px;
                }
                .ai-ml-tools-inner{
                  max-width:1160px;
                  margin:0 auto;
                  text-align:center;
                }
                .ai-ml-tools-inner h2{
                  font-size:20px;
                  margin:0 0 6px;
                  color:#0f172a;
                }
                .ai-ml-tools-inner p{
                  margin:0 0 20px;
                  font-size:14px;
                  color:#4b5563;
                }
                .ai-ml-tools-grid{
                  display:flex;
                  flex-wrap:wrap;
                  justify-content:center;
                  gap:16px;
                }
                .ai-ml-tools-card{
                  width:140px;
                  height:90px;
                  border-radius:16px;
                  background:#ffffff;
                  box-shadow:0 10px 26px rgba(15,23,42,.12);
                  display:flex;
                  flex-direction:column;
                  align-items:center;
                  justify-content:center;
                  padding:8px;
                }
                .ai-ml-tools-logo{
                  max-height:36px;
                  max-width:90px;
                  margin-bottom:4px;
                }
                .ai-ml-tools-card span{
                  font-size:12px;
                  color:#111827;
                }
                
                /* === MORE COURSE DETAILS SECTION (roles, journey, mini-images) === */
                .ai-ml-more{
                  background:#e0f2fe;
                  padding:0 20px 50px;
                }
                .ai-ml-more-inner{
                  max-width:1160px;
                  margin:0 auto;
                }
                .ai-ml-more-header{
                  text-align:center;
                  margin-bottom:20px;
                }
                .ai-ml-more-header h2{
                  font-size:20px;
                  margin:0 0 6px;
                  color:#0f172a;
                }
                .ai-ml-more-header p{
                  margin:0;
                  font-size:14px;
                  color:#4b5563;
                }
                .ai-ml-more-grid{
                  display:grid;
                  grid-template-columns:repeat(3,minmax(0,1fr));
                  gap:18px;
                }
                .ai-ml-more-card{
                  background:#ffffff;
                  border-radius:18px;
                  padding:16px 14px;
                  box-shadow:0 12px 30px rgba(15,23,42,.12);
                  display:flex;
                  flex-direction:column;
                  gap:8px;
                }
                .ai-ml-more-top{
                  display:flex;
                  align-items:flex-start;
                  gap:8px;
                }
                .ai-ml-more-icon{
                  width:32px;
                  height:32px;
                  border-radius:999px;
                  background:linear-gradient(135deg,#22c55e,#14b8a6);
                  color:#fff;
                  display:flex;
                  align-items:center;
                  justify-content:center;
                  font-size:18px;
                }
                .ai-ml-more-title{
                  font-size:15px;
                  font-weight:600;
                  margin:0;
                  color:#0f172a;
                }
                .ai-ml-more-text{
                  font-size:13px;
                  color:#4b5563;
                  margin:0;
                }
                
                /* Centered, small tool logos in tools card */
                .ai-ml-tool-logos{
                  margin-top:12px;
                  display:flex;
                  flex-wrap:wrap;
                  gap:10px;
                  align-items:center;
                  justify-content:center; /* center horizontally */
                  width:100%;
                }
                .ai-ml-tool-logo{
                  max-height:32px;
                  width:auto;
                  filter:drop-shadow(0 2px 4px rgba(15,23,42,.18));
                }
                .ai-ml-tool-logos img{
                  max-height:32px !important;
                  width:auto !important;
                  object-fit:contain;
                }
                
                .ai-ml-roles-image{
                  margin-top:8px;
                  display:flex;
                  flex-wrap:wrap;
                  gap:6px;
                }
                .ai-ml-role-tag{
                  padding:4px 8px;
                  border-radius:999px;
                  font-size:11px;
                  background:#eff6ff;
                  color:#1d4ed8;
                }
                .ai-ml-journey{
                  margin-top:8px;
                  border-left:2px solid #bfdbfe;
                  padding-left:10px;
                }
                .ai-ml-journey-step{
                  position:relative;
                  padding-left:10px;
                  margin-bottom:6px;
                  font-size:12px;
                  color:#4b5563;
                }
                .ai-ml-journey-step::before{
                  content:"";
                  position:absolute;
                  left:-11px;
                  top:5px;
                  width:8px;
                  height:8px;
                  border-radius:999px;
                  background:#38bdf8;
                }
                
                /* ENQUIRY / FORM SECTION */
                .ai-ml-enquiry{
                  background:linear-gradient(135deg,#dbeafe,#e0f2fe);
                  padding:40px 20px 50px;
                }
                .ai-ml-enquiry-inner{
                  max-width:900px;
                  margin:0 auto;
                }
                .ai-ml-enquiry-card{
                  background:#ffffff;
                  border-radius:22px;
                  padding:24px 22px 18px;
                  box-shadow:0 18px 40px rgba(37,99,235,.2);
                  border-top:4px solid #38bdf8;
                }
                .ai-ml-enquiry-header{
                  display:flex;
                  align-items:flex-start;
                  gap:10px;
                  margin-bottom:10px;
                }
                .ai-ml-enquiry-icon{
                  width:32px;
                  height:32px;
                  border-radius:999px;
                  background:radial-gradient(circle at 30% 20%,#38bdf8,#6366f1);
                  display:flex;
                  align-items:center;
                  justify-content:center;
                  color:#fff;
                  font-size:18px;
                }
                .ai-ml-enquiry-title{
                  font-size:18px;
                  font-weight:700;
                  margin:0;
                  color:#0f172a;
                }
                .ai-ml-enquiry-text{
                  font-size:14px;
                  color:#4b5563;
                  margin:2px 0 12px;
                }
                
                /* RESPONSIVE */
                @media (max-width:900px){
                  .ai-ml-hero{padding:50px 18px;}
                  .fs-hero-title{font-size:48px;}
                  .ai-ml-main-inner{
                    grid-template-columns:minmax(0,1fr);
                  }
                  .ai-ml-highlights-inner{
                    grid-template-columns:minmax(0,1fr);
                  }
                  .ai-ml-more-grid{
                    grid-template-columns:minmax(0,1fr);
                  }
                }
                @media (max-width:640px){
                  .ai-ml-hero{padding:38px 16px;}
                  .ai-ml-hero-meta{flex-direction:column;}
                  .ai-ml-highlight-grid{
                    grid-template-columns:minmax(0,1fr);
                  }
                }
            `}),e.jsx(i,{className:"ai-ml-hero ai-ml-section",children:e.jsxs("div",{className:"flex flex-col md:flex-row justify-between items-start max-w-[1200px] mx-auto w-full gap-8",children:[e.jsxs("div",{className:"ai-ml-hero-content",children:[e.jsx("span",{className:"ai-ml-badge",children:"Artificial Intelligence"}),e.jsx("h1",{className:"fs-hero-title",children:"Master AI & Machine Learning: From Fundamentals to Professional Industry Applications"}),e.jsx("p",{className:"fs-hero-sub",children:"Learn the foundations of AI, master core machine learning algorithms, and build production‑ready models that solve real business problems. Start from the basics and grow into an industry‑ready AI & ML engineer."}),e.jsxs("div",{className:"ai-ml-hero-meta",children:[e.jsx("span",{children:"No prior ML experience required"}),e.jsx("span",{children:"Hands‑on projects with real datasets"}),e.jsx("span",{children:"Capstone project for your portfolio"})]})]}),e.jsx("div",{className:"flex-shrink-0 w-full md:w-auto mt-6 md:mt-12",children:e.jsxs("a",{href:"https://user.aindhin.com/course/AD-944b67c3bbf11c65037beb11b0c1ada8",target:"_blank",rel:"noopener noreferrer",className:"inline-flex items-center justify-center gap-2 px-8 py-4 bg-primary text-white font-bold rounded-full shadow-[0_10px_30px_rgba(37,99,235,0.4)] hover:shadow-[0_20px_40px_rgba(37,99,235,0.6)] hover:-translate-y-1 transition-all duration-300 font-inter text-lg w-full md:w-auto animate-color-blink",children:["Enroll Now ",e.jsx(m,{className:"w-5 h-5"})]})})]})}),e.jsx("main",{className:"ai-ml-main ai-ml-section",children:e.jsxs("div",{className:"ai-ml-main-inner",children:[e.jsxs("div",{className:"ai-ml-left",children:[e.jsxs(i,{className:"ai-ml-card",children:[e.jsx("h2",{children:"About This Course"}),e.jsxs("div",{className:"ai-ml-about-text",children:[e.jsx("p",{className:"mb-4",children:"This Artificial Intelligence and Machine Learning course takes you from Python fundamentals and essential math concepts to building real-world AI solutions. You will learn how machine learning algorithms work, how to prepare and analyze data, and how to evaluate, optimize, and improve model performance."}),e.jsx("p",{className:"mb-6",children:"As you progress, you will work with supervised and unsupervised learning, deep learning, computer vision, and basic NLP applications. By the end of this AI and ML certification course, you will complete several end-to-end projects and be ready for industry-level Artificial Intelligence and Machine Learning roles."}),e.jsx("h3",{className:"text-lg font-bold text-slate-800 mt-6 mb-2",children:"What You Will Achieve in This AI & ML Program"}),e.jsx("p",{className:"mb-4",children:"Build strong AI and Machine Learning skills, work on live industry projects, and become job-ready for top career opportunities in Data Science and Artificial Intelligence."}),e.jsxs("div",{className:"space-y-4 mt-4",children:[e.jsxs("div",{children:[e.jsx("strong",{className:"text-slate-800 block",children:"Deep Conceptual Clarity"}),"Understand Artificial Intelligence and Machine Learning algorithms in depth so you can analyze, optimize, and explain models with confidence in real-world projects."]}),e.jsxs("div",{children:[e.jsx("strong",{className:"text-slate-800 block",children:"Hands on Coding Skills"}),"Learn Python programming, use NumPy and Pandas for data analysis, and build Machine Learning models using Scikit-learn, TensorFlow, and industry-standard tools."]}),e.jsxs("div",{children:[e.jsx("strong",{className:"text-slate-800 block",children:"Real-World Projects"}),"Work with real-world datasets, build and evaluate Machine Learning models, deploy them as APIs, and create portfolio-ready projects that showcase your AI and Data Science skills."]}),e.jsxs("div",{children:[e.jsx("strong",{className:"text-slate-800 block",children:"Industry Applications"}),"Explore how Artificial Intelligence is used in healthcare, finance, e-commerce, digital marketing, automation, and modern business decision-making."]}),e.jsxs("div",{children:[e.jsx("strong",{className:"text-slate-800 block",children:"Expert Mentorship and Learning Community"}),"Get live mentor support, doubt-clearing sessions, career guidance, and peer learning to stay motivated and confident throughout your AI learning journey."]})]})]})]}),e.jsxs(i,{className:"ai-ml-card",children:[e.jsx("h2",{children:"Syllabus Covered"}),e.jsx("div",{className:"flex flex-col gap-4",children:[{label:"Module 1",title:"Foundations of AI & Python",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Introduction to AI, ML and industry use-cases"}),e.jsx("li",{children:"Python essentials for data & ML (NumPy, Pandas, Matplotlib)"}),e.jsx("li",{children:"Statistics & linear algebra for ML intuition"}),e.jsx("li",{children:"Exploratory Data Analysis (EDA) on real datasets"})]})},{label:"Module 2",title:"Core Machine Learning Algorithms",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Regression & classification models (LR, k-NN, trees, forests)"}),e.jsx("li",{children:"Model evaluation & cross-validation"}),e.jsx("li",{children:"Feature engineering, scaling and handling missing data"}),e.jsx("li",{children:"Unsupervised learning: clustering & dimensionality reduction"})]})},{label:"Module 3",title:"Deep Learning & Neural Networks",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Neural network basics & backpropagation"}),e.jsx("li",{children:"Building models with TensorFlow / Keras"}),e.jsx("li",{children:"Image classification with CNNs"}),e.jsx("li",{children:"Intro to NLP and word embeddings"})]})},{label:"Module 4",title:"Industry Applications & Capstone",content:e.jsxs("ul",{children:[e.jsx("li",{children:"Case studies from finance, healthcare and e-commerce"}),e.jsx("li",{children:"End-to-end ML pipeline: data, training, deployment"}),e.jsx("li",{children:"Serving models via simple REST APIs & MLOps basics"}),e.jsx("li",{children:"Capstone project: design, build and present an AI solution"})]})}].map((a,s)=>e.jsxs("div",{className:`ai-ml-module ${l===s?"open":""}`,onClick:()=>r(l===s?null:s),children:[e.jsx("div",{className:"summary",children:e.jsxs("div",{className:"ai-ml-module-title",children:[e.jsx("span",{className:"ai-ml-module-label",children:a.label}),e.jsx("span",{children:a.title})]})}),l===s&&e.jsx("div",{className:"ai-ml-module-content",children:a.content})]},s))})]})]}),e.jsx("aside",{className:"ai-ml-right",children:e.jsxs(i,{className:"ai-ml-card",children:[e.jsx("h2",{children:"Course Details"}),e.jsxs("ul",{className:"ai-ml-detail-list",children:[e.jsxs("li",{className:"ai-ml-detail-item",children:[e.jsx("div",{className:"ai-ml-detail-icon",children:e.jsx(x,{size:20})}),e.jsxs("div",{className:"ai-ml-detail-text",children:[e.jsx("strong",{children:"Duration"}),e.jsx("span",{children:"16 Weeks (120+ hours of guided learning)"})]})]}),e.jsxs("li",{className:"ai-ml-detail-item",children:[e.jsx("div",{className:"ai-ml-detail-icon",children:e.jsx(o,{size:20})}),e.jsxs("div",{className:"ai-ml-detail-text",children:[e.jsx("strong",{children:"Skill Level"}),e.jsx("span",{children:"Beginner to Intermediate (basic coding helpful)"})]})]}),e.jsxs("li",{className:"ai-ml-detail-item",children:[e.jsx("div",{className:"ai-ml-detail-icon",children:e.jsx(h,{size:20})}),e.jsxs("div",{className:"ai-ml-detail-text",children:[e.jsx("strong",{children:"Includes"}),e.jsx("span",{children:"Live mentorship, doubt sessions & projects"})]})]}),e.jsxs("li",{className:"ai-ml-detail-item",children:[e.jsx("div",{className:"ai-ml-detail-icon",children:e.jsx(p,{size:20})}),e.jsxs("div",{className:"ai-ml-detail-text",children:[e.jsx("strong",{children:"Next Batch"}),e.jsx("span",{children:"Batch Completed - Next Batch Coming Soon"})]})]}),e.jsxs("li",{className:"ai-ml-detail-item",children:[e.jsx("div",{className:"ai-ml-detail-icon",children:e.jsx(g,{size:20})}),e.jsxs("div",{className:"ai-ml-detail-text",children:[e.jsx("strong",{children:"Certificate"}),e.jsx("span",{children:"Industry‑recognized completion certificate"})]})]})]}),e.jsx("a",{href:"https://user.aindhin.com/course/AD-944b67c3bbf11c65037beb11b0c1ada8",target:"_blank",rel:"noopener noreferrer",className:"ai-ml-cta-btn",children:"Enroll Now & Start Learning"})]})})]})}),e.jsx(i,{className:"ai-ml-companies ai-ml-section",children:e.jsxs("div",{className:"ai-ml-companies-inner",children:[e.jsx("h2",{children:"Top Companies Hiring for AI & ML Roles"}),e.jsx("p",{children:"Skills from this course are in demand across leading global technology and IT services companies."}),e.jsxs("div",{className:"ai-ml-logo-row",children:[e.jsx("div",{className:"ai-ml-logo-card",children:e.jsx("img",{src:z,alt:"Google"})}),e.jsx("div",{className:"ai-ml-logo-card",children:e.jsx("img",{src:C,alt:"Microsoft"})}),e.jsx("div",{className:"ai-ml-logo-card",children:e.jsx("img",{src:S,alt:"Amazon Web Services"})}),e.jsx("div",{className:"ai-ml-logo-card",children:e.jsx("img",{src:P,alt:"IBM"})}),e.jsx("div",{className:"ai-ml-logo-card",children:e.jsx("img",{src:E,alt:"Meta"})}),e.jsx("div",{className:"ai-ml-logo-card",children:e.jsx("img",{src:T,alt:"Netflix"})}),e.jsx("div",{className:"ai-ml-logo-card",children:e.jsx("img",{src:R,alt:"Infosys"})}),e.jsx("div",{className:"ai-ml-logo-card",children:e.jsx("img",{src:D,alt:"Accenture"})})]})]})}),e.jsx(i,{className:"ai-ml-highlights ai-ml-section",children:e.jsxs("div",{className:"ai-ml-highlights-inner",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"ai-ml-highlights-heading",children:[e.jsx("h2",{children:"What You Will Achieve in This AI & ML Program"}),e.jsx("p",{children:"Gain strong foundations, build real products, and become job‑ready for data‑driven roles."})]}),e.jsxs("div",{className:"ai-ml-highlight-grid",children:[e.jsxs("div",{className:"ai-ml-highlight-card",children:[e.jsx("div",{className:"ai-ml-highlight-icon",children:e.jsx(f,{size:24})}),e.jsx("h3",{children:"Deep Conceptual Clarity"}),e.jsx("p",{children:"Understand how algorithms work under the hood so you can debug, tune and explain your models with confidence."})]}),e.jsxs("div",{className:"ai-ml-highlight-card",children:[e.jsx("div",{className:"ai-ml-highlight-icon",children:e.jsx(u,{size:24})}),e.jsx("h3",{children:"Hands‑on Coding Skills"}),e.jsx("p",{children:"Write clean Python, use Pandas & NumPy effectively, and implement ML pipelines using Scikit‑learn & TensorFlow."})]}),e.jsxs("div",{className:"ai-ml-highlight-card",children:[e.jsx("div",{className:"ai-ml-highlight-icon",children:e.jsx(o,{size:24})}),e.jsx("h3",{children:"Real‑World Projects"}),e.jsx("p",{children:"Work with messy, real datasets, deploy models as APIs, and document projects that you can showcase in your portfolio."})]}),e.jsxs("div",{className:"ai-ml-highlight-card",children:[e.jsx("div",{className:"ai-ml-highlight-icon",children:e.jsx(j,{size:24})}),e.jsx("h3",{children:"Career‑Ready Profile"}),e.jsx("p",{children:"Prepare for roles like Data Scientist, ML Engineer and AI Analyst with interview‑oriented practice and guidance."})]}),e.jsxs("div",{className:"ai-ml-highlight-card",children:[e.jsx("div",{className:"ai-ml-highlight-icon",children:e.jsx(b,{size:24})}),e.jsx("h3",{children:"Industry Applications"}),e.jsx("p",{children:"Explore AI use‑cases in finance, healthcare, e‑commerce, marketing and more to understand how ML is used in business."})]}),e.jsxs("div",{className:"ai-ml-highlight-card",children:[e.jsx("div",{className:"ai-ml-highlight-icon",children:"🤝"}),e.jsx("h3",{children:"Mentorship & Community"}),e.jsx("p",{children:"Get mentor feedback, doubt support and peer interaction so you never feel stuck while learning."})]})]})]}),e.jsx("div",{className:"ai-ml-highlights-visual",children:e.jsxs("div",{className:"ai-ml-dashboard",children:[e.jsxs("div",{className:"ai-ml-dashboard-header",children:[e.jsx("span",{children:"AI Model Performance"}),e.jsxs("div",{className:"ai-ml-dashboard-dots",children:[e.jsx("span",{}),e.jsx("span",{}),e.jsx("span",{})]})]}),e.jsxs("div",{className:"ai-ml-dashboard-graph",children:[e.jsx("div",{className:"ai-ml-dashboard-bar"}),e.jsx("div",{className:"ai-ml-dashboard-bar"}),e.jsx("div",{className:"ai-ml-dashboard-bar"}),e.jsx("div",{className:"ai-ml-dashboard-bar"}),e.jsx("div",{className:"ai-ml-dashboard-bar"})]}),e.jsxs("div",{className:"ai-ml-dashboard-tags",children:[e.jsx("span",{children:"Accuracy ↑"}),e.jsx("span",{children:"Precision"}),e.jsx("span",{children:"Recall"}),e.jsx("span",{children:"ROC‑AUC"})]})]})})]})}),e.jsx(i,{className:"ai-ml-tools ai-ml-section",children:e.jsxs("div",{className:"ai-ml-tools-inner",children:[e.jsx("h2",{children:"Tools & Platforms You Will Use"}),e.jsx("p",{children:"Get hands‑on experience with the most widely used tools in data science, machine learning and modern software development."}),e.jsxs("div",{className:"ai-ml-tools-grid",children:[e.jsxs("div",{className:"ai-ml-tools-card",children:[e.jsx("img",{className:"ai-ml-tools-logo",src:t,alt:"Python"}),e.jsx("span",{children:"Python"})]}),e.jsxs("div",{className:"ai-ml-tools-card",children:[e.jsx("img",{className:"ai-ml-tools-logo",src:w,alt:"Jupyter Notebook"}),e.jsx("span",{children:"Jupyter Notebook"})]}),e.jsxs("div",{className:"ai-ml-tools-card",children:[e.jsx("img",{className:"ai-ml-tools-logo",src:k,alt:"VS Code"}),e.jsx("span",{children:"VS Code"})]}),e.jsxs("div",{className:"ai-ml-tools-card",children:[e.jsx("img",{className:"ai-ml-tools-logo",src:A,alt:"Git"}),e.jsx("span",{children:"Git"})]}),e.jsxs("div",{className:"ai-ml-tools-card",children:[e.jsx("img",{className:"ai-ml-tools-logo",src:L,alt:"GitHub"}),e.jsx("span",{children:"GitHub"})]}),e.jsxs("div",{className:"ai-ml-tools-card",children:[e.jsx("img",{className:"ai-ml-tools-logo",src:I,alt:"NumPy"}),e.jsx("span",{children:"NumPy"})]}),e.jsxs("div",{className:"ai-ml-tools-card",children:[e.jsx("img",{className:"ai-ml-tools-logo",src:M,alt:"Pandas"}),e.jsx("span",{children:"Pandas"})]}),e.jsxs("div",{className:"ai-ml-tools-card",children:[e.jsx("img",{className:"ai-ml-tools-logo",src:O,alt:"Matplotlib"}),e.jsx("span",{children:"Matplotlib"})]}),e.jsxs("div",{className:"ai-ml-tools-card",children:[e.jsx("img",{className:"ai-ml-tools-logo",src:d,alt:"Scikit-learn"}),e.jsx("span",{children:"Scikit‑learn"})]}),e.jsxs("div",{className:"ai-ml-tools-card",children:[e.jsx("img",{className:"ai-ml-tools-logo",src:c,alt:"TensorFlow"}),e.jsx("span",{children:"TensorFlow / Keras"})]})]})]})}),e.jsx(i,{className:"ai-ml-more ai-ml-section",children:e.jsxs("div",{className:"ai-ml-more-inner",children:[e.jsxs("div",{className:"ai-ml-more-header",children:[e.jsx("h2",{children:"Course Tools, Roles & Learning Journey"}),e.jsx("p",{children:"See the ecosystem you will work with, the roles this course prepares you for, and how your learning path progresses."})]}),e.jsxs("div",{className:"ai-ml-more-grid",children:[e.jsxs("div",{className:"ai-ml-more-card",children:[e.jsxs("div",{className:"ai-ml-more-top",children:[e.jsx("div",{className:"ai-ml-more-icon",children:"🛠"}),e.jsxs("div",{children:[e.jsx("h3",{className:"ai-ml-more-title",children:"Tools & Libraries You Will Master"}),e.jsx("p",{className:"ai-ml-more-text",children:"Work with industry‑standard tools for data analysis, classical ML, and deep learning so you can contribute to real projects."})]})]}),e.jsxs("div",{className:"ai-ml-tool-logos",children:[e.jsx("img",{className:"ai-ml-tool-logo",src:t,alt:"Python"}),e.jsx("img",{className:"ai-ml-tool-logo",src:d,alt:"Scikit-learn"}),e.jsx("img",{className:"ai-ml-tool-logo",src:c,alt:"TensorFlow"})]})]}),e.jsxs("div",{className:"ai-ml-more-card",children:[e.jsxs("div",{className:"ai-ml-more-top",children:[e.jsx("div",{className:"ai-ml-more-icon",children:"🎯"}),e.jsxs("div",{children:[e.jsx("h3",{className:"ai-ml-more-title",children:"Career Roles You Can Target"}),e.jsx("p",{className:"ai-ml-more-text",children:"Build a portfolio and skill set that maps directly to high‑growth AI & data‑driven job roles across industries."})]})]}),e.jsxs("div",{className:"ai-ml-roles-image",children:[e.jsx("span",{className:"ai-ml-role-tag",children:"Junior Data Scientist"}),e.jsx("span",{className:"ai-ml-role-tag",children:"Machine Learning Engineer"}),e.jsx("span",{className:"ai-ml-role-tag",children:"AI Engineer"}),e.jsx("span",{className:"ai-ml-role-tag",children:"Business Analytics Engineer"}),e.jsx("span",{className:"ai-ml-role-tag",children:"ML Ops Associate"})]})]}),e.jsxs("div",{className:"ai-ml-more-card",children:[e.jsxs("div",{className:"ai-ml-more-top",children:[e.jsx("div",{className:"ai-ml-more-icon",children:"📚"}),e.jsxs("div",{children:[e.jsx("h3",{className:"ai-ml-more-title",children:"Your Learning Journey"}),e.jsx("p",{className:"ai-ml-more-text",children:"A guided path from fundamentals to deployment, with checkpoints to track your progress and confidence."})]})]}),e.jsxs("div",{className:"ai-ml-journey",children:[e.jsx("div",{className:"ai-ml-journey-step",children:"Weeks 1–4: Python, maths & data handling fundamentals"}),e.jsx("div",{className:"ai-ml-journey-step",children:"Weeks 5–8: Core ML algorithms, evaluation & feature engineering"}),e.jsx("div",{className:"ai-ml-journey-step",children:"Weeks 9–12: Deep learning, CNNs & basic NLP applications"}),e.jsx("div",{className:"ai-ml-journey-step",children:"Weeks 13–16: Capstone project, model deployment & interview prep"})]})]})]})]})})]})};export{ee as default};
