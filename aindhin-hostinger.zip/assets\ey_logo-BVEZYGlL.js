const o="/assets/ey_logo-DBOcdPJ8.svg";export{o as E};
