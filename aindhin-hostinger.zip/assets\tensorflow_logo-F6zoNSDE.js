const s="/assets/numpy-DShJy0PC.svg",o="/assets/scikit_learn_logo-CNZ4BZxS.svg",t="/assets/tensorflow_logo-CV_gkUDK.svg";export{s as N,o as S,t as T};
