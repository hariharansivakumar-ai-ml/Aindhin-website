const s="/assets/git-DHkOHQQE.svg";export{s as G};
