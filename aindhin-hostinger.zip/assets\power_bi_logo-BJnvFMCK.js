const o="/assets/powerbi-BbPy9d0V.svg";export{o as P};
