const o="/assets/github_logo-eaX2nSbE.svg";export{o as G};
