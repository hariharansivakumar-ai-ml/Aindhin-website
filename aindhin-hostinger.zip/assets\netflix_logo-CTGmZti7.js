const s="/assets/meta_logo-VDAdjeys.webp",e="/assets/netflix-O1T4aWxM.svg";export{s as M,e as N};
