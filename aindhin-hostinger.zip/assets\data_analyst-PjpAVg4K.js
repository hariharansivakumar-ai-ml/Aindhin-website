const a="/assets/data_analyst-BhpJ9rba.webp";export{a as d};
