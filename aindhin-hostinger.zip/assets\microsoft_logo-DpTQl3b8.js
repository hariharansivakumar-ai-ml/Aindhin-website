const o="/assets/microsoft-DUSySa8Z.svg";export{o as M};
