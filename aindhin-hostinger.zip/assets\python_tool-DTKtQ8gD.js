const o="/assets/python-Cy-g5xqC.svg";export{o as p};
