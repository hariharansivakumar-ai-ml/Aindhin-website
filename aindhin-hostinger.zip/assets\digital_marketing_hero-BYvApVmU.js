const e="/assets/digital_marketing_hero-VxfhTaMt.webp";export{e as h};
