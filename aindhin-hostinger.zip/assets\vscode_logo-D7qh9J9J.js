const s="/assets/vscode-ofeWxTsy.svg";export{s as V};
