const a="/assets/tableau_logo-CpaImqAS.webp";export{a as T};
