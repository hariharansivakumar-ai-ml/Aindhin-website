const o="/assets/google_analytics_logo-DuMSz2l8.svg";export{o as G};
