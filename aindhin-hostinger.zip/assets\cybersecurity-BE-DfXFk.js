const s="/assets/aiml-U87TC2R-.webp",e="/assets/cybersecurity-DSR7GkUH.webp";export{s as a,e as c};
