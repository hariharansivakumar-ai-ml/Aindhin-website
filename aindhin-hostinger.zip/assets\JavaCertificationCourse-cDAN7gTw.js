import{r as l,j as e,n as j,aV as o,an as t,ak as p,K as d,b2 as m,a$ as g,a9 as v,aw as f,E as u,ah as b,aU as N,m as y}from"./vendor-BkeoPC-K.js";import{g as w}from"./git-CTeECw9u.js";import{g as C,m as k,a as z,i as S,b as E,n as I,c as A,d as J}from"./accenture-_JMXlVdC.js";const O="/assets/java_hero-CKGmQAvk.webp",c="/assets/java-C7lJCW9k.svg",L="/assets/intellij-Dt3uHgex.svg",x="/assets/spring-BeCi7N4J.svg",M="/assets/maven-CLYOof1B.svg",T="/assets/junit-CyrFh2b9.webp",a=({children:i,className:n})=>{const r=l.useRef(null),s=N(r,{once:!0,margin:"-100px"});return e.jsx(y.div,{ref:r,initial:{opacity:0,y:24},animate:s?{opacity:1,y:0}:{opacity:0,y:24},transition:{duration:.7,ease:"easeOut"},className:n,children:i})},R=()=>{l.useEffect(()=>{document.title="Java Certification Course: Master Object-Oriented Programming | Aindhin";const s=document.querySelector('meta[name="description"]');s&&s.setAttribute("content","Aindhin is an online learning platform in India offering skill-based and career-oriented courses.")},[]);const[i,n]=l.useState(0),r=(s,h)=>{h.preventDefault(),n(i===s?null:s)};return e.jsxs("div",{className:"jv-course font-sans text-slate-900 bg-blue-50 w-full overflow-x-hidden",children:[e.jsx("style",{children:`
            /* ===== JAVA CERTIFICATION COURSE PAGE (scoped) ===== */
            .jv-course{
              font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
              color:#0f172a;
              background:#e0f2fe;
              width:100%;
            }
            .jv-course *{box-sizing:border-box;}
            
            /* HERO */
            .jv-hero{
              color:#fff;
              background:
                linear-gradient(120deg,rgba(15,23,42,.96),rgba(37,99,235,.75)),
                url("${O}")
                center/cover no-repeat;
              padding:70px 20px;
              display:flex;
              align-items:center;
              justify-content:center;
            }
            .jv-hero-content{
              max-width:900px;
              text-align:left;
            }
            .jv-badge{
              display:inline-block;
              padding:4px 12px;
              border-radius:999px;
              background:rgba(15,23,42,.7);
              border:1px solid rgba(248,250,252,.4);
              font-size:12px;
              letter-spacing:.08em;
              text-transform:uppercase;
              margin-bottom:10px;
            }
            .fs-hero-title{
              color:#fff;
              font-size:64px;
              line-height:1.1;
              margin:0 0 14px;
            }
            .fs-hero-sub{
              font-size:20px;
              max-width:720px;
              color:#e5e7eb;
              margin:0 0 16px;
            }
            .jv-hero-meta{
              display:flex;
              flex-wrap:wrap;
              gap:10px 18px;
              font-size:13px;
              color:#e5e7eb;
            }
            .jv-hero-meta span::before{
              content:"• ";
              color:#fde68a;
              font-weight:700;
            }
            
            /* MAIN LAYOUT */
            .jv-main{padding:40px 20px 50px;}
            .jv-main-inner{
              max-width:1160px;
              margin:0 auto;
              display:grid;
              grid-template-columns:minmax(0,2fr) minmax(0,1.1fr);
              gap:24px;
            }
            .jv-left,.jv-right{
              display:flex;
              flex-direction:column;
              gap:16px;
            }
            
            /* CARDS */
            .jv-card{
              background:#ffffff;
              border-radius:18px;
              padding:20px 22px;
              box-shadow:0 10px 25px rgba(15,23,42,.08);
            }
            .jv-card h2{
              font-size:18px;
              margin:0 0 10px;
              color:#1d4ed8;
            }
            .jv-about-text{
              font-size:14px;
              color:#4b5563;
              line-height:1.6;
            }
            
            /* SYLLABUS */
            .jv-module{
              border:1px solid #e5e7eb;
              border-radius:12px;
              background:#f9fafb;
              margin-top:8px;
              overflow:hidden;
            }
            .jv-module summary{
              list-style:none;
              padding:10px 14px;
              cursor:pointer;
              display:flex;
              justify-content:space-between;
              align-items:center;
              font-size:14px;
              font-weight:600;
            }
            .jv-module summary::-webkit-details-marker{display:none;}
            .jv-module summary::after{
              content:"▾";
              font-size:12px;
              color:#9ca3af;
              transition:transform .2s;
            }
            .jv-module[open] summary::after{transform:rotate(-180deg);}
            .jv-module-title{
              display:flex;
              gap:8px;
              flex-wrap:wrap;
              align-items:baseline;
            }
            .jv-module-label{
              font-size:11px;
              text-transform:uppercase;
              letter-spacing:.08em;
              color:#111827;   /* dark text */
              font-weight:700; /* bold */
            }
            .jv-module-content{
              padding:0 14px 10px 24px;
              font-size:13px;
              color:#4b5563;
            }
            .jv-module-content ul{
              margin:0;
              padding-left:16px;
            }
            .jv-module-content li{margin-bottom:4px;}
            
            /* RIGHT-COLUMN DETAILS */
            .jv-detail-list{
              list-style:none;
              padding:0;
              margin:0 0 16px;
              font-size:14px;
            }
            .jv-detail-item{
              display:flex;
              gap:10px;
              margin-bottom:10px;
            }
            .jv-detail-icon{
              width:26px;
              height:26px;
              border-radius:999px;
              background:#e0f2fe;
              display:flex;
              align-items:center;
              justify-content:center;
              font-size:13px;
              color:#1d4ed8;
              flex-shrink:0;
            }
            .jv-detail-text strong{
              display:block;
              font-weight:600;
              color:#111827;
            }
            .jv-detail-text span{
              font-size:13px;
              color:#4b5563;
            }
            
            /* CTA BUTTON */
            .jv-cta-btn{
              display:block;
              width:100%;
              border-radius:999px;
              padding:11px 16px;
              border:none;
              text-align:center;
              text-decoration:none;
              background:linear-gradient(135deg,#38bdf8,#6366f1);
              color:#fff !important;
              font-weight:600;
              font-size:15px;
              box-shadow:0 14px 30px rgba(37,99,235,.45);
              transition:transform .15s,box-shadow .15s,filter .15s,color .15s;
            }
            .jv-cta-btn:hover{
              transform:translateY(-1px);
              filter:brightness(1.04);
              box-shadow:0 18px 40px rgba(37,99,235,.6);
              color:#fff !important;
            }
            
            /* TOP COMPANIES */
            .jv-companies{
              background:#e0f2fe;
              padding:40px 20px 40px;
            }
            .jv-companies-inner{
              max-width:1160px;
              margin:0 auto;
              text-align:center;
            }
            .jv-companies h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .jv-companies p{
              margin:0 0 20px;
              font-size:14px;
              color:#4b5563;
            }
            .jv-logo-row{
              display:flex;
              flex-wrap:wrap;
              justify-content:center;
              gap:18px;
            }
            .jv-logo-card{
              width:130px;
              height:62px;
              border-radius:14px;
              background:#ffffff;
              display:flex;
              align-items:center;
              justify-content:center;
              box-shadow:0 8px 18px rgba(15,23,42,.08);
              transition:transform .18s,box-shadow .18s;
            }
            .jv-logo-card img{
              max-height:40px;
              max-width:100%;
            }
            .jv-logo-card:hover{
              transform:translateY(-3px);
              box-shadow:0 14px 30px rgba(15,23,42,.16);
            }
            
            /* EXTRA COURSE DETAILS SECTION */
            .jv-highlights{
              background:#e0f2fe;
              padding:10px 20px 50px;
            }
            .jv-highlights-inner{
              max-width:1160px;
              margin:0 auto;
              display:grid;
              grid-template-columns:minmax(0,1.7fr) minmax(0,1.1fr);
              gap:28px;
              align-items:center;
            }
            .jv-highlights-heading{
              margin-bottom:12px;
            }
            .jv-highlights-heading h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .jv-highlights-heading p{
              margin:0;
              font-size:14px;
              color:#4b5563;
            }
            .jv-highlight-grid{
              margin-top:18px;
              display:grid;
              grid-template-columns:repeat(3,minmax(0,1fr));
              gap:14px;
            }
            .jv-highlight-card{
              background:#ffffff;
              border-radius:16px;
              padding:14px 12px;
              box-shadow:0 10px 24px rgba(15,23,42,.08);
            }
            .jv-highlight-icon{
              width:38px;
              height:38px;
              border-radius:999px;
              background:linear-gradient(135deg,#38bdf8,#6366f1);
              display:flex;
              align-items:center;
              justify-content:center;
              color:#fff;
              font-size:20px;
              margin-bottom:8px;
            }
            .jv-highlight-card h3{
              font-size:14px;
              margin:0 0 4px;
              color:#0f172a;
            }
            .jv-highlight-card p{
              font-size:13px;
              margin:0;
              color:#4b5563;
            }
            
            /* representation "image" block */
            .jv-highlights-visual{
              display:flex;
              justify-content:center;
            }
            .jv-dashboard{
              width:100%;
              max-width:340px;
              background:#ffffff;
              border-radius:20px;
              padding:14px 14px 18px;
              box-shadow:0 18px 40px rgba(37,99,235,.35);
            }
            .jv-dashboard-header{
              display:flex;
              justify-content:space-between;
              align-items:center;
              margin-bottom:10px;
              font-size:12px;
              color:#0f172a;
            }
            .jv-dashboard-dots{
              display:flex;
              gap:4px;
            }
            .jv-dashboard-dots span{
              width:7px;
              height:7px;
              border-radius:999px;
              background:#bfdbfe;
            }
            .jv-dashboard-graph{
              display:flex;
              gap:6px;
              align-items:flex-end;
              height:90px;
              margin-bottom:12px;
            }
            .jv-dashboard-bar{
              flex:1;
              border-radius:8px 8px 2px 2px;
              background:linear-gradient(180deg,#38bdf8,#1d4ed8);
            }
            .jv-dashboard-bar:nth-child(2){height:65%;}
            .jv-dashboard-bar:nth-child(3){height:85%;}
            .jv-dashboard-bar:nth-child(4){height:45%;}
            .jv-dashboard-bar:nth-child(5){height:75%;}
            .jv-dashboard-bar:nth-child(1){height:35%;}
            .jv-dashboard-tags{
              display:flex;
              flex-wrap:wrap;
              gap:6px;
              font-size:11px;
            }
            .jv-dashboard-tags span{
              padding:3px 7px;
              border-radius:999px;
              background:#eff6ff;
              color:#1d4ed8;
            }
            
            /* TOOLS SECTION */
            .jv-tools{
              background:#e0f2fe;
              padding:0 20px 50px;
            }
            .jv-tools-inner{
              max-width:1160px;
              margin:0 auto;
              text-align:center;
            }
            .jv-tools-inner h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .jv-tools-inner p{
              margin:0 0 20px;
              font-size:14px;
              color:#4b5563;
            }
            .jv-tools-grid{
              display:flex;
              flex-wrap:wrap;
              justify-content:center;
              gap:16px;
            }
            .jv-tools-card{
              width:140px;
              height:90px;
              border-radius:16px;
              background:#ffffff;
              box-shadow:0 10px 26px rgba(15,23,42,.12);
              display:flex;
              flex-direction:column;
              align-items:center;
              justify-content:center;
              padding:8px;
            }
            .jv-tools-logo{
              max-height:36px;
              max-width:90px;
              margin-bottom:4px;
            }
            .jv-tools-card span{
              font-size:12px;
              color:#111827;
            }
            
            /* MORE DETAILS SECTION */
            .jv-more{
              background:#e0f2fe;
              padding:0 20px 50px;
            }
            .jv-more-inner{
              max-width:1160px;
              margin:0 auto;
            }
            .jv-more-header{
              text-align:center;
              margin-bottom:20px;
            }
            .jv-more-header h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .jv-more-header p{
              margin:0;
              font-size:14px;
              color:#4b5563;
            }
            .jv-more-grid{
              display:grid;
              grid-template-columns:repeat(3,minmax(0,1fr));
              gap:18px;
            }
            .jv-more-card{
              background:#ffffff;
              border-radius:18px;
              padding:16px 14px;
              box-shadow:0 12px 30px rgba(15,23,42,.12);
              display:flex;
              flex-direction:column;
              gap:8px;
            }
            .jv-more-top{
              display:flex;
              align-items:flex-start;
              gap:8px;
            }
            .jv-more-icon{
              width:32px;
              height:32px;
              border-radius:999px;
              background:linear-gradient(135deg,#38bdf8,#6366f1);
              color:#fff;
              display:flex;
              align-items:center;
              justify-content:center;
              font-size:18px;
            }
            .jv-more-title{
              font-size:15px;
              font-weight:600;
              margin:0;
              color:#0f172a;
            }
            .jv-more-text{
              font-size:13px;
              color:#4b5563;
              margin:0;
            }
            .jv-tool-logos{
              margin-top:12px;
              display:flex;
              flex-wrap:wrap;
              gap:10px;
              align-items:center;
              justify-content:center;
              width:100%;
            }
            .jv-tool-logo{
              max-height:32px;
              width:auto;
              filter:drop-shadow(0 2px 4px rgba(15,23,42,.18));
            }
            .jv-tool-logos img{
              max-height:32px !important;
              width:auto !important;
              object-fit:contain;
            }
            .jv-roles-image{
              margin-top:8px;
              display:flex;
              flex-wrap:wrap;
              gap:6px;
            }
            .jv-role-tag{
              padding:4px 8px;
              border-radius:999px;
              font-size:11px;
              background:#eff6ff;
              color:#1d4ed8;
            }
            .jv-journey{
              margin-top:8px;
              border-left:2px solid #bfdbfe;
              padding-left:10px;
            }
            .jv-journey-step{
              position:relative;
              padding-left:10px;
              margin-bottom:6px;
              font-size:12px;
              color:#4b5563;
            }
            .jv-journey-step::before{
              content:"";
              position:absolute;
              left:-11px;
              top:5px;
              width:8px;
              height:8px;
              border-radius:999px;
              background:#38bdf8;
            }
            
            /* FADE-IN ON SCROLL */
            .jv-section{
              opacity:0;
              transform:translateY(24px);
              transition:opacity .7s ease-out, transform .7s ease-out;
            }
            .jv-section.jv-visible{
              opacity:1;
              transform:translateY(0);
            }
            
            /* RESPONSIVE */
            @media (max-width:900px){
              .jv-hero{padding:50px 18px;}
              .fs-hero-title{font-size:48px;}
              .jv-main-inner{
                grid-template-columns:minmax(0,1fr);
              }
              .jv-highlights-inner{
                grid-template-columns:minmax(0,1fr);
              }
              .jv-more-grid{
                grid-template-columns:minmax(0,1fr);
              }
            }
            @media (max-width:640px){
              .jv-hero{padding:38px 16px;}
              .jv-hero-meta{flex-direction:column;}
              .jv-highlight-grid{
                grid-template-columns:minmax(0,1fr);
              }
            }
            `}),e.jsxs("div",{className:"jv-course",id:"top",children:[e.jsx(a,{className:"jv-hero jv-section",children:e.jsxs("div",{className:"jv-hero-content",children:[e.jsx("span",{className:"jv-badge",children:"Java Certification"}),e.jsx("h1",{className:"fs-hero-title",children:"Master Java Programming: Get Certified and Build Enterprise-Grade Applications"}),e.jsx("p",{className:"fs-hero-sub",children:"Master Core Java, Object-Oriented Programming, and advanced concepts including Collections, Multithreading, and Database connectivity to build robust enterprise applications."}),e.jsxs("div",{className:"jv-hero-meta",children:[e.jsx("span",{children:"Covers Core Java, OOPs, Collections & JDBC"}),e.jsx("span",{children:"Hands-on with Spring Framework & Maven"}),e.jsx("span",{children:"Industry-aligned curriculum & Interview prep"})]})]})}),e.jsx("main",{className:"jv-main jv-section",children:e.jsxs("div",{className:"jv-main-inner",children:[e.jsxs("div",{className:"jv-left",children:[e.jsxs(a,{className:"jv-card",children:[e.jsx("h2",{children:"About This Course"}),e.jsxs("div",{className:"jv-about-text",children:[e.jsx("p",{children:"This course provides a comprehensive deep dive into Java programming. Starting from the absolute basics, you will progress to advanced topics like Exception Handling, File I/O, and the Collections Framework."}),e.jsx("p",{children:"You will also learn how to build scalable applications using modern tools like Maven and Spring, and gain proficiency in database connectivity with JDBC. Designed for both beginners and those looking to upskill for backend roles."})]})]}),e.jsxs(a,{className:"jv-card",children:[e.jsx("h2",{children:"Syllabus Covered"}),e.jsxs("details",{className:"jv-module",open:i===0,children:[e.jsx("summary",{onClick:s=>r(0,s),children:e.jsxs("div",{className:"jv-module-title",children:[e.jsx("span",{className:"jv-module-label",children:"Module 1"}),e.jsx("span",{children:"Java Basics & Core Syntax"})]})}),e.jsx("div",{className:"jv-module-content",children:e.jsxs("ul",{children:[e.jsx("li",{children:"JDK Setup, IDEs & Environment Variables"}),e.jsx("li",{children:"Data Types, Operators & Control Flow"}),e.jsx("li",{children:"Arrays, Strings & Memory Management"}),e.jsx("li",{children:"Methods, Scope & Recursion"}),e.jsx("li",{children:"Debugging & Code Optimization"})]})})]}),e.jsxs("details",{className:"jv-module",open:i===1,children:[e.jsx("summary",{onClick:s=>r(1,s),children:e.jsxs("div",{className:"jv-module-title",children:[e.jsx("span",{className:"jv-module-label",children:"Module 2"}),e.jsx("span",{children:"Object-Oriented Programming"})]})}),e.jsx("div",{className:"jv-module-content",children:e.jsxs("ul",{children:[e.jsx("li",{children:"Classes, Objects & Constructors"}),e.jsx("li",{children:"Inheritance, Polymorphism & Encapsulation"}),e.jsx("li",{children:"Abstract Classes & Interfaces"}),e.jsx("li",{children:"Exception Handling & Custom Exceptions"}),e.jsx("li",{children:"Packages & Access Modifiers"})]})})]}),e.jsxs("details",{className:"jv-module",open:i===2,children:[e.jsx("summary",{onClick:s=>r(2,s),children:e.jsxs("div",{className:"jv-module-title",children:[e.jsx("span",{className:"jv-module-label",children:"Module 3"}),e.jsx("span",{children:"Collections & Advanced Concepts"})]})}),e.jsx("div",{className:"jv-module-content",children:e.jsxs("ul",{children:[e.jsx("li",{children:"Java Collections Framework (List, Set, Map)"}),e.jsx("li",{children:"Generics & Lambda Expressions (Java 8)"}),e.jsx("li",{children:"Streams API & Functional Programming"}),e.jsx("li",{children:"File Handling & Multithreading"}),e.jsx("li",{children:"JDBC: Connecting to Databases"})]})})]}),e.jsxs("details",{className:"jv-module",open:i===3,children:[e.jsx("summary",{onClick:s=>r(3,s),children:e.jsxs("div",{className:"jv-module-title",children:[e.jsx("span",{className:"jv-module-label",children:"Module 4"}),e.jsx("span",{children:"Frameworks & Enterprise Development"})]})}),e.jsx("div",{className:"jv-module-content",children:e.jsxs("ul",{children:[e.jsx("li",{children:"Introduction to Maven & Dependency Management"}),e.jsx("li",{children:"Unit Testing with JUnit"}),e.jsx("li",{children:"Introduction to Spring Framework & DI"}),e.jsx("li",{children:"Building RESTful APIs (Spring Boot Basics)"}),e.jsx("li",{children:"Capstone: Application Development"})]})})]})]})]}),e.jsx("aside",{className:"jv-right",children:e.jsxs(a,{className:"jv-card",children:[e.jsx("h2",{children:"Course Details"}),e.jsxs("ul",{className:"jv-detail-list",children:[e.jsxs("li",{className:"jv-detail-item",children:[e.jsx("div",{className:"jv-detail-icon",children:e.jsx(j,{size:20})}),e.jsxs("div",{className:"jv-detail-text",children:[e.jsx("strong",{children:"Duration"}),e.jsx("span",{children:"14 Weeks (90+ hours)"})]})]}),e.jsxs("li",{className:"jv-detail-item",children:[e.jsx("div",{className:"jv-detail-icon",children:e.jsx(o,{size:20})}),e.jsxs("div",{className:"jv-detail-text",children:[e.jsx("strong",{children:"Skill Level"}),e.jsx("span",{children:"Beginner to Intermediate"})]})]}),e.jsxs("li",{className:"jv-detail-item",children:[e.jsx("div",{className:"jv-detail-icon",children:e.jsx(t,{size:20})}),e.jsxs("div",{className:"jv-detail-text",children:[e.jsx("strong",{children:"Includes"}),e.jsx("span",{children:"Live Classes, Projects & Placement Support"})]})]}),e.jsxs("li",{className:"jv-detail-item",children:[e.jsx("div",{className:"jv-detail-icon",children:e.jsx(p,{size:20})}),e.jsxs("div",{className:"jv-detail-text",children:[e.jsx("strong",{children:"Next Batch"}),e.jsx("span",{children:"Coming Soon"})]})]}),e.jsxs("li",{className:"jv-detail-item",children:[e.jsx("div",{className:"jv-detail-icon",children:e.jsx(d,{size:20})}),e.jsxs("div",{className:"jv-detail-text",children:[e.jsx("strong",{children:"Certificate"}),e.jsx("span",{children:"Java Certification & Job Prep"})]})]})]}),e.jsx("a",{href:"#top",className:"jv-cta-btn",children:"Enroll Now & Start Learning"})]})})]})}),e.jsx(a,{className:"jv-companies jv-section",children:e.jsxs("div",{className:"jv-companies-inner",children:[e.jsx("h2",{children:"Top Companies Hiring Java Developers"}),e.jsx("p",{children:"Java remains the backbone of enterprise software, used by leading tech giants globally."}),e.jsxs("div",{className:"jv-logo-row",children:[e.jsx("div",{className:"jv-logo-card",children:e.jsx("img",{src:C,alt:"Google"})}),e.jsx("div",{className:"jv-logo-card",children:e.jsx("img",{src:k,alt:"Microsoft"})}),e.jsx("div",{className:"jv-logo-card",children:e.jsx("img",{src:z,alt:"AWS"})}),e.jsx("div",{className:"jv-logo-card",children:e.jsx("img",{src:S,alt:"IBM"})}),e.jsx("div",{className:"jv-logo-card",children:e.jsx("img",{src:E,alt:"Meta"})}),e.jsx("div",{className:"jv-logo-card",children:e.jsx("img",{src:I,alt:"Netflix"})}),e.jsx("div",{className:"jv-logo-card",children:e.jsx("img",{src:A,alt:"Infosys"})}),e.jsx("div",{className:"jv-logo-card",children:e.jsx("img",{src:J,alt:"Accenture"})})]})]})}),e.jsx(a,{className:"jv-highlights jv-section",children:e.jsxs("div",{className:"jv-highlights-inner",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"jv-highlights-heading",children:[e.jsx("h2",{children:"Why Learn Java with Us?"}),e.jsx("p",{children:"Gain specialized skills that make you an invaluable asset in the software industry."})]}),e.jsxs("div",{className:"jv-highlight-grid",children:[e.jsxs("div",{className:"jv-highlight-card",children:[e.jsx("div",{className:"jv-highlight-icon",children:e.jsx(m,{size:24})}),e.jsx("h3",{children:"Strong Foundations"}),e.jsx("p",{children:"Build a robust understanding of OOP principles that apply across all major languages."})]}),e.jsxs("div",{className:"jv-highlight-card",children:[e.jsx("div",{className:"jv-highlight-icon",children:e.jsx(g,{size:24})}),e.jsx("h3",{children:"Performance Tuning"}),e.jsx("p",{children:"Learn to write efficient, high-performance code and manage memory effectively."})]}),e.jsxs("div",{className:"jv-highlight-card",children:[e.jsx("div",{className:"jv-highlight-icon",children:e.jsx(v,{size:24})}),e.jsx("h3",{children:"Enterprise Ready"}),e.jsx("p",{children:"Master the tools and frameworks (Spring, Hibernate) used in large-scale systems."})]}),e.jsxs("div",{className:"jv-highlight-card",children:[e.jsx("div",{className:"jv-highlight-icon",children:e.jsx(t,{size:24})}),e.jsx("h3",{children:"Testing & QA"}),e.jsx("p",{children:"Write reliable code with JUnit testing and learn enterprise debugging techniques."})]}),e.jsxs("div",{className:"jv-highlight-card",children:[e.jsx("div",{className:"jv-highlight-icon",children:e.jsx(d,{size:24})}),e.jsx("h3",{children:"Certification"}),e.jsx("p",{children:"Prepare for Oracle Java Certification exams with targeted practice modules."})]}),e.jsxs("div",{className:"jv-highlight-card",children:[e.jsx("div",{className:"jv-highlight-icon",children:e.jsx(o,{size:24})}),e.jsx("h3",{children:"Career Growth"}),e.jsx("p",{children:"Open doors to high-paying backend and full-stack development roles."})]})]})]}),e.jsx("div",{className:"jv-highlights-visual",children:e.jsxs("div",{className:"jv-dashboard",children:[e.jsxs("div",{className:"jv-dashboard-header",children:[e.jsx("span",{children:"Java Application Metrics"}),e.jsxs("div",{className:"jv-dashboard-dots",children:[e.jsx("span",{}),e.jsx("span",{}),e.jsx("span",{})]})]}),e.jsxs("div",{className:"jv-dashboard-graph",children:[e.jsx("div",{className:"jv-dashboard-bar"}),e.jsx("div",{className:"jv-dashboard-bar"}),e.jsx("div",{className:"jv-dashboard-bar"}),e.jsx("div",{className:"jv-dashboard-bar"}),e.jsx("div",{className:"jv-dashboard-bar"})]}),e.jsxs("div",{className:"jv-dashboard-tags",children:[e.jsx("span",{children:"Throughput"}),e.jsx("span",{children:"Latency"}),e.jsx("span",{children:"Heap"}),e.jsx("span",{children:"Threads"})]})]})})]})}),e.jsx(a,{className:"jv-tools jv-section",children:e.jsxs("div",{className:"jv-tools-inner",children:[e.jsx("h2",{children:"Tools & Frameworks You Will Master"}),e.jsx("p",{children:"Get hands-on experience with the industry-standard Java ecosystem."}),e.jsxs("div",{className:"jv-tools-grid",children:[e.jsxs("div",{className:"jv-tools-card",children:[e.jsx("img",{className:"jv-tools-logo",src:c,alt:"Java"}),e.jsx("span",{children:"Java SE/EE"})]}),e.jsxs("div",{className:"jv-tools-card",children:[e.jsx("img",{className:"jv-tools-logo",src:L,alt:"IntelliJ"}),e.jsx("span",{children:"IntelliJ IDEA"})]}),e.jsxs("div",{className:"jv-tools-card",children:[e.jsx("img",{className:"jv-tools-logo",src:x,alt:"Spring"}),e.jsx("span",{children:"Spring Boot"})]}),e.jsxs("div",{className:"jv-tools-card",children:[e.jsx("img",{className:"jv-tools-logo",src:M,alt:"Maven"}),e.jsx("span",{children:"Maven"})]}),e.jsxs("div",{className:"jv-tools-card",children:[e.jsx("img",{className:"jv-tools-logo",src:T,alt:"JUnit"}),e.jsx("span",{children:"JUnit"})]}),e.jsxs("div",{className:"jv-tools-card",children:[e.jsx("img",{className:"jv-tools-logo",src:w,alt:"Git"}),e.jsx("span",{children:"Git & GitHub"})]})]})]})}),e.jsx(a,{className:"jv-more jv-section",children:e.jsxs("div",{className:"jv-more-inner",children:[e.jsxs("div",{className:"jv-more-header",children:[e.jsx("h2",{children:"Career Paths & Roadmap"}),e.jsx("p",{children:"See how this course shapes your journey into professional software development."})]}),e.jsxs("div",{className:"jv-more-grid",children:[e.jsxs("div",{className:"jv-more-card",children:[e.jsxs("div",{className:"jv-more-top",children:[e.jsx("div",{className:"jv-more-icon",children:e.jsx(f,{size:24})}),e.jsxs("div",{children:[e.jsx("h3",{className:"jv-more-title",children:"Java Ecosystem"}),e.jsx("p",{className:"jv-more-text",children:"From mobile apps (Android) to massive server-side applications, Java is everywhere."})]})]}),e.jsxs("div",{className:"jv-tool-logos",children:[e.jsx("img",{className:"jv-tool-logo",src:c,alt:"Java"}),e.jsx("img",{className:"jv-tool-logo",src:x,alt:"Spring"})]})]}),e.jsxs("div",{className:"jv-more-card",children:[e.jsxs("div",{className:"jv-more-top",children:[e.jsx("div",{className:"jv-more-icon",children:e.jsx(u,{size:24})}),e.jsxs("div",{children:[e.jsx("h3",{className:"jv-more-title",children:"Roles You Can Target"}),e.jsx("p",{className:"jv-more-text",children:"Ideal for entry-level and mid-level positions in software engineering."})]})]}),e.jsxs("div",{className:"jv-roles-image",children:[e.jsx("span",{className:"jv-role-tag",children:"Java Developer"}),e.jsx("span",{className:"jv-role-tag",children:"Backend Engineer"}),e.jsx("span",{className:"jv-role-tag",children:"Software Engineer"}),e.jsx("span",{className:"jv-role-tag",children:"Android Developer"})]})]}),e.jsxs("div",{className:"jv-more-card",children:[e.jsxs("div",{className:"jv-more-top",children:[e.jsx("div",{className:"jv-more-icon",children:e.jsx(b,{size:24})}),e.jsxs("div",{children:[e.jsx("h3",{className:"jv-more-title",children:"Your Learning Path"}),e.jsx("p",{className:"jv-more-text",children:"A structured journey from understanding syntax to building complex systems."})]})]}),e.jsxs("div",{className:"jv-journey",children:[e.jsx("div",{className:"jv-journey-step",children:"Weeks 1-4: Core Elements & OPPs"}),e.jsx("div",{className:"jv-journey-step",children:"Weeks 5-8: Advanced Java & Collections"}),e.jsx("div",{className:"jv-journey-step",children:"Weeks 9-11: Database, Maven, & Testing"}),e.jsx("div",{className:"jv-journey-step",children:"Weeks 12-14: Spring Boot & Capstone"})]})]})]})]})})]})]})};export{R as default};
