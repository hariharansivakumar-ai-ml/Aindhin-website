const s="/assets/tcs_logo-CCJpT6j4.svg";export{s as T};
