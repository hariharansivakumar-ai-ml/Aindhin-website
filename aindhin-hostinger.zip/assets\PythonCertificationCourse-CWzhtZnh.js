import{r as o,j as e,n as x,aV as l,an as h,ak as m,K as t,a3 as g,aX as y,b5 as f,J as d,b0 as j,b3 as u,aU as b,m as N}from"./vendor-BkeoPC-K.js";import{g as v}from"./git-CTeECw9u.js";import{g as w,m as k,a as P,i as C,b as S,n as z,c as L,d as A}from"./accenture-_JMXlVdC.js";const I="/assets/java_hero-CKGmQAvk.webp",p="/assets/python-Cy-g5xqC.svg",D="/assets/jupyter-BENGM-un.svg",O="/assets/vscode-ofeWxTsy.svg",T="/assets/numpy-DShJy0PC.svg",E="/assets/pandas-CAqHiGRj.svg",M="/assets/pytest-DYIuD6Wd.svg",a=({children:i,className:r})=>{const n=o.useRef(null),s=b(n,{once:!0,margin:"-100px"});return e.jsx(N.div,{ref:n,initial:{opacity:0,y:24},animate:s?{opacity:1,y:0}:{opacity:0,y:24},transition:{duration:.7,ease:"easeOut"},className:r,children:i})},F=()=>{o.useEffect(()=>{document.title="Python Certification Course: Master Python Programming | Aindhin";const s=document.querySelector('meta[name="description"]');s&&s.setAttribute("content","Aindhin is an online learning platform in India offering skill-based and career-oriented courses.")},[]);const[i,r]=o.useState(0),n=(s,c)=>{c.preventDefault(),r(i===s?null:s)};return e.jsxs("div",{className:"py-course font-sans text-slate-900 bg-blue-50 w-full overflow-x-hidden",children:[e.jsx("style",{children:`
            /* ===== PYTHON CERTIFICATION COURSE PAGE (scoped) ===== */
            .py-course{
              font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
              color:#0f172a;
              background:#e0f2fe;
              width:100%;
            }
            .py-course *{box-sizing:border-box;}
            
            /* HERO */
            .py-hero{
              color:#fff;
              background:
                linear-gradient(120deg,rgba(15,23,42,.96),rgba(37,99,235,.75)),
                url("${I}")
                center/cover no-repeat;
              padding:70px 20px;
              display:flex;
              align-items:center;
              justify-content:center;
            }
            .py-hero-content{
              max-width:900px;
              text-align:left;
            }
            .py-badge{
              display:inline-block;
              padding:4px 12px;
              border-radius:999px;
              background:rgba(15,23,42,.7);
              border:1px solid rgba(248,250,252,.4);
              font-size:12px;
              letter-spacing:.08em;
              text-transform:uppercase;
              margin-bottom:10px;
            }
            .fs-hero-title{
              color:#fff;
              font-size:64px;
              line-height:1.1;
              margin:0 0 14px;
            }
            .fs-hero-sub{
              font-size:20px;
              max-width:720px;
              color:#e5e7eb;
              margin:0 0 16px;
            }
            .py-hero-meta{
              display:flex;
              flex-wrap:wrap;
              gap:10px 18px;
              font-size:13px;
              color:#e5e7eb;
            }
            .py-hero-meta span::before{
              content:"• ";
              color:#fde68a;
              font-weight:700;
            }
            
            /* MAIN LAYOUT */
            .py-main{padding:40px 20px 50px;}
            .py-main-inner{
              max-width:1160px;
              margin:0 auto;
              display:grid;
              grid-template-columns:minmax(0,2fr) minmax(0,1.1fr);
              gap:24px;
            }
            .py-left,.py-right{
              display:flex;
              flex-direction:column;
              gap:16px;
            }
            
            /* CARDS */
            .py-card{
              background:#ffffff;
              border-radius:18px;
              padding:20px 22px;
              box-shadow:0 10px 25px rgba(15,23,42,.08);
            }
            .py-card h2{
              font-size:18px;
              margin:0 0 10px;
              color:#1d4ed8;
            }
            .py-about-text{
              font-size:14px;
              color:#4b5563;
              line-height:1.6;
            }
            
            /* SYLLABUS */
            .py-module{
              border:1px solid #e5e7eb;
              border-radius:12px;
              background:#f9fafb;
              margin-top:8px;
              overflow:hidden;
            }
            .py-module summary{
              list-style:none;
              padding:10px 14px;
              cursor:pointer;
              display:flex;
              justify-content:space-between;
              align-items:center;
              font-size:14px;
              font-weight:600;
            }
            .py-module summary::-webkit-details-marker{display:none;}
            .py-module summary::after{
              content:"▾";
              font-size:12px;
              color:#9ca3af;
              transition:transform .2s;
            }
            .py-module[open] summary::after{transform:rotate(-180deg);}
            .py-module-title{
              display:flex;
              gap:8px;
              flex-wrap:wrap;
              align-items:baseline;
            }
            .py-module-label{
              font-size:11px;
              text-transform:uppercase;
              letter-spacing:.08em;
              color:#111827;   /* dark text */
              font-weight:700; /* bold */
            }
            .py-module-content{
              padding:0 14px 10px 24px;
              font-size:13px;
              color:#4b5563;
            }
            .py-module-content ul{
              margin:0;
              padding-left:16px;
            }
            .py-module-content li{margin-bottom:4px;}
            
            /* RIGHT-COLUMN DETAILS */
            .py-detail-list{
              list-style:none;
              padding:0;
              margin:0 0 16px;
              font-size:14px;
            }
            .py-detail-item{
              display:flex;
              gap:10px;
              margin-bottom:10px;
            }
            .py-detail-icon{
              width:26px;
              height:26px;
              border-radius:999px;
              background:#e0f2fe;
              display:flex;
              align-items:center;
              justify-content:center;
              font-size:13px;
              color:#1d4ed8;
              flex-shrink:0;
            }
            .py-detail-text strong{
              display:block;
              font-weight:600;
              color:#111827;
            }
            .py-detail-text span{
              font-size:13px;
              color:#4b5563;
            }
            
            /* CTA BUTTON */
            .py-cta-btn{
              display:block;
              width:100%;
              border-radius:999px;
              padding:11px 16px;
              border:none;
              text-align:center;
              text-decoration:none;
              background:linear-gradient(135deg,#38bdf8,#6366f1);
              color:#fff !important;
              font-weight:600;
              font-size:15px;
              box-shadow:0 14px 30px rgba(37,99,235,.45);
              transition:transform .15s,box-shadow .15s,filter .15s,color .15s;
            }
            .py-cta-btn:hover{
              transform:translateY(-1px);
              filter:brightness(1.04);
              box-shadow:0 18px 40px rgba(37,99,235,.6);
              color:#fff !important;
            }
            
            /* TOP COMPANIES */
            .py-companies{
              background:#e0f2fe;
              padding:40px 20px 40px;
            }
            .py-companies-inner{
              max-width:1160px;
              margin:0 auto;
              text-align:center;
            }
            .py-companies h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .py-companies p{
              margin:0 0 20px;
              font-size:14px;
              color:#4b5563;
            }
            .py-logo-row{
              display:flex;
              flex-wrap:wrap;
              justify-content:center;
              gap:18px;
            }
            .py-logo-card{
              width:130px;
              height:62px;
              border-radius:14px;
              background:#ffffff;
              display:flex;
              align-items:center;
              justify-content:center;
              box-shadow:0 8px 18px rgba(15,23,42,.08);
              transition:transform .18s,box-shadow .18s;
            }
            .py-logo-card img{
              max-height:40px;
              max-width:100%;
            }
            .py-logo-card:hover{
              transform:translateY(-3px);
              box-shadow:0 14px 30px rgba(15,23,42,.16);
            }
            
            /* EXTRA COURSE DETAILS SECTION */
            .py-highlights{
              background:#e0f2fe;
              padding:10px 20px 50px;
            }
            .py-highlights-inner{
              max-width:1160px;
              margin:0 auto;
              display:grid;
              grid-template-columns:minmax(0,1.7fr) minmax(0,1.1fr);
              gap:28px;
              align-items:center;
            }
            .py-highlights-heading{
              margin-bottom:12px;
            }
            .py-highlights-heading h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .py-highlights-heading p{
              margin:0;
              font-size:14px;
              color:#4b5563;
            }
            .py-highlight-grid{
              margin-top:18px;
              display:grid;
              grid-template-columns:repeat(3,minmax(0,1fr));
              gap:14px;
            }
            .py-highlight-card{
              background:#ffffff;
              border-radius:16px;
              padding:14px 12px;
              box-shadow:0 10px 24px rgba(15,23,42,.08);
            }
            .py-highlight-icon{
              width:38px;
              height:38px;
              border-radius:999px;
              background:linear-gradient(135deg,#38bdf8,#6366f1);
              display:flex;
              align-items:center;
              justify-content:center;
              color:#fff;
              font-size:20px;
              margin-bottom:8px;
            }
            .py-highlight-card h3{
              font-size:14px;
              margin:0 0 4px;
              color:#0f172a;
            }
            .py-highlight-card p{
              font-size:13px;
              margin:0;
              color:#4b5563;
            }
            
            /* representation "image" block */
            .py-highlights-visual{
              display:flex;
              justify-content:center;
            }
            .py-dashboard{
              width:100%;
              max-width:340px;
              background:#ffffff;
              border-radius:20px;
              padding:14px 14px 18px;
              box-shadow:0 18px 40px rgba(37,99,235,.35);
            }
            .py-dashboard-header{
              display:flex;
              justify-content:space-between;
              align-items:center;
              margin-bottom:10px;
              font-size:12px;
              color:#0f172a;
            }
            .py-dashboard-dots{
              display:flex;
              gap:4px;
            }
            .py-dashboard-dots span{
              width:7px;
              height:7px;
              border-radius:999px;
              background:#bfdbfe;
            }
            .py-dashboard-graph{
              display:flex;
              gap:6px;
              align-items:flex-end;
              height:90px;
              margin-bottom:12px;
            }
            .py-dashboard-bar{
              flex:1;
              border-radius:8px 8px 2px 2px;
              background:linear-gradient(180deg,#38bdf8,#1d4ed8);
            }
            .py-dashboard-bar:nth-child(2){height:55%;}
            .py-dashboard-bar:nth-child(3){height:80%;}
            .py-dashboard-bar:nth-child(4){height:40%;}
            .py-dashboard-bar:nth-child(5){height:70%;}
            .py-dashboard-bar:nth-child(1){height:30%;}
            .py-dashboard-tags{
              display:flex;
              flex-wrap:wrap;
              gap:6px;
              font-size:11px;
            }
            .py-dashboard-tags span{
              padding:3px 7px;
              border-radius:999px;
              background:#eff6ff;
              color:#1d4ed8;
            }
            
            /* TOOLS SECTION */
            .py-tools{
              background:#e0f2fe;
              padding:0 20px 50px;
            }
            .py-tools-inner{
              max-width:1160px;
              margin:0 auto;
              text-align:center;
            }
            .py-tools-inner h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .py-tools-inner p{
              margin:0 0 20px;
              font-size:14px;
              color:#4b5563;
            }
            .py-tools-grid{
              display:flex;
              flex-wrap:wrap;
              justify-content:center;
              gap:16px;
            }
            .py-tools-card{
              width:140px;
              height:90px;
              border-radius:16px;
              background:#ffffff;
              box-shadow:0 10px 26px rgba(15,23,42,.12);
              display:flex;
              flex-direction:column;
              align-items:center;
              justify-content:center;
              padding:8px;
            }
            .py-tools-logo{
              max-height:36px;
              max-width:90px;
              margin-bottom:4px;
            }
            .py-tools-card span{
              font-size:12px;
              color:#111827;
            }
            
            /* MORE DETAILS SECTION */
            .py-more{
              background:#e0f2fe;
              padding:0 20px 50px;
            }
            .py-more-inner{
              max-width:1160px;
              margin:0 auto;
            }
            .py-more-header{
              text-align:center;
              margin-bottom:20px;
            }
            .py-more-header h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .py-more-header p{
              margin:0;
              font-size:14px;
              color:#4b5563;
            }
            .py-more-grid{
              display:grid;
              grid-template-columns:repeat(3,minmax(0,1fr));
              gap:18px;
            }
            .py-more-card{
              background:#ffffff;
              border-radius:18px;
              padding:16px 14px;
              box-shadow:0 12px 30px rgba(15,23,42,.12);
              display:flex;
              flex-direction:column;
              gap:8px;
            }
            .py-more-top{
              display:flex;
              align-items:flex-start;
              gap:8px;
            }
            .py-more-icon{
              width:32px;
              height:32px;
              border-radius:999px;
              background:linear-gradient(135deg,#38bdf8,#6366f1);
              color:#fff;
              display:flex;
              align-items:center;
              justify-content:center;
              font-size:18px;
            }
            .py-more-title{
              font-size:15px;
              font-weight:600;
              margin:0;
              color:#0f172a;
            }
            .py-more-text{
              font-size:13px;
              color:#4b5563;
              margin:0;
            }
            .py-tool-logos{
              margin-top:12px;
              display:flex;
              flex-wrap:wrap;
              gap:10px;
              align-items:center;
              justify-content:center;
              width:100%;
            }
            .py-tool-logo{
              max-height:32px;
              width:auto;
              filter:drop-shadow(0 2px 4px rgba(15,23,42,.18));
            }
            .py-tool-logos img{
              max-height:32px !important;
              width:auto !important;
              object-fit:contain;
            }
            .py-roles-image{
              margin-top:8px;
              display:flex;
              flex-wrap:wrap;
              gap:6px;
            }
            .py-role-tag{
              padding:4px 8px;
              border-radius:999px;
              font-size:11px;
              background:#eff6ff;
              color:#1d4ed8;
            }
            .py-journey{
              margin-top:8px;
              border-left:2px solid #bfdbfe;
              padding-left:10px;
            }
            .py-journey-step{
              position:relative;
              padding-left:10px;
              margin-bottom:6px;
              font-size:12px;
              color:#4b5563;
            }
            .py-journey-step::before{
              content:"";
              position:absolute;
              left:-11px;
              top:5px;
              width:8px;
              height:8px;
              border-radius:999px;
              background:#38bdf8;
            }
            
            /* ENQUIRY / FORM SECTION */
            .py-enquiry{
              background:linear-gradient(135deg,#dbeafe,#e0f2fe);
              padding:40px 20px 50px;
            }
            .py-enquiry-inner{
              max-width:900px;
              margin:0 auto;
            }
            .py-enquiry-card{
              background:#ffffff;
              border-radius:22px;
              padding:24px 22px 18px;
              box-shadow:0 18px 40px rgba(37,99,235,.2);
              border-top:4px solid #38bdf8;
            }
            .py-enquiry-header{
              display:flex;
              align-items:flex-start;
              gap:10px;
              margin-bottom:10px;
            }
            .py-enquiry-icon{
              width:32px;
              height:32px;
              border-radius:999px;
              background:radial-gradient(circle at 30% 20%,#38bdf8,#6366f1);
              display:flex;
              align-items:center;
              justify-content:center;
              color:#fff;
              font-size:18px;
            }
            .py-enquiry-title{
              font-size:18px;
              font-weight:700;
              margin:0;
              color:#0f172a;
            }
            .py-enquiry-text{
              font-size:14px;
              color:#4b5563;
              margin:2px 0 12px;
            }
            
            /* FADE-IN ON SCROLL */
            .py-section{
              opacity:0;
              transform:translateY(24px);
              transition:opacity .7s ease-out, transform .7s ease-out;
            }
            .py-section.py-visible{
              opacity:1;
              transform:translateY(0);
            }
            
            /* RESPONSIVE */
            @media (max-width:900px){
              .py-hero{padding:50px 18px;}
              .fs-hero-title{font-size:48px;}
              .py-main-inner{
                grid-template-columns:minmax(0,1fr);
              }
              .py-highlights-inner{
                grid-template-columns:minmax(0,1fr);
              }
              .py-more-grid{
                grid-template-columns:minmax(0,1fr);
              }
            }
            @media (max-width:640px){
              .py-hero{padding:38px 16px;}
              .py-hero-meta{flex-direction:column;}
              .py-highlight-grid{
                grid-template-columns:minmax(0,1fr);
              }
            }
            `}),e.jsxs("div",{className:"py-course",id:"top",children:[e.jsx(a,{className:"py-hero py-section",children:e.jsxs("div",{className:"py-hero-content",children:[e.jsx("span",{className:"py-badge",children:"Python Programming"}),e.jsx("h1",{className:"fs-hero-title",children:"Master Python Programming: Get Certified and Build Real-World Applications"}),e.jsx("p",{className:"fs-hero-sub",children:"Learn Python from the ground up, master core programming concepts, work with data using popular libraries, and prepare for Python certification exams and real‑world roles."}),e.jsxs("div",{className:"py-hero-meta",children:[e.jsx("span",{children:"Covers core Python, OOP, files, modules & virtual envs"}),e.jsx("span",{children:"Hands‑on projects using NumPy, Pandas & APIs"}),e.jsx("span",{children:"Certification‑aligned practice tests & interview prep"})]})]})}),e.jsx("main",{className:"py-main py-section",children:e.jsxs("div",{className:"py-main-inner",children:[e.jsxs("div",{className:"py-left",children:[e.jsxs(a,{className:"py-card",children:[e.jsx("h2",{children:"About This Course"}),e.jsxs("div",{className:"py-about-text",children:[e.jsx("p",{children:"This course gives you a solid foundation in Python programming. You’ll begin with syntax, data types and control flow, move into functions and object‑oriented programming, and then explore modules, packages and error handling."}),e.jsx("p",{children:"You’ll also work with files, CSV/JSON data, virtual environments and popular libraries like NumPy and Pandas. The syllabus is aligned with common Python certification exams and technical interview expectations."})]})]}),e.jsxs(a,{className:"py-card",children:[e.jsx("h2",{children:"Syllabus Covered"}),e.jsxs("details",{className:"py-module",open:i===0,children:[e.jsx("summary",{onClick:s=>n(0,s),children:e.jsxs("div",{className:"py-module-title",children:[e.jsx("span",{className:"py-module-label",children:"Module 1"}),e.jsx("span",{children:"Python Basics & Core Concepts"})]})}),e.jsx("div",{className:"py-module-content",children:e.jsxs("ul",{children:[e.jsx("li",{children:"Python Installation, IDLE & VS Code Setup"}),e.jsx("li",{children:"Variables, Data Types & Type Conversion"}),e.jsx("li",{children:"Operators, Control Flow (if-else, loops)"}),e.jsx("li",{children:"Functions, Lambda Expressions & Recursion"}),e.jsx("li",{children:"String Manipulation & Regular Expressions"})]})})]}),e.jsxs("details",{className:"py-module",open:i===1,children:[e.jsx("summary",{onClick:s=>n(1,s),children:e.jsxs("div",{className:"py-module-title",children:[e.jsx("span",{className:"py-module-label",children:"Module 2"}),e.jsx("span",{children:"Data Structures & OOPs"})]})}),e.jsx("div",{className:"py-module-content",children:e.jsxs("ul",{children:[e.jsx("li",{children:"Lists, Tuples, Sets & Dictionaries"}),e.jsx("li",{children:"Object-Oriented Programming (Classes & Objects)"}),e.jsx("li",{children:"Inheritance, Polymorphism & Encapsulation"}),e.jsx("li",{children:"Exception Handling & File I/O"}),e.jsx("li",{children:"Modules, Packages & Virtual Environments"})]})})]}),e.jsxs("details",{className:"py-module",open:i===2,children:[e.jsx("summary",{onClick:s=>n(2,s),children:e.jsxs("div",{className:"py-module-title",children:[e.jsx("span",{className:"py-module-label",children:"Module 3"}),e.jsx("span",{children:"Libraries for Data Science"})]})}),e.jsx("div",{className:"py-module-content",children:e.jsxs("ul",{children:[e.jsx("li",{children:"NumPy: Arrays & Mathematical Operations"}),e.jsx("li",{children:"Pandas: DataFrames, Cleaning & Analysis"}),e.jsx("li",{children:"Matplotlib & Seaborn: Data Visualisation"}),e.jsx("li",{children:"Introduction to Scikit-Learn (Basic ML concepts)"}),e.jsx("li",{children:"Mini-Project: Data Analysis Dashboard"})]})})]}),e.jsxs("details",{className:"py-module",open:i===3,children:[e.jsx("summary",{onClick:s=>n(3,s),children:e.jsxs("div",{className:"py-module-title",children:[e.jsx("span",{className:"py-module-label",children:"Module 4"}),e.jsx("span",{children:"Web Development & Automation"})]})}),e.jsx("div",{className:"py-module-content",children:e.jsxs("ul",{children:[e.jsx("li",{children:"Introduction to Django / Flask (Web Frameworks)"}),e.jsx("li",{children:"REST APIs & JSON Handling"}),e.jsx("li",{children:"Web Scraping (BeautifulSoup / Selenium)"}),e.jsx("li",{children:"Automating Tasks with Python Scripts"}),e.jsx("li",{children:"Capstone Project: Full-fledged Application"})]})})]})]})]}),e.jsx("aside",{className:"py-right",children:e.jsxs(a,{className:"py-card",children:[e.jsx("h2",{children:"Course Details"}),e.jsxs("ul",{className:"py-detail-list",children:[e.jsxs("li",{className:"py-detail-item",children:[e.jsx("div",{className:"py-detail-icon",children:e.jsx(x,{size:20})}),e.jsxs("div",{className:"py-detail-text",children:[e.jsx("strong",{children:"Duration"}),e.jsx("span",{children:"12 Weeks (80+ hours)"})]})]}),e.jsxs("li",{className:"py-detail-item",children:[e.jsx("div",{className:"py-detail-icon",children:e.jsx(l,{size:20})}),e.jsxs("div",{className:"py-detail-text",children:[e.jsx("strong",{children:"Skill Level"}),e.jsx("span",{children:"Beginner to Advanced"})]})]}),e.jsxs("li",{className:"py-detail-item",children:[e.jsx("div",{className:"py-detail-icon",children:e.jsx(h,{size:20})}),e.jsxs("div",{className:"py-detail-text",children:[e.jsx("strong",{children:"Includes"}),e.jsx("span",{children:"Live Classes, Projects & Placement Support"})]})]}),e.jsxs("li",{className:"py-detail-item",children:[e.jsx("div",{className:"py-detail-icon",children:e.jsx(m,{size:20})}),e.jsxs("div",{className:"py-detail-text",children:[e.jsx("strong",{children:"Next Batch"}),e.jsx("span",{children:"Coming Soon"})]})]}),e.jsxs("li",{className:"py-detail-item",children:[e.jsx("div",{className:"py-detail-icon",children:e.jsx(t,{size:20})}),e.jsxs("div",{className:"py-detail-text",children:[e.jsx("strong",{children:"Certificate"}),e.jsx("span",{children:"Python Developer Certification"})]})]})]}),e.jsx("a",{href:"#top",className:"py-cta-btn",children:"Enroll Now & Start Learning"})]})})]})}),e.jsx(a,{className:"py-companies py-section",children:e.jsxs("div",{className:"py-companies-inner",children:[e.jsx("h2",{children:"Top Companies Hiring Python Developers"}),e.jsx("p",{children:"Python powers web apps, data pipelines, ML systems and automation across modern companies."}),e.jsxs("div",{className:"py-logo-row",children:[e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:w,alt:"Google"})}),e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:k,alt:"Microsoft"})}),e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:P,alt:"AWS"})}),e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:C,alt:"IBM"})}),e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:S,alt:"Meta"})}),e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:z,alt:"Netflix"})}),e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:L,alt:"Infosys"})}),e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:A,alt:"Accenture"})})]})]})}),e.jsx(a,{className:"py-highlights py-section",children:e.jsxs("div",{className:"py-highlights-inner",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"py-highlights-heading",children:[e.jsx("h2",{children:"What You Will Achieve in This Python Certification Program"}),e.jsx("p",{children:"Develop strong programming fundamentals and hands‑on skills used across Python jobs."})]}),e.jsxs("div",{className:"py-highlight-grid",children:[e.jsxs("div",{className:"py-highlight-card",children:[e.jsx("div",{className:"py-highlight-icon",children:e.jsx(g,{size:24})}),e.jsx("h3",{children:"Versatile Language"}),e.jsx("p",{children:"Master Python’s simple syntax to build web apps, analyse data, and automate tasks."})]}),e.jsxs("div",{className:"py-highlight-card",children:[e.jsx("div",{className:"py-highlight-icon",children:e.jsx(y,{size:24})}),e.jsx("h3",{children:"Data Science Ready"}),e.jsx("p",{children:"Learn powerful libraries like Pandas, NumPy, and Matplotlib for data analysis."})]}),e.jsxs("div",{className:"py-highlight-card",children:[e.jsx("div",{className:"py-highlight-icon",children:e.jsx(f,{size:24})}),e.jsx("h3",{children:"Backend Development"}),e.jsx("p",{children:"Build robust backends using frameworks like Django and Flask."})]}),e.jsxs("div",{className:"py-highlight-card",children:[e.jsx("div",{className:"py-highlight-icon",children:e.jsx(d,{size:24})}),e.jsx("h3",{children:"AI & ML Foundation"}),e.jsx("p",{children:"Get started with machine learning concepts using Scikit-Learn."})]}),e.jsxs("div",{className:"py-highlight-card",children:[e.jsx("div",{className:"py-highlight-icon",children:e.jsx(j,{size:24})}),e.jsx("h3",{children:"Automation Scripts"}),e.jsx("p",{children:"Write scripts to automate repetitive tasks and improve productivity."})]}),e.jsxs("div",{className:"py-highlight-card",children:[e.jsx("div",{className:"py-highlight-icon",children:e.jsx(l,{size:24})}),e.jsx("h3",{children:"High Demand"}),e.jsx("p",{children:"Python developers are among the most sought-after professionals globally."})]})]})]}),e.jsx("div",{className:"py-highlights-visual",children:e.jsxs("div",{className:"py-dashboard",children:[e.jsxs("div",{className:"py-dashboard-header",children:[e.jsx("span",{children:"Python Script Performance"}),e.jsxs("div",{className:"py-dashboard-dots",children:[e.jsx("span",{}),e.jsx("span",{}),e.jsx("span",{})]})]}),e.jsxs("div",{className:"py-dashboard-graph",children:[e.jsx("div",{className:"py-dashboard-bar"}),e.jsx("div",{className:"py-dashboard-bar"}),e.jsx("div",{className:"py-dashboard-bar"}),e.jsx("div",{className:"py-dashboard-bar"}),e.jsx("div",{className:"py-dashboard-bar"})]}),e.jsxs("div",{className:"py-dashboard-tags",children:[e.jsx("span",{children:"Run Time"}),e.jsx("span",{children:"Memory"}),e.jsx("span",{children:"Tests"}),e.jsx("span",{children:"Coverage"})]})]})})]})}),e.jsx(a,{className:"py-tools py-section",children:e.jsxs("div",{className:"py-tools-inner",children:[e.jsx("h2",{children:"Tools & Libraries You Will Use"}),e.jsx("p",{children:"Practice with the most popular tools in the Python ecosystem."}),e.jsxs("div",{className:"py-tools-grid",children:[e.jsxs("div",{className:"py-tools-card",children:[e.jsx("img",{className:"py-tools-logo",src:p,alt:"Python"}),e.jsx("span",{children:"Python 3.x"})]}),e.jsxs("div",{className:"py-tools-card",children:[e.jsx("img",{className:"py-tools-logo",src:D,alt:"Jupyter"}),e.jsx("span",{children:"Jupyter Notebook"})]}),e.jsxs("div",{className:"py-tools-card",children:[e.jsx("img",{className:"py-tools-logo",src:O,alt:"VS Code"}),e.jsx("span",{children:"VS Code / IDEs"})]}),e.jsxs("div",{className:"py-tools-card",children:[e.jsx("img",{className:"py-tools-logo",src:T,alt:"NumPy"}),e.jsx("span",{children:"NumPy"})]}),e.jsxs("div",{className:"py-tools-card",children:[e.jsx("img",{className:"py-tools-logo",src:E,alt:"Pandas"}),e.jsx("span",{children:"Pandas"})]}),e.jsxs("div",{className:"py-tools-card",children:[e.jsx("img",{className:"py-tools-logo",src:M,alt:"pytest"}),e.jsx("span",{children:"pytest / unittest"})]}),e.jsxs("div",{className:"py-tools-card",children:[e.jsx("img",{className:"py-tools-logo",src:v,alt:"Git"}),e.jsx("span",{children:"Git & GitHub"})]})]})]})}),e.jsx(a,{className:"py-more py-section",children:e.jsxs("div",{className:"py-more-inner",children:[e.jsxs("div",{className:"py-more-header",children:[e.jsx("h2",{children:"Roles & Learning Journey"}),e.jsx("p",{children:"See how this Python course maps to real roles and how your skills grow week by week."})]}),e.jsxs("div",{className:"py-more-grid",children:[e.jsxs("div",{className:"py-more-card",children:[e.jsxs("div",{className:"py-more-top",children:[e.jsx("div",{className:"py-more-icon",children:e.jsx(d,{size:24})}),e.jsxs("div",{children:[e.jsx("h3",{className:"py-more-title",children:"Power of Python"}),e.jsx("p",{className:"py-more-text",children:"From simple scripts to complex AI models, Python powers the modern tech world."})]})]}),e.jsx("div",{className:"py-tool-logos",children:e.jsx("img",{className:"py-tool-logo",src:p,alt:"Python"})})]}),e.jsxs("div",{className:"py-more-card",children:[e.jsxs("div",{className:"py-more-top",children:[e.jsx("div",{className:"py-more-icon",children:e.jsx(u,{size:24})}),e.jsxs("div",{children:[e.jsx("h3",{className:"py-more-title",children:"Roles You Can Target"}),e.jsx("p",{className:"py-more-text",children:"With Python skills, you can aim for diverse roles in tech."})]})]}),e.jsxs("div",{className:"py-roles-image",children:[e.jsx("span",{className:"py-role-tag",children:"Python Developer"}),e.jsx("span",{className:"py-role-tag",children:"Data Analyst"}),e.jsx("span",{className:"py-role-tag",children:"Backend Developer"}),e.jsx("span",{className:"py-role-tag",children:"Automation Engineer"})]})]}),e.jsxs("div",{className:"py-more-card",children:[e.jsxs("div",{className:"py-more-top",children:[e.jsx("div",{className:"py-more-icon",children:e.jsx(t,{size:24})}),e.jsxs("div",{children:[e.jsx("h3",{className:"py-more-title",children:"Your Learning Path"}),e.jsx("p",{className:"py-more-text",children:"Step-by-step mastery from syntax to building deployable applications."})]})]}),e.jsxs("div",{className:"py-journey",children:[e.jsx("div",{className:"py-journey-step",children:"Weeks 1-3: Python Basics & Logic"}),e.jsx("div",{className:"py-journey-step",children:"Weeks 4-6: OOPs & File Handling"}),e.jsx("div",{className:"py-journey-step",children:"Weeks 7-9: Data Science Libraries"}),e.jsx("div",{className:"py-journey-step",children:"Weeks 10-12: Web Dev & Capstone"})]})]})]})]})})]})]})};export{F as default};
