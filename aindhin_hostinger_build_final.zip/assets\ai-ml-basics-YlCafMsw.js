const s="/assets/aiml-U87TC2R-.webp";export{s as a};
