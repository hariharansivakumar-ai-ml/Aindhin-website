import{r as n,j as e,n as x,aP as o,aj as h,ag as m,y as t,$ as g,aS as y,b0 as f,x as c,aX as j,a_ as u}from"./react-vendor-DYsDEQNa.js";import{g as b}from"./git-Bqls52A0.js";import{g as v,m as N,a as w,i as k,b as S,n as P,c as C,d as z}from"./accenture-C3hx-HbI.js";import{u as L,m as M}from"./ui-vendor-DRkt0NXn.js";import"./vendor-CgLk17x9.js";import"./sentry-vendor-DJFyW8md.js";const D="/assets/java_hero-CKGmQAvk.webp",d="data:image/svg+xml,%3c?xml%20version='1.0'%20encoding='utf-8'?%3e%3c!DOCTYPE%20svg%20PUBLIC%20'-//W3C//DTD%20SVG%201.1//EN'%20'http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd'%3e%3csvg%20version='1.1'%20xmlns:dc='http://purl.org/dc/elements/1.1/'%20xmlns:cc='http://web.resource.org/cc/'%20xmlns:rdf='http://www.w3.org/1999/02/22-rdf-syntax-ns%23'%20xmlns:svg='http://www.w3.org/2000/svg'%20xmlns='http://www.w3.org/2000/svg'%20xmlns:xlink='http://www.w3.org/1999/xlink'%20x='0px'%20y='0px'%20width='110px'%20height='110px'%20viewBox='0.21%20-0.077%20110%20110'%20enable-background='new%200.21%20-0.077%20110%20110'%20xml:space='preserve'%3e%3clinearGradient%20id='SVGID_1_'%20gradientUnits='userSpaceOnUse'%20x1='63.8159'%20y1='56.6829'%20x2='118.4934'%20y2='1.8225'%20gradientTransform='matrix(1%200%200%20-1%20-53.2974%2066.4321)'%3e%3cstop%20offset='0'%20style='stop-color:%23387EB8'/%3e%3cstop%20offset='1'%20style='stop-color:%23366994'/%3e%3c/linearGradient%3e%3cpath%20fill='url(%23SVGID_1_)'%20d='M55.023-0.077c-25.971,0-26.25,10.081-26.25,12.156c0,3.148,0,12.594,0,12.594h26.75v3.781%20c0,0-27.852,0-37.375,0c-7.949,0-17.938,4.833-17.938,26.25c0,19.673,7.792,27.281,15.656,27.281c2.335,0,9.344,0,9.344,0%20s0-9.765,0-13.125c0-5.491,2.721-15.656,15.406-15.656c15.91,0,19.971,0,26.531,0c3.902,0,14.906-1.696,14.906-14.406%20c0-13.452,0-17.89,0-24.219C82.054,11.426,81.515-0.077,55.023-0.077z%20M40.273,8.392c2.662,0,4.813,2.15,4.813,4.813%20c0,2.661-2.151,4.813-4.813,4.813s-4.813-2.151-4.813-4.813C35.46,10.542,37.611,8.392,40.273,8.392z'/%3e%3clinearGradient%20id='SVGID_2_'%20gradientUnits='userSpaceOnUse'%20x1='97.0444'%20y1='21.6321'%20x2='155.6665'%20y2='-34.5308'%20gradientTransform='matrix(1%200%200%20-1%20-53.2974%2066.4321)'%3e%3cstop%20offset='0'%20style='stop-color:%23FFE052'/%3e%3cstop%20offset='1'%20style='stop-color:%23FFC331'/%3e%3c/linearGradient%3e%3cpath%20fill='url(%23SVGID_2_)'%20d='M55.397,109.923c25.959,0,26.282-10.271,26.282-12.156c0-3.148,0-12.594,0-12.594H54.897v-3.781%20c0,0,28.032,0,37.375,0c8.009,0,17.938-4.954,17.938-26.25c0-23.322-10.538-27.281-15.656-27.281c-2.336,0-9.344,0-9.344,0%20s0,10.216,0,13.125c0,5.491-2.631,15.656-15.406,15.656c-15.91,0-19.476,0-26.532,0c-3.892,0-14.906,1.896-14.906,14.406%20c0,14.475,0,18.265,0,24.219C28.366,100.497,31.562,109.923,55.397,109.923z%20M70.148,101.454c-2.662,0-4.813-2.151-4.813-4.813%20s2.15-4.813,4.813-4.813c2.661,0,4.813,2.151,4.813,4.813S72.809,101.454,70.148,101.454z'/%3e%3c/svg%3e",A="/assets/jupyter-BENGM-un.svg",I="/assets/vscode-ofeWxTsy.svg",T="data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20721.86%20324.74'%3e%3cdefs%3e%3cstyle%3e.cls-1{fill:%234d77cf;}.cls-2{fill:%234dabcf;}%3c/style%3e%3c/defs%3e%3cg%20id='Layer_1'%3e%3cpath%20class='cls-1'%20d='M299.23,125a5.76,5.76,0,0,1,1.62.45,5.58,5.58,0,0,1,1.38.93,17,17,0,0,1,1.49,1.62l41.51,52.47c-.17-1.67-.28-3.31-.36-4.88s-.12-3.07-.12-4.47V124.83h17.87v87.38H352.06a9.68,9.68,0,0,1-3.95-.72,8.47,8.47,0,0,1-3.12-2.64l-41.21-52c.13,1.51.22,3,.3,4.46s.13,2.83.13,4.11v46.84H286.33V124.83H297A17.21,17.21,0,0,1,299.23,125Z'/%3e%3cpath%20class='cls-1'%20d='M392,150v39.46q0,4.62,2.1,7.14a7.62,7.62,0,0,0,6.18,2.52,13.26,13.26,0,0,0,5.73-1.26,21.37,21.37,0,0,0,5.19-3.54V150h18.59v62.19H418.28a4.39,4.39,0,0,1-4.57-3.12l-1.13-3.6a37.32,37.32,0,0,1-3.72,3.16,23.32,23.32,0,0,1-4.11,2.39A24.55,24.55,0,0,1,400,212.6a25,25,0,0,1-5.51.57,21.75,21.75,0,0,1-9-1.77,18.67,18.67,0,0,1-6.63-4.94,21.68,21.68,0,0,1-4.08-7.5,31,31,0,0,1-1.38-9.48V150Z'/%3e%3cpath%20class='cls-1'%20d='M441.78,212.21V150H453.3a5.13,5.13,0,0,1,2.91.78,4.21,4.21,0,0,1,1.65,2.34l1,3.36a33.22,33.22,0,0,1,3.23-3,20.83,20.83,0,0,1,3.63-2.34,19.68,19.68,0,0,1,9.15-2.13,14.6,14.6,0,0,1,9.33,2.91,18.14,18.14,0,0,1,5.6,7.76,18.71,18.71,0,0,1,3.81-4.92,20.42,20.42,0,0,1,4.86-3.29,23.69,23.69,0,0,1,5.51-1.86,28.63,28.63,0,0,1,5.8-.6,26.3,26.3,0,0,1,9.47,1.59,18.05,18.05,0,0,1,6.93,4.62,20.15,20.15,0,0,1,4.23,7.44,32,32,0,0,1,1.44,10v39.52h-18.6V172.69q0-9.66-8.27-9.65a8.46,8.46,0,0,0-6.27,2.49q-2.49,2.47-2.49,7.16v39.52H477.65V172.69q0-5.34-2.1-7.5c-1.4-1.44-3.46-2.15-6.18-2.15a10.53,10.53,0,0,0-4.77,1.13,17.72,17.72,0,0,0-4.23,3.06v45Z'/%3e%3cpath%20class='cls-1'%20d='M562.93,183v29.21H542.66V124.83h30.82A50.86,50.86,0,0,1,589.35,127a30.49,30.49,0,0,1,10.91,6,23.36,23.36,0,0,1,6.33,9.06,30.63,30.63,0,0,1,2,11.27,33.11,33.11,0,0,1-2.1,12,24.08,24.08,0,0,1-6.42,9.36,30,30,0,0,1-10.94,6.08A49.9,49.9,0,0,1,573.48,183Zm0-15.29h10.55c5.28,0,9.08-1.25,11.4-3.78s3.48-6,3.48-10.55a15.79,15.79,0,0,0-.9-5.46,11.11,11.11,0,0,0-2.73-4.23,12.41,12.41,0,0,0-4.62-2.73,20.71,20.71,0,0,0-6.63-1H562.93Z'/%3e%3cpath%20class='cls-1'%20d='M644.61,228.35a6.69,6.69,0,0,1-2,2.72,6.62,6.62,0,0,1-3.84.87H624.82l12-25.18L612,150h16.43a5.25,5.25,0,0,1,3.36,1,5.15,5.15,0,0,1,1.68,2.28l10.19,26.81A59,59,0,0,1,646,187.5c.4-1.28.84-2.54,1.32-3.77s.94-2.5,1.38-3.78l9.24-26.69a4.5,4.5,0,0,1,1.89-2.31,5.4,5.4,0,0,1,3-.93h15Z'/%3e%3cpolygon%20class='cls-2'%20points='132.38%2096.4%2095.25%2077.66%2054.49%2098%2092.63%20117.15%20132.38%2096.4'/%3e%3cpolygon%20class='cls-2'%20points='149.41%20104.99%20188.34%20124.65%20147.95%20144.93%20109.75%20125.75%20149.41%20104.99'/%3e%3cpolygon%20class='cls-2'%20points='201.41%2077.94%20241.41%2098%20205.63%20115.96%20166.62%2096.28%20201.41%2077.94'/%3e%3cpolygon%20class='cls-2'%20points='184.19%2069.3%20148.18%2051.24%20112.56%2069.02%20149.67%2087.73%20184.19%2069.3'/%3e%3cpolygon%20class='cls-2'%20points='156.04%20224.36%20156.04%20273.5%20199.66%20251.73%20199.62%20202.57%20156.04%20224.36'/%3e%3cpolygon%20class='cls-2'%20points='199.6%20185.41%20199.55%20136.77%20156.04%20158.4%20156.04%20207.06%20199.6%20185.41'/%3e%3cpolygon%20class='cls-2'%20points='251.97%20176.3%20251.97%20225.63%20214.76%20244.19%20214.73%20195.09%20251.97%20176.3'/%3e%3cpolygon%20class='cls-2'%20points='251.97%20159.05%20251.97%20110.71%20214.69%20129.24%20214.72%20177.98%20251.97%20159.05'/%3e%3cpath%20class='cls-1'%20d='M140.64,158.4l-29.38-14.78v63.84S75.32,131,72,124.13c-.43-.89-2.19-1.86-2.64-2.1C62.88,118.65,44,109.09,44,109.09V221.92l26.12,14v-59s35.55,68.32,35.92,69.07,3.92,7.94,7.74,10.47c5.07,3.37,26.84,16.46,26.84,16.46Z'/%3e%3c/g%3e%3c/svg%3e",O="data:image/svg+xml,%3csvg%20id='Layer_1'%20data-name='Layer%201'%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20818.63%20331.21'%3e%3cdefs%3e%3cstyle%3e.cls-1{fill:%23130754;}.cls-2{fill:%23ffca00;}.cls-3{fill:%23e70488;}%3c/style%3e%3c/defs%3e%3ctitle%3eArtboard%2063%3c/title%3e%3cpath%20class='cls-1'%20d='M290.85,199.21c-10.27,0-20.73-4.25-27.28-12.58v45H243l0-111.09h18.6l.71,12.22c6.38-9.39,17.71-14.35,28.52-14.35,20.73,0,36,17.37,36,40.4S311.58,199.22,290.85,199.21Zm-6.37-65.55c-12.05,0-21.79,9.39-21.79,25.16S272.43,184,284.48,184s21.79-9.39,21.79-25.16S296.53,133.66,284.48,133.66Z'/%3e%3cpath%20class='cls-1'%20d='M404.36,197.1l-.71-12.22c-6.38,9.39-17.72,14.35-28.53,14.34-20.73,0-36-17.36-36-40.39s15.24-40.4,36-40.39c10.81,0,22.15,5,28.53,14.35l.71-12.22H423V197.1Zm-22.85-63.43c-12.05,0-21.79,9.39-21.8,25.16S369.45,184,381.5,184s21.8-9.39,21.8-25.16S393.56,133.67,381.51,133.67Z'/%3e%3cpath%20class='cls-1'%20d='M494.87,197.11V154.77c0-14.88-5.13-19.84-14.52-19.84-9.75,0-20.38,8.85-20.38,19.48v42.7H439.41V120.57H458.2l.89,14.18c5.14-9.75,16.65-16.3,28.35-16.3,20.37,0,28,14.18,28,33.13v45.54Z'/%3e%3cpath%20class='cls-1'%20d='M590.77,197.13l-.71-12.23c-6.38,9.39-17.72,14.35-28.52,14.35-20.73,0-36-17.37-36-40.4s15.24-40.39,36-40.39c10.27,0,20.72,4.26,27.28,12.58V90.83h20.56l0,106.3ZM567.92,133.7c-12,0-21.79,9.39-21.79,25.15S555.87,184,567.92,184s21.79-9.38,21.79-25.15S580,133.7,567.92,133.7Z'/%3e%3cpath%20class='cls-1'%20d='M686.6,197.14l-.71-12.22c-6.38,9.39-17.72,14.34-28.53,14.34-20.73,0-36-17.36-36-40.4s15.24-40.39,36-40.39c10.81,0,22.15,5,28.53,14.36l.71-12.23h18.6v76.53Zm-22.85-63.43c-12,0-21.79,9.39-21.8,25.16S651.7,184,663.74,184s21.8-9.39,21.8-25.16S675.8,133.71,663.75,133.71Z'/%3e%3cpath%20class='cls-1'%20d='M750.73,199.63a60.16,60.16,0,0,1-30.65-8.69l3.37-14.17c6.2,3.72,15.59,8.51,26.93,8.51,8.15,0,13.82-2.48,13.82-8.86,0-5.49-5.85-7.44-16.3-9.92-18.78-4.08-25.51-14-25.51-24.81,0-12.05,9.39-23.38,30.12-23.38,12.58,0,23.57,5.49,26,6.91l-3.37,13.47A44.59,44.59,0,0,0,753,132.31c-8.32,0-12.4,2.83-12.4,7.44,0,5.13,5.32,7.44,13.46,9.39,20.2,4.25,28.35,13.64,28.35,23.92C782.45,189.53,770.4,199.63,750.73,199.63Z'/%3e%3crect%20class='cls-1'%20x='74.88'%20y='68.42'%20width='24.09'%20height='50.02'/%3e%3crect%20class='cls-1'%20x='74.88'%20y='171.17'%20width='24.09'%20height='50.02'/%3e%3crect%20class='cls-2'%20x='74.88'%20y='133.04'%20width='24.09'%20height='23.6'/%3e%3crect%20class='cls-1'%20x='36.19'%20y='109.55'%20width='24.09'%20height='166.27'/%3e%3crect%20class='cls-1'%20x='112.78'%20y='212.44'%20width='24.09'%20height='50.02'/%3e%3crect%20class='cls-1'%20x='112.78'%20y='109.61'%20width='24.09'%20height='50.02'/%3e%3crect%20class='cls-3'%20x='112.78'%20y='174.23'%20width='24.09'%20height='23.6'/%3e%3crect%20class='cls-1'%20x='150.67'%20y='55.39'%20width='24.09'%20height='166.27'/%3e%3c/svg%3e",E="/assets/pytest-DYIuD6Wd.svg",a=({children:i,className:r})=>{const l=n.useRef(null),s=L(l,{once:!0,margin:"-100px"});return e.jsx(M.div,{ref:l,initial:{opacity:0,y:24},animate:s?{opacity:1,y:0}:{opacity:0,y:24},transition:{duration:.7,ease:"easeOut"},className:r,children:i})},W=()=>{n.useEffect(()=>{document.title="Python Certification Course: Master Python Programming | Aindhin";const s=document.querySelector('meta[name="description"]');s&&s.setAttribute("content","Aindhin is an online learning platform in India offering skill-based and career-oriented courses.")},[]);const[i,r]=n.useState(0),l=(s,p)=>{p.preventDefault(),r(i===s?null:s)};return e.jsxs("div",{className:"py-course font-sans text-slate-900 bg-blue-50 w-full overflow-x-hidden",children:[e.jsx("style",{children:`
            /* ===== PYTHON CERTIFICATION COURSE PAGE (scoped) ===== */
            .py-course{
              font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
              color:#0f172a;
              background:#e0f2fe;
              width:100%;
            }
            .py-course *{box-sizing:border-box;}
            
            /* HERO */
            .py-hero{
              color:#fff;
              background:
                linear-gradient(120deg,rgba(15,23,42,.96),rgba(37,99,235,.75)),
                url("${D}")
                center/cover no-repeat;
              padding:70px 20px;
              display:flex;
              align-items:center;
              justify-content:center;
            }
            .py-hero-content{
              max-width:900px;
              text-align:left;
            }
            .py-badge{
              display:inline-block;
              padding:4px 12px;
              border-radius:999px;
              background:rgba(15,23,42,.7);
              border:1px solid rgba(248,250,252,.4);
              font-size:12px;
              letter-spacing:.08em;
              text-transform:uppercase;
              margin-bottom:10px;
            }
            .fs-hero-title{
              color:#fff;
              font-size:64px;
              line-height:1.1;
              margin:0 0 14px;
            }
            .fs-hero-sub{
              font-size:20px;
              max-width:720px;
              color:#e5e7eb;
              margin:0 0 16px;
            }
            .py-hero-meta{
              display:flex;
              flex-wrap:wrap;
              gap:10px 18px;
              font-size:13px;
              color:#e5e7eb;
            }
            .py-hero-meta span::before{
              content:"• ";
              color:#fde68a;
              font-weight:700;
            }
            
            /* MAIN LAYOUT */
            .py-main{padding:40px 20px 50px;}
            .py-main-inner{
              max-width:1160px;
              margin:0 auto;
              display:grid;
              grid-template-columns:minmax(0,2fr) minmax(0,1.1fr);
              gap:24px;
            }
            .py-left,.py-right{
              display:flex;
              flex-direction:column;
              gap:16px;
            }
            
            /* CARDS */
            .py-card{
              background:#ffffff;
              border-radius:18px;
              padding:20px 22px;
              box-shadow:0 10px 25px rgba(15,23,42,.08);
            }
            .py-card h2{
              font-size:18px;
              margin:0 0 10px;
              color:#1d4ed8;
            }
            .py-about-text{
              font-size:14px;
              color:#4b5563;
              line-height:1.6;
            }
            
            /* SYLLABUS */
            .py-module{
              border:1px solid #e5e7eb;
              border-radius:12px;
              background:#f9fafb;
              margin-top:8px;
              overflow:hidden;
            }
            .py-module summary{
              list-style:none;
              padding:10px 14px;
              cursor:pointer;
              display:flex;
              justify-content:space-between;
              align-items:center;
              font-size:14px;
              font-weight:600;
            }
            .py-module summary::-webkit-details-marker{display:none;}
            .py-module summary::after{
              content:"▾";
              font-size:12px;
              color:#9ca3af;
              transition:transform .2s;
            }
            .py-module[open] summary::after{transform:rotate(-180deg);}
            .py-module-title{
              display:flex;
              gap:8px;
              flex-wrap:wrap;
              align-items:baseline;
            }
            .py-module-label{
              font-size:11px;
              text-transform:uppercase;
              letter-spacing:.08em;
              color:#111827;   /* dark text */
              font-weight:700; /* bold */
            }
            .py-module-content{
              padding:0 14px 10px 24px;
              font-size:13px;
              color:#4b5563;
            }
            .py-module-content ul{
              margin:0;
              padding-left:16px;
            }
            .py-module-content li{margin-bottom:4px;}
            
            /* RIGHT-COLUMN DETAILS */
            .py-detail-list{
              list-style:none;
              padding:0;
              margin:0 0 16px;
              font-size:14px;
            }
            .py-detail-item{
              display:flex;
              gap:10px;
              margin-bottom:10px;
            }
            .py-detail-icon{
              width:26px;
              height:26px;
              border-radius:999px;
              background:#e0f2fe;
              display:flex;
              align-items:center;
              justify-content:center;
              font-size:13px;
              color:#1d4ed8;
              flex-shrink:0;
            }
            .py-detail-text strong{
              display:block;
              font-weight:600;
              color:#111827;
            }
            .py-detail-text span{
              font-size:13px;
              color:#4b5563;
            }
            
            /* CTA BUTTON */
            .py-cta-btn{
              display:block;
              width:100%;
              border-radius:999px;
              padding:11px 16px;
              border:none;
              text-align:center;
              text-decoration:none;
              background:linear-gradient(135deg,#38bdf8,#6366f1);
              color:#fff !important;
              font-weight:600;
              font-size:15px;
              box-shadow:0 14px 30px rgba(37,99,235,.45);
              transition:transform .15s,box-shadow .15s,filter .15s,color .15s;
            }
            .py-cta-btn:hover{
              transform:translateY(-1px);
              filter:brightness(1.04);
              box-shadow:0 18px 40px rgba(37,99,235,.6);
              color:#fff !important;
            }
            
            /* TOP COMPANIES */
            .py-companies{
              background:#e0f2fe;
              padding:40px 20px 40px;
            }
            .py-companies-inner{
              max-width:1160px;
              margin:0 auto;
              text-align:center;
            }
            .py-companies h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .py-companies p{
              margin:0 0 20px;
              font-size:14px;
              color:#4b5563;
            }
            .py-logo-row{
              display:flex;
              flex-wrap:wrap;
              justify-content:center;
              gap:18px;
            }
            .py-logo-card{
              width:130px;
              height:62px;
              border-radius:14px;
              background:#ffffff;
              display:flex;
              align-items:center;
              justify-content:center;
              box-shadow:0 8px 18px rgba(15,23,42,.08);
              transition:transform .18s,box-shadow .18s;
            }
            .py-logo-card img{
              max-height:40px;
              max-width:100%;
            }
            .py-logo-card:hover{
              transform:translateY(-3px);
              box-shadow:0 14px 30px rgba(15,23,42,.16);
            }
            
            /* EXTRA COURSE DETAILS SECTION */
            .py-highlights{
              background:#e0f2fe;
              padding:10px 20px 50px;
            }
            .py-highlights-inner{
              max-width:1160px;
              margin:0 auto;
              display:grid;
              grid-template-columns:minmax(0,1.7fr) minmax(0,1.1fr);
              gap:28px;
              align-items:center;
            }
            .py-highlights-heading{
              margin-bottom:12px;
            }
            .py-highlights-heading h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .py-highlights-heading p{
              margin:0;
              font-size:14px;
              color:#4b5563;
            }
            .py-highlight-grid{
              margin-top:18px;
              display:grid;
              grid-template-columns:repeat(3,minmax(0,1fr));
              gap:14px;
            }
            .py-highlight-card{
              background:#ffffff;
              border-radius:16px;
              padding:14px 12px;
              box-shadow:0 10px 24px rgba(15,23,42,.08);
            }
            .py-highlight-icon{
              width:38px;
              height:38px;
              border-radius:999px;
              background:linear-gradient(135deg,#38bdf8,#6366f1);
              display:flex;
              align-items:center;
              justify-content:center;
              color:#fff;
              font-size:20px;
              margin-bottom:8px;
            }
            .py-highlight-card h3{
              font-size:14px;
              margin:0 0 4px;
              color:#0f172a;
            }
            .py-highlight-card p{
              font-size:13px;
              margin:0;
              color:#4b5563;
            }
            
            /* representation "image" block */
            .py-highlights-visual{
              display:flex;
              justify-content:center;
            }
            .py-dashboard{
              width:100%;
              max-width:340px;
              background:#ffffff;
              border-radius:20px;
              padding:14px 14px 18px;
              box-shadow:0 18px 40px rgba(37,99,235,.35);
            }
            .py-dashboard-header{
              display:flex;
              justify-content:space-between;
              align-items:center;
              margin-bottom:10px;
              font-size:12px;
              color:#0f172a;
            }
            .py-dashboard-dots{
              display:flex;
              gap:4px;
            }
            .py-dashboard-dots span{
              width:7px;
              height:7px;
              border-radius:999px;
              background:#bfdbfe;
            }
            .py-dashboard-graph{
              display:flex;
              gap:6px;
              align-items:flex-end;
              height:90px;
              margin-bottom:12px;
            }
            .py-dashboard-bar{
              flex:1;
              border-radius:8px 8px 2px 2px;
              background:linear-gradient(180deg,#38bdf8,#1d4ed8);
            }
            .py-dashboard-bar:nth-child(2){height:55%;}
            .py-dashboard-bar:nth-child(3){height:80%;}
            .py-dashboard-bar:nth-child(4){height:40%;}
            .py-dashboard-bar:nth-child(5){height:70%;}
            .py-dashboard-bar:nth-child(1){height:30%;}
            .py-dashboard-tags{
              display:flex;
              flex-wrap:wrap;
              gap:6px;
              font-size:11px;
            }
            .py-dashboard-tags span{
              padding:3px 7px;
              border-radius:999px;
              background:#eff6ff;
              color:#1d4ed8;
            }
            
            /* TOOLS SECTION */
            .py-tools{
              background:#e0f2fe;
              padding:0 20px 50px;
            }
            .py-tools-inner{
              max-width:1160px;
              margin:0 auto;
              text-align:center;
            }
            .py-tools-inner h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .py-tools-inner p{
              margin:0 0 20px;
              font-size:14px;
              color:#4b5563;
            }
            .py-tools-grid{
              display:flex;
              flex-wrap:wrap;
              justify-content:center;
              gap:16px;
            }
            .py-tools-card{
              width:140px;
              height:90px;
              border-radius:16px;
              background:#ffffff;
              box-shadow:0 10px 26px rgba(15,23,42,.12);
              display:flex;
              flex-direction:column;
              align-items:center;
              justify-content:center;
              padding:8px;
            }
            .py-tools-logo{
              max-height:36px;
              max-width:90px;
              margin-bottom:4px;
            }
            .py-tools-card span{
              font-size:12px;
              color:#111827;
            }
            
            /* MORE DETAILS SECTION */
            .py-more{
              background:#e0f2fe;
              padding:0 20px 50px;
            }
            .py-more-inner{
              max-width:1160px;
              margin:0 auto;
            }
            .py-more-header{
              text-align:center;
              margin-bottom:20px;
            }
            .py-more-header h2{
              font-size:20px;
              margin:0 0 6px;
              color:#0f172a;
            }
            .py-more-header p{
              margin:0;
              font-size:14px;
              color:#4b5563;
            }
            .py-more-grid{
              display:grid;
              grid-template-columns:repeat(3,minmax(0,1fr));
              gap:18px;
            }
            .py-more-card{
              background:#ffffff;
              border-radius:18px;
              padding:16px 14px;
              box-shadow:0 12px 30px rgba(15,23,42,.12);
              display:flex;
              flex-direction:column;
              gap:8px;
            }
            .py-more-top{
              display:flex;
              align-items:flex-start;
              gap:8px;
            }
            .py-more-icon{
              width:32px;
              height:32px;
              border-radius:999px;
              background:linear-gradient(135deg,#38bdf8,#6366f1);
              color:#fff;
              display:flex;
              align-items:center;
              justify-content:center;
              font-size:18px;
            }
            .py-more-title{
              font-size:15px;
              font-weight:600;
              margin:0;
              color:#0f172a;
            }
            .py-more-text{
              font-size:13px;
              color:#4b5563;
              margin:0;
            }
            .py-tool-logos{
              margin-top:12px;
              display:flex;
              flex-wrap:wrap;
              gap:10px;
              align-items:center;
              justify-content:center;
              width:100%;
            }
            .py-tool-logo{
              max-height:32px;
              width:auto;
              filter:drop-shadow(0 2px 4px rgba(15,23,42,.18));
            }
            .py-tool-logos img{
              max-height:32px !important;
              width:auto !important;
              object-fit:contain;
            }
            .py-roles-image{
              margin-top:8px;
              display:flex;
              flex-wrap:wrap;
              gap:6px;
            }
            .py-role-tag{
              padding:4px 8px;
              border-radius:999px;
              font-size:11px;
              background:#eff6ff;
              color:#1d4ed8;
            }
            .py-journey{
              margin-top:8px;
              border-left:2px solid #bfdbfe;
              padding-left:10px;
            }
            .py-journey-step{
              position:relative;
              padding-left:10px;
              margin-bottom:6px;
              font-size:12px;
              color:#4b5563;
            }
            .py-journey-step::before{
              content:"";
              position:absolute;
              left:-11px;
              top:5px;
              width:8px;
              height:8px;
              border-radius:999px;
              background:#38bdf8;
            }
            
            /* ENQUIRY / FORM SECTION */
            .py-enquiry{
              background:linear-gradient(135deg,#dbeafe,#e0f2fe);
              padding:40px 20px 50px;
            }
            .py-enquiry-inner{
              max-width:900px;
              margin:0 auto;
            }
            .py-enquiry-card{
              background:#ffffff;
              border-radius:22px;
              padding:24px 22px 18px;
              box-shadow:0 18px 40px rgba(37,99,235,.2);
              border-top:4px solid #38bdf8;
            }
            .py-enquiry-header{
              display:flex;
              align-items:flex-start;
              gap:10px;
              margin-bottom:10px;
            }
            .py-enquiry-icon{
              width:32px;
              height:32px;
              border-radius:999px;
              background:radial-gradient(circle at 30% 20%,#38bdf8,#6366f1);
              display:flex;
              align-items:center;
              justify-content:center;
              color:#fff;
              font-size:18px;
            }
            .py-enquiry-title{
              font-size:18px;
              font-weight:700;
              margin:0;
              color:#0f172a;
            }
            .py-enquiry-text{
              font-size:14px;
              color:#4b5563;
              margin:2px 0 12px;
            }
            
            /* FADE-IN ON SCROLL */
            .py-section{
              opacity:0;
              transform:translateY(24px);
              transition:opacity .7s ease-out, transform .7s ease-out;
            }
            .py-section.py-visible{
              opacity:1;
              transform:translateY(0);
            }
            
            /* RESPONSIVE */
            @media (max-width:900px){
              .py-hero{padding:50px 18px;}
              .fs-hero-title{font-size:48px;}
              .py-main-inner{
                grid-template-columns:minmax(0,1fr);
              }
              .py-highlights-inner{
                grid-template-columns:minmax(0,1fr);
              }
              .py-more-grid{
                grid-template-columns:minmax(0,1fr);
              }
            }
            @media (max-width:640px){
              .py-hero{padding:38px 16px;}
              .py-hero-meta{flex-direction:column;}
              .py-highlight-grid{
                grid-template-columns:minmax(0,1fr);
              }
            }
            `}),e.jsxs("div",{className:"py-course",id:"top",children:[e.jsx(a,{className:"py-hero py-section",children:e.jsxs("div",{className:"py-hero-content",children:[e.jsx("span",{className:"py-badge",children:"Python Programming"}),e.jsx("h1",{className:"fs-hero-title",children:"Master Python Programming: Get Certified and Build Real-World Applications"}),e.jsx("p",{className:"fs-hero-sub",children:"Learn Python from the ground up, master core programming concepts, work with data using popular libraries, and prepare for Python certification exams and real‑world roles."}),e.jsxs("div",{className:"py-hero-meta",children:[e.jsx("span",{children:"Covers core Python, OOP, files, modules & virtual envs"}),e.jsx("span",{children:"Hands‑on projects using NumPy, Pandas & APIs"}),e.jsx("span",{children:"Certification‑aligned practice tests & interview prep"})]})]})}),e.jsx("main",{className:"py-main py-section",children:e.jsxs("div",{className:"py-main-inner",children:[e.jsxs("div",{className:"py-left",children:[e.jsxs(a,{className:"py-card",children:[e.jsx("h2",{children:"About This Course"}),e.jsxs("div",{className:"py-about-text",children:[e.jsx("p",{children:"This course gives you a solid foundation in Python programming. You’ll begin with syntax, data types and control flow, move into functions and object‑oriented programming, and then explore modules, packages and error handling."}),e.jsx("p",{children:"You’ll also work with files, CSV/JSON data, virtual environments and popular libraries like NumPy and Pandas. The syllabus is aligned with common Python certification exams and technical interview expectations."})]})]}),e.jsxs(a,{className:"py-card",children:[e.jsx("h2",{children:"Syllabus Covered"}),e.jsxs("details",{className:"py-module",open:i===0,children:[e.jsx("summary",{onClick:s=>l(0,s),children:e.jsxs("div",{className:"py-module-title",children:[e.jsx("span",{className:"py-module-label",children:"Module 1"}),e.jsx("span",{children:"Python Basics & Core Concepts"})]})}),e.jsx("div",{className:"py-module-content",children:e.jsxs("ul",{children:[e.jsx("li",{children:"Python Installation, IDLE & VS Code Setup"}),e.jsx("li",{children:"Variables, Data Types & Type Conversion"}),e.jsx("li",{children:"Operators, Control Flow (if-else, loops)"}),e.jsx("li",{children:"Functions, Lambda Expressions & Recursion"}),e.jsx("li",{children:"String Manipulation & Regular Expressions"})]})})]}),e.jsxs("details",{className:"py-module",open:i===1,children:[e.jsx("summary",{onClick:s=>l(1,s),children:e.jsxs("div",{className:"py-module-title",children:[e.jsx("span",{className:"py-module-label",children:"Module 2"}),e.jsx("span",{children:"Data Structures & OOPs"})]})}),e.jsx("div",{className:"py-module-content",children:e.jsxs("ul",{children:[e.jsx("li",{children:"Lists, Tuples, Sets & Dictionaries"}),e.jsx("li",{children:"Object-Oriented Programming (Classes & Objects)"}),e.jsx("li",{children:"Inheritance, Polymorphism & Encapsulation"}),e.jsx("li",{children:"Exception Handling & File I/O"}),e.jsx("li",{children:"Modules, Packages & Virtual Environments"})]})})]}),e.jsxs("details",{className:"py-module",open:i===2,children:[e.jsx("summary",{onClick:s=>l(2,s),children:e.jsxs("div",{className:"py-module-title",children:[e.jsx("span",{className:"py-module-label",children:"Module 3"}),e.jsx("span",{children:"Libraries for Data Science"})]})}),e.jsx("div",{className:"py-module-content",children:e.jsxs("ul",{children:[e.jsx("li",{children:"NumPy: Arrays & Mathematical Operations"}),e.jsx("li",{children:"Pandas: DataFrames, Cleaning & Analysis"}),e.jsx("li",{children:"Matplotlib & Seaborn: Data Visualisation"}),e.jsx("li",{children:"Introduction to Scikit-Learn (Basic ML concepts)"}),e.jsx("li",{children:"Mini-Project: Data Analysis Dashboard"})]})})]}),e.jsxs("details",{className:"py-module",open:i===3,children:[e.jsx("summary",{onClick:s=>l(3,s),children:e.jsxs("div",{className:"py-module-title",children:[e.jsx("span",{className:"py-module-label",children:"Module 4"}),e.jsx("span",{children:"Web Development & Automation"})]})}),e.jsx("div",{className:"py-module-content",children:e.jsxs("ul",{children:[e.jsx("li",{children:"Introduction to Django / Flask (Web Frameworks)"}),e.jsx("li",{children:"REST APIs & JSON Handling"}),e.jsx("li",{children:"Web Scraping (BeautifulSoup / Selenium)"}),e.jsx("li",{children:"Automating Tasks with Python Scripts"}),e.jsx("li",{children:"Capstone Project: Full-fledged Application"})]})})]})]})]}),e.jsx("aside",{className:"py-right",children:e.jsxs(a,{className:"py-card",children:[e.jsx("h2",{children:"Course Details"}),e.jsxs("ul",{className:"py-detail-list",children:[e.jsxs("li",{className:"py-detail-item",children:[e.jsx("div",{className:"py-detail-icon",children:e.jsx(x,{size:20})}),e.jsxs("div",{className:"py-detail-text",children:[e.jsx("strong",{children:"Duration"}),e.jsx("span",{children:"12 Weeks (80+ hours)"})]})]}),e.jsxs("li",{className:"py-detail-item",children:[e.jsx("div",{className:"py-detail-icon",children:e.jsx(o,{size:20})}),e.jsxs("div",{className:"py-detail-text",children:[e.jsx("strong",{children:"Skill Level"}),e.jsx("span",{children:"Beginner to Advanced"})]})]}),e.jsxs("li",{className:"py-detail-item",children:[e.jsx("div",{className:"py-detail-icon",children:e.jsx(h,{size:20})}),e.jsxs("div",{className:"py-detail-text",children:[e.jsx("strong",{children:"Includes"}),e.jsx("span",{children:"Live Classes, Projects & Placement Support"})]})]}),e.jsxs("li",{className:"py-detail-item",children:[e.jsx("div",{className:"py-detail-icon",children:e.jsx(m,{size:20})}),e.jsxs("div",{className:"py-detail-text",children:[e.jsx("strong",{children:"Next Batch"}),e.jsx("span",{children:"Coming Soon"})]})]}),e.jsxs("li",{className:"py-detail-item",children:[e.jsx("div",{className:"py-detail-icon",children:e.jsx(t,{size:20})}),e.jsxs("div",{className:"py-detail-text",children:[e.jsx("strong",{children:"Certificate"}),e.jsx("span",{children:"Python Developer Certification"})]})]})]}),e.jsx("a",{href:"https://user.aindhin.com",target:"_blank",rel:"noopener noreferrer",className:"py-cta-btn",children:"Enroll Now & Start Learning"})]})})]})}),e.jsx(a,{className:"py-companies py-section",children:e.jsxs("div",{className:"py-companies-inner",children:[e.jsx("h2",{children:"Top Companies Hiring Python Developers"}),e.jsx("p",{children:"Python powers web apps, data pipelines, ML systems and automation across modern companies."}),e.jsxs("div",{className:"py-logo-row",children:[e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:v,alt:"Google"})}),e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:N,alt:"Microsoft"})}),e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:w,alt:"AWS"})}),e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:k,alt:"IBM"})}),e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:S,alt:"Meta"})}),e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:P,alt:"Netflix"})}),e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:C,alt:"Infosys"})}),e.jsx("div",{className:"py-logo-card",children:e.jsx("img",{src:z,alt:"Accenture"})})]})]})}),e.jsx(a,{className:"py-highlights py-section",children:e.jsxs("div",{className:"py-highlights-inner",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"py-highlights-heading",children:[e.jsx("h2",{children:"What You Will Achieve in This Python Certification Program"}),e.jsx("p",{children:"Develop strong programming fundamentals and hands‑on skills used across Python jobs."})]}),e.jsxs("div",{className:"py-highlight-grid",children:[e.jsxs("div",{className:"py-highlight-card",children:[e.jsx("div",{className:"py-highlight-icon",children:e.jsx(g,{size:24})}),e.jsx("h3",{children:"Versatile Language"}),e.jsx("p",{children:"Master Python’s simple syntax to build web apps, analyse data, and automate tasks."})]}),e.jsxs("div",{className:"py-highlight-card",children:[e.jsx("div",{className:"py-highlight-icon",children:e.jsx(y,{size:24})}),e.jsx("h3",{children:"Data Science Ready"}),e.jsx("p",{children:"Learn powerful libraries like Pandas, NumPy, and Matplotlib for data analysis."})]}),e.jsxs("div",{className:"py-highlight-card",children:[e.jsx("div",{className:"py-highlight-icon",children:e.jsx(f,{size:24})}),e.jsx("h3",{children:"Backend Development"}),e.jsx("p",{children:"Build robust backends using frameworks like Django and Flask."})]}),e.jsxs("div",{className:"py-highlight-card",children:[e.jsx("div",{className:"py-highlight-icon",children:e.jsx(c,{size:24})}),e.jsx("h3",{children:"AI & ML Foundation"}),e.jsx("p",{children:"Get started with machine learning concepts using Scikit-Learn."})]}),e.jsxs("div",{className:"py-highlight-card",children:[e.jsx("div",{className:"py-highlight-icon",children:e.jsx(j,{size:24})}),e.jsx("h3",{children:"Automation Scripts"}),e.jsx("p",{children:"Write scripts to automate repetitive tasks and improve productivity."})]}),e.jsxs("div",{className:"py-highlight-card",children:[e.jsx("div",{className:"py-highlight-icon",children:e.jsx(o,{size:24})}),e.jsx("h3",{children:"High Demand"}),e.jsx("p",{children:"Python developers are among the most sought-after professionals globally."})]})]})]}),e.jsx("div",{className:"py-highlights-visual",children:e.jsxs("div",{className:"py-dashboard",children:[e.jsxs("div",{className:"py-dashboard-header",children:[e.jsx("span",{children:"Python Script Performance"}),e.jsxs("div",{className:"py-dashboard-dots",children:[e.jsx("span",{}),e.jsx("span",{}),e.jsx("span",{})]})]}),e.jsxs("div",{className:"py-dashboard-graph",children:[e.jsx("div",{className:"py-dashboard-bar"}),e.jsx("div",{className:"py-dashboard-bar"}),e.jsx("div",{className:"py-dashboard-bar"}),e.jsx("div",{className:"py-dashboard-bar"}),e.jsx("div",{className:"py-dashboard-bar"})]}),e.jsxs("div",{className:"py-dashboard-tags",children:[e.jsx("span",{children:"Run Time"}),e.jsx("span",{children:"Memory"}),e.jsx("span",{children:"Tests"}),e.jsx("span",{children:"Coverage"})]})]})})]})}),e.jsx(a,{className:"py-tools py-section",children:e.jsxs("div",{className:"py-tools-inner",children:[e.jsx("h2",{children:"Tools & Libraries You Will Use"}),e.jsx("p",{children:"Practice with the most popular tools in the Python ecosystem."}),e.jsxs("div",{className:"py-tools-grid",children:[e.jsxs("div",{className:"py-tools-card",children:[e.jsx("img",{className:"py-tools-logo",src:d,alt:"Python"}),e.jsx("span",{children:"Python 3.x"})]}),e.jsxs("div",{className:"py-tools-card",children:[e.jsx("img",{className:"py-tools-logo",src:A,alt:"Jupyter"}),e.jsx("span",{children:"Jupyter Notebook"})]}),e.jsxs("div",{className:"py-tools-card",children:[e.jsx("img",{className:"py-tools-logo",src:I,alt:"VS Code"}),e.jsx("span",{children:"VS Code / IDEs"})]}),e.jsxs("div",{className:"py-tools-card",children:[e.jsx("img",{className:"py-tools-logo",src:T,alt:"NumPy"}),e.jsx("span",{children:"NumPy"})]}),e.jsxs("div",{className:"py-tools-card",children:[e.jsx("img",{className:"py-tools-logo",src:O,alt:"Pandas"}),e.jsx("span",{children:"Pandas"})]}),e.jsxs("div",{className:"py-tools-card",children:[e.jsx("img",{className:"py-tools-logo",src:E,alt:"pytest"}),e.jsx("span",{children:"pytest / unittest"})]}),e.jsxs("div",{className:"py-tools-card",children:[e.jsx("img",{className:"py-tools-logo",src:b,alt:"Git"}),e.jsx("span",{children:"Git & GitHub"})]})]})]})}),e.jsx(a,{className:"py-more py-section",children:e.jsxs("div",{className:"py-more-inner",children:[e.jsxs("div",{className:"py-more-header",children:[e.jsx("h2",{children:"Roles & Learning Journey"}),e.jsx("p",{children:"See how this Python course maps to real roles and how your skills grow week by week."})]}),e.jsxs("div",{className:"py-more-grid",children:[e.jsxs("div",{className:"py-more-card",children:[e.jsxs("div",{className:"py-more-top",children:[e.jsx("div",{className:"py-more-icon",children:e.jsx(c,{size:24})}),e.jsxs("div",{children:[e.jsx("h3",{className:"py-more-title",children:"Power of Python"}),e.jsx("p",{className:"py-more-text",children:"From simple scripts to complex AI models, Python powers the modern tech world."})]})]}),e.jsx("div",{className:"py-tool-logos",children:e.jsx("img",{className:"py-tool-logo",src:d,alt:"Python"})})]}),e.jsxs("div",{className:"py-more-card",children:[e.jsxs("div",{className:"py-more-top",children:[e.jsx("div",{className:"py-more-icon",children:e.jsx(u,{size:24})}),e.jsxs("div",{children:[e.jsx("h3",{className:"py-more-title",children:"Roles You Can Target"}),e.jsx("p",{className:"py-more-text",children:"With Python skills, you can aim for diverse roles in tech."})]})]}),e.jsxs("div",{className:"py-roles-image",children:[e.jsx("span",{className:"py-role-tag",children:"Python Developer"}),e.jsx("span",{className:"py-role-tag",children:"Data Analyst"}),e.jsx("span",{className:"py-role-tag",children:"Backend Developer"}),e.jsx("span",{className:"py-role-tag",children:"Automation Engineer"})]})]}),e.jsxs("div",{className:"py-more-card",children:[e.jsxs("div",{className:"py-more-top",children:[e.jsx("div",{className:"py-more-icon",children:e.jsx(t,{size:24})}),e.jsxs("div",{children:[e.jsx("h3",{className:"py-more-title",children:"Your Learning Path"}),e.jsx("p",{className:"py-more-text",children:"Step-by-step mastery from syntax to building deployable applications."})]})]}),e.jsxs("div",{className:"py-journey",children:[e.jsx("div",{className:"py-journey-step",children:"Weeks 1-3: Python Basics & Logic"}),e.jsx("div",{className:"py-journey-step",children:"Weeks 4-6: OOPs & File Handling"}),e.jsx("div",{className:"py-journey-step",children:"Weeks 7-9: Data Science Libraries"}),e.jsx("div",{className:"py-journey-step",children:"Weeks 10-12: Web Dev & Capstone"})]})]})]})]})})]})]})};export{W as default};
